(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,15034,e=>{"use strict";var t=e.i(43476),s=e.i(74431),a=e.i(71645),r=e.i(18566),i=e.i(17927),n=e.i(37066),l=e.i(77768);e.s(["default",0,function(){let e,[o,c]=(0,a.useState)(null),[d,m]=(0,a.useState)(!0),[u,p]=(0,a.useState)([]),[h,x]=(0,a.useState)([]),[f,g]=(0,a.useState)([]),[b,y]=(0,a.useState)(null),[v,_]=(0,a.useState)("all"),[j,N]=(0,a.useState)("all"),[w,$]=(0,a.useState)("all"),[C,S]=(0,a.useState)(!1),[q,P]=(0,a.useState)([]),[k,M]=(0,a.useState)(!1),[E,O]=(0,a.useState)([]),z=(0,r.useRouter)(),I=async()=>{try{y(null);let{data:e,error:t}=await i.supabase.from("commission_rate_introducer").select("*");if(e&&x(e),t)if("PGRST116"===t.code||t.message.includes("does not exist"));else throw t;let s=await (0,n.f)((e,t)=>i.supabase.from("customer_personal_data").select("customer_id, customer_name, introducer, customer_type, voucher_number").eq("customer_type","社區券客戶").order("id").range(e,t)),a=await (0,n.f)((e,t)=>i.supabase.from("customer_personal_data").select("introducer").not("introducer","is",null).order("id").range(e,t));if(a){let e=new Set;a.forEach(t=>{t.introducer&&e.add(t.introducer)}),O(Array.from(e).sort())}let r=[],l=0,o=!0;for(;o;){let{data:e,error:t}=await i.supabase.from("billing_salary_data").select(`
            customer_id,
            customer_name,
            service_date,
            service_hours,
            service_fee,
            project_category
          `).order("id").range(l,l+1e3-1);if(t)throw t;e&&e.length>0?(r=[...r,...e],l+=e.length,o=!0):o=!1}let c=r,d=c?.filter(e=>"MC街客"!==e.project_category&&"Steven140"!==e.project_category)||[],m=new Map;s.filter(t=>{let s=e?.some(e=>e.introducer===t.introducer),a=d.some(e=>e.customer_id===t.customer_id);return s&&a}).forEach(e=>{d.filter(t=>t.customer_id===e.customer_id).forEach(t=>{let s=new Date(t.service_date).toISOString().substring(0,7),a=`${e.customer_id}-${s}`;m.has(a)||m.set(a,{customer_id:e.customer_id,customer_name:e.customer_name,introducer:e.introducer,service_month:s,monthly_hours:0,monthly_fee:0,first_service_date:t.service_date,voucher_number:e.voucher_number||""});let r=m.get(a);r.monthly_hours=Math.round((r.monthly_hours+(Number(t.service_hours)||0))*100)/100,r.monthly_fee=Math.round((r.monthly_fee+(Number(t.service_fee)||0))*100)/100,t.service_date<r.first_service_date&&(r.first_service_date=t.service_date)})});let u=[],h=new Map;Array.from(m.values()).sort((e,t)=>e.service_month.localeCompare(t.service_month)).forEach(t=>{let s=t.monthly_fee>=6e3,a=0,r=0,i=t.customer_id,n=(h.get(i)||0)+1;h.set(i,n),r=n;let l=e?.find(e=>e.introducer===t.introducer);if(l){let e=1===n?l.first_month_commission:l.subsequent_month_commission;a=s?e:0}u.push({...t,is_qualified:s,month_sequence:r,commission_amount:a})}),g(u);let f=new Map;u.forEach(e=>{f.has(e.introducer)||f.set(e.introducer,{introducer:e.introducer,total_commission:0,first_month_count:0,subsequent_month_count:0,customers:[]});let t=f.get(e.introducer);t.customers.push(e),t.total_commission=Math.round((t.total_commission+e.commission_amount)*100)/100,1===e.month_sequence?t.first_month_count++:e.month_sequence>1&&t.subsequent_month_count++}),p(Array.from(f.values()))}catch(e){y(e.message||"獲取數據失敗")}},R=e=>new Intl.NumberFormat("zh-HK",{style:"currency",currency:"HKD",minimumFractionDigits:0}).format(e),D=e=>{let[t,s]=e.split("-");return`${t}年${s}月`},A=(e=f,"all"!==v&&(e.length,e=e.filter(e=>e.introducer===v)),"all"!==j&&(e.length,e=e.filter(e=>e.service_month.startsWith(j))),"all"!==w&&(e.length,e=e.filter(e=>e.service_month.endsWith(`-${w.padStart(2,"0")}`))),e.reduce((e,t)=>e+t.commission_amount,0),"all"!==w&&e.length>0&&e.forEach((e,t)=>{}),e),F=Array.from(new Set(f.map(e=>e.service_month.split("-")[0]))).sort(),L=new Map;A.forEach(e=>{L.has(e.introducer)||L.set(e.introducer,{introducer:e.introducer,total_commission:0,first_month_count:0,subsequent_month_count:0,customers:[]});let t=L.get(e.introducer);t.customers.push(e),e.is_qualified&&(t.total_commission=Math.round((t.total_commission+e.commission_amount)*100)/100,1===e.month_sequence?t.first_month_count++:t.subsequent_month_count++)});let T=Array.from(L.values()),W=A.reduce((e,t)=>e+t.commission_amount,0);return((0,a.useEffect)(()=>{(async()=>{let{data:{user:e},error:t}=await i.supabase.auth.getUser();e?(c(e),await I()):z.push("/"),m(!1)})()},[z]),d)?(0,t.jsx)(l.f,{message:"正在載入佣金數據..."}):b?(0,t.jsx)("div",{className:"min-h-screen bg-bg-primary flex items-center justify-center",children:(0,t.jsx)("div",{className:"text-center card-apple max-w-md mx-4",children:(0,t.jsxs)("div",{className:"card-apple-content",children:[(0,t.jsx)("h2",{className:"text-lg font-semibold text-red-600 mb-4",children:"載入數據時發生錯誤"}),(0,t.jsx)("p",{className:"text-text-secondary mb-4",children:b}),(0,t.jsx)("button",{onClick:I,className:"btn-apple-primary",children:"重新載入"})]})})}):(0,t.jsxs)("div",{className:"min-h-screen bg-bg-primary",children:[(0,t.jsx)("header",{className:"card-apple border-b border-border-light fade-in-apple sticky top-0 z-10",children:(0,t.jsx)("div",{className:"px-3 sm:px-6 lg:px-8",children:(0,t.jsxs)("div",{className:"flex justify-between items-center py-3 sm:py-6 lg:py-8",children:[(0,t.jsxs)("div",{className:"flex-1 min-w-0",children:[(0,t.jsx)("h1",{className:"text-base sm:text-xl lg:text-2xl font-bold text-text-primary mb-1 truncate",children:"佣金計算"}),(0,t.jsx)("p",{className:"text-xs sm:text-sm text-text-secondary hidden md:block",children:"計算業務佣金、獎金及績效獎勵"}),(0,t.jsx)("p",{className:"text-xs text-orange-600 mt-1",children:"達標：月費 ≥ $6,000"})]}),(0,t.jsxs)("div",{className:"flex gap-2 ml-2 sm:ml-3 flex-shrink-0",children:[(0,t.jsx)("button",{onClick:()=>z.push("/commissions/voucher-commission"),className:"btn-apple-primary text-xs px-2 sm:px-3 py-2 bg-purple-600 hover:bg-purple-700",children:"📊 社區券佣金"}),(0,t.jsx)("button",{onClick:()=>z.push("/dashboard"),className:"btn-apple-secondary text-xs px-2 sm:px-3 py-2",children:"返回"})]})]})})}),(0,t.jsxs)("main",{className:"px-3 sm:px-6 lg:px-8 py-3 sm:py-6 lg:py-8",children:[(0,t.jsx)("div",{className:"card-apple fade-in-apple mb-4 sm:mb-6",children:(0,t.jsx)("div",{className:"card-apple-content",children:(0,t.jsxs)("div",{className:"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"block text-xs sm:text-sm font-medium text-text-primary mb-1 sm:mb-2",children:"介紹人："}),(0,t.jsxs)("select",{value:v,onChange:e=>_(e.target.value),className:"form-input-apple w-full text-xs sm:text-sm",children:[(0,t.jsx)("option",{value:"all",children:"全部介紹人"}),Array.from(new Set(f.map(e=>e.introducer))).map(e=>(0,t.jsx)("option",{value:e,children:e},e))]})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"block text-xs sm:text-sm font-medium text-text-primary mb-1 sm:mb-2",children:"年份："}),(0,t.jsxs)("select",{value:j,onChange:e=>N(e.target.value),className:"form-input-apple w-full text-xs sm:text-sm",children:[(0,t.jsx)("option",{value:"all",children:"全部年份"}),F.map(e=>(0,t.jsxs)("option",{value:e,children:[e,"年"]},e))]})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"block text-xs sm:text-sm font-medium text-text-primary mb-1 sm:mb-2",children:"月份："}),(0,t.jsxs)("select",{value:w,onChange:e=>$(e.target.value),className:"form-input-apple w-full text-xs sm:text-sm",children:[(0,t.jsx)("option",{value:"all",children:"全部月份"}),["01","02","03","04","05","06","07","08","09","10","11","12"].map(e=>(0,t.jsxs)("option",{value:e,children:[e,"月"]},e))]})]}),(0,t.jsxs)("div",{className:"sm:col-span-2 lg:col-span-2 grid grid-cols-2 sm:flex sm:items-end gap-2 sm:space-x-2",children:[(0,t.jsx)("button",{onClick:()=>{_("all"),N("all"),$("all")},className:"btn-apple-secondary text-xs sm:text-sm py-2 sm:py-3 sm:flex-1",children:"清除篩選"}),(0,t.jsx)("button",{onClick:I,className:"btn-apple-primary text-xs sm:text-sm py-2 sm:py-3 sm:flex-1",children:"重新載入"}),(0,t.jsx)("button",{onClick:()=>{try{let e=new Map;A.forEach(t=>{e.has(t.service_month)||e.set(t.service_month,[]),e.get(t.service_month).push(t)});let t=Array.from(e.keys()).sort(),a=0,r=0,i=0,n=0,l=0,o=new Set,c=t.map(t=>{let s=e.get(t),[c,d]=t.split("-"),m=new Map;s.forEach(e=>{e.commission_amount>0&&(m.has(e.introducer)||m.set(e.introducer,[]),m.get(e.introducer).push(e))});let u=s.reduce((e,t)=>e+t.monthly_fee,0),p=s.reduce((e,t)=>e+t.monthly_hours,0),x=s.filter(e=>e.is_qualified).length,f=s.filter(e=>!e.is_qualified&&e.commission_amount>0).length,g=s.reduce((e,t)=>e+(t.commission_amount||0),0);return a=Math.round((a+u)*100)/100,r=Math.round((r+p)*100)/100,i+=x,n+=f,l=Math.round((l+g)*100)/100,Array.from(m.keys()).forEach(e=>{o.add(e)}),m.forEach((e,t)=>{e.reduce((e,t)=>e+(t.commission_amount||0),0),e.filter(e=>e.is_qualified).length,e.filter(e=>!e.is_qualified).length,e.filter(e=>1===e.month_sequence).length,e.filter(e=>e.month_sequence>1).length,e.forEach(e=>{})}),{year:c,month:d,qualifiedCustomers:x,unqualifiedCustomers:f,totalHours:p,totalFee:u,totalCommission:g,commissions:Array.from(m.entries()).map(([e,t])=>{let s=t.filter(e=>e.commission_amount>0),a=s.filter(e=>e.is_qualified),r=s.filter(e=>!e.is_qualified),i=s.reduce((e,t)=>e+t.monthly_fee,0),n=s.reduce((e,t)=>e+t.commission_amount,0),l=h.find(t=>t.introducer===e)?.first_month_commission||0;return{introducerName:e,rate:l,qualifiedCustomers:a.length,unqualifiedCustomers:r.length,totalFee:i,amount:n,customerDetails:t.map(e=>({customerName:e.customer_name,customerId:e.customer_id,hours:e.monthly_hours,fee:e.monthly_fee,isQualified:e.is_qualified,commission:e.commission_amount}))}}),allCustomers:s.map(e=>({customerName:e.customer_name,customerId:e.customer_id,voucherNumber:e.voucher_number||"",introducer:e.introducer,hours:e.monthly_hours,fee:e.monthly_fee,isQualified:e.is_qualified,commission:e.commission_amount}))}}),d=new Map,m=new Map;A.forEach(e=>{let t=`${e.introducer}-${e.customer_id}`;m.has(t)||m.set(t,{introducer:e.introducer,customer_id:e.customer_id,customer_name:e.customer_name,total_fee:0,total_commission:0,is_qualified:e.is_qualified});let s=m.get(t);s.total_fee=Math.round((s.total_fee+e.monthly_fee)*100)/100,s.total_commission=Math.round((s.total_commission+e.commission_amount)*100)/100,s.is_qualified=s.is_qualified||e.is_qualified}),m.forEach(e=>{if(e.is_qualified&&e.total_commission>0){d.has(e.introducer)||d.set(e.introducer,{introducerName:e.introducer,qualifiedCustomers:0,unqualifiedCustomers:0,totalServiceFee:0,totalCommission:0});let t=d.get(e.introducer);e.is_qualified?t.qualifiedCustomers+=1:t.unqualifiedCustomers+=1,t.totalServiceFee=Math.round((t.totalServiceFee+e.total_fee)*100)/100,t.totalCommission=Math.round((t.totalCommission+e.total_commission)*100)/100}});let u=Array.from(d.values()).sort((e,t)=>e.introducerName.localeCompare(t.introducerName,"zh-TW")),p=`
        <!DOCTYPE html>
        <html lang="zh-TW">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>佣金計算報告</title>
          <style>
            body {
              font-family: 'Microsoft JhengHei', '微軟正黑體', Arial, sans-serif;
              margin: 20px;
              font-size: 12px;
              line-height: 1.4;
            }
            
            .header {
              text-align: center;
              margin-bottom: 30px;
              border-bottom: 2px solid #428bca;
              padding-bottom: 15px;
              position: relative;
            }
            
            .header h1 {
              color: #428bca;
              margin: 0;
              font-size: 24px;
            }
            
            .save-pdf-btn {
              position: absolute;
              top: 10px;
              right: 10px;
              background-color: #428bca;
              color: white;
              border: none;
              padding: 10px 20px;
              border-radius: 5px;
              cursor: pointer;
              font-size: 14px;
              font-weight: bold;
            }
            
            .save-pdf-btn:hover {
              background-color: #357abd;
            }
            
            .date-range {
              color: #666;
              margin-top: 10px;
              font-size: 14px;
            }
            
            .filters {
              margin-top: 10px;
              font-size: 12px;
              color: #888;
            }
            
            .month-section {
              margin-bottom: 30px;
              page-break-inside: avoid;
            }
            
            .month-header {
              background-color: #f8f9fa;
              padding: 10px;
              border-left: 4px solid #428bca;
              margin-bottom: 15px;
            }
            
            .month-title {
              font-size: 16px;
              font-weight: bold;
              color: #428bca;
              margin: 0;
            }
            
            .month-summary {
              display: flex;
              justify-content: space-around;
              background-color: #e7f3ff;
              padding: 10px;
              border-radius: 5px;
              margin: 10px 0;
            }
            
            .summary-item {
              text-align: center;
            }
            
            .summary-label {
              font-weight: bold;
              color: #428bca;
              display: block;
              font-size: 11px;
            }
            
            .summary-value {
              font-size: 14px;
              font-weight: bold;
              color: #333;
            }
            
            .commissions-table {
              width: 100%;
              border-collapse: collapse;
              margin-top: 10px;
            }
            
            .commissions-table th,
            .commissions-table td {
              border: 1px solid #ddd;
              padding: 8px;
              text-align: left;
            }
            
            .commissions-table th {
              background-color: #428bca;
              color: white;
              font-weight: bold;
            }
            
            .commissions-table tr:nth-child(even) {
              background-color: #f9f9f9;
            }
            
            .customer-details {
              margin: 20px 0;
            }
            
            .customer-details h4 {
              color: #428bca;
              border-bottom: 1px solid #ddd;
              padding-bottom: 5px;
              margin-bottom: 10px;
            }
            
            .customer-table {
              width: 100%;
              border-collapse: collapse;
              margin-bottom: 20px;
              font-size: 11px;
            }
            
            .customer-table th,
            .customer-table td {
              border: 1px solid #ddd;
              padding: 6px;
              text-align: left;
            }
            
            .customer-table th {
              background-color: #f5f5f5;
              font-weight: bold;
              color: #333;
            }
            
            .customer-table tr.qualified {
              background-color: #e8f5e8;
            }
            
            .customer-table tr.not-qualified {
              background-color: #ffe8e8;
            }
            
            .number {
              text-align: right;
            }
            
            .introducer-summary-table {
              width: 100%;
              border-collapse: collapse;
              margin: 20px 0;
            }
            
            .introducer-summary-table th,
            .introducer-summary-table td {
              border: 1px solid #ddd;
              padding: 10px;
              text-align: left;
            }
            
            .introducer-summary-table th {
              background-color: #428bca;
              color: white;
              font-weight: bold;
            }
            
            .introducer-summary-table tr:nth-child(even) {
              background-color: #f9f9f9;
            }
            
            .overall-summary {
              margin-top: 40px;
              padding: 20px;
              border: 2px solid #428bca;
              background-color: #f8f9fa;
              page-break-inside: avoid;
            }
            
            .overall-summary h2 {
              text-align: center;
              color: #428bca;
              margin-bottom: 20px;
            }
            
            .total-stats {
              display: flex;
              justify-content: space-around;
              margin-top: 15px;
            }
            
            .total-stat {
              text-align: center;
            }
            
            .total-stat-label {
              font-weight: bold;
              color: #428bca;
              display: block;
              margin-bottom: 5px;
            }
            
            .total-stat-value {
              font-size: 18px;
              font-weight: bold;
              color: #333;
            }
            
            @media print {
              body { margin: 15px; }
              .month-section { page-break-inside: avoid; }
              .overall-summary { page-break-inside: avoid; }
              .save-pdf-btn { display: none; }
            }
          </style>
        </head>
        <body>
          <div class="header">
            <button class="save-pdf-btn" data-intranet-print>儲存為PDF</button>
            <h1>佣金計算報告</h1>
            <div class="date-range">
              生成日期: ${new Date().toLocaleDateString("zh-TW")}
            </div>
            <div class="filters">
              ${"all"!==v?`介紹人: ${v} | `:""}${"all"!==j?`年份: ${j} | `:""}${"all"!==w?`月份: ${w}`:""}
            </div>
          </div>
          
          ${c.map(e=>`
            <div class="month-section">
              <div class="month-header">
                <h3 class="month-title">${e.year}年${e.month}月 佣金統計</h3>
              </div>
              
              <div class="month-summary">
                <div class="summary-item">
                  <span class="summary-label">達標客戶</span>
                  <span class="summary-value">${e.qualifiedCustomers}</span>
                </div>
                <div class="summary-item">
                  <span class="summary-label">不達標客戶</span>
                  <span class="summary-value">${e.unqualifiedCustomers}</span>
                </div>
                <div class="summary-item">
                  <span class="summary-label">總服務時數</span>
                  <span class="summary-value">${e.totalHours.toFixed(1)}</span>
                </div>
                <div class="summary-item">
                  <span class="summary-label">總服務金額</span>
                  <span class="summary-value">$${e.totalFee.toLocaleString()}</span>
                </div>
                <div class="summary-item">
                  <span class="summary-label">總佣金</span>
                  <span class="summary-value">$${e.totalCommission.toLocaleString()}</span>
                </div>
              </div>
              
              <div class="customer-details">
                <h4>客戶明細</h4>
                <table class="customer-table">
                  <thead>
                    <tr>
                      <th>客戶編號</th>
                      <th>客戶姓名</th>
                      <th>CCSV 號碼</th>
                      <th>介紹人</th>
                      <th>服務時數</th>
                      <th>服務費用</th>
                      <th>達標狀態</th>
                      <th>佣金金額</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${e.allCustomers.map(e=>`
                      <tr class="${e.isQualified?"qualified":"not-qualified"}">
                        <td>${e.customerId}</td>
                        <td>${e.customerName}</td>
                        <td>${e.voucherNumber||"-"}</td>
                        <td>${e.introducer}</td>
                        <td class="number">${e.hours.toFixed(1)} 小時</td>
                        <td class="number">$${e.fee.toLocaleString()}</td>
                        <td style="text-align: center;">${e.isQualified?"✓ 達標":"✗ 不達標"}</td>
                        <td class="number">${e.commission>0?"$"+e.commission.toLocaleString():"$0"}</td>
                      </tr>
                    `).join("")}
                  </tbody>
                </table>
              </div>
              
              ${e.commissions.length>0?`
                <div class="customer-details">
                  <h4>介紹人佣金匯總</h4>
                  <table class="commissions-table">
                    <thead>
                      <tr>
                        <th>介紹人</th>
                        <th>達標客戶</th>
                        <th>不達標客戶</th>
                        <th>總服務金額</th>
                        <th>佣金金額</th>
                      </tr>
                    </thead>
                    <tbody>
                      ${e.commissions.map(e=>`
                        <tr>
                          <td>${e.introducerName}</td>
                          <td class="number">${e.qualifiedCustomers}</td>
                          <td class="number">${e.unqualifiedCustomers}</td>
                          <td class="number">$${e.totalFee.toLocaleString()}</td>
                          <td class="number">$${e.amount.toLocaleString()}</td>
                        </tr>
                      `).join("")}
                    </tbody>
                  </table>
                </div>
              `:'<p style="text-align: center; color: #666; font-style: italic;">本月無佣金記錄</p>'}
            </div>
          `).join("")}
          
          <div class="overall-summary">
            <h2>總結報告</h2>
            
            <h3 style="color: #428bca; margin-bottom: 15px;">各介紹人統計明細</h3>
            <table class="introducer-summary-table">
              <thead>
                <tr>
                  <th>介紹人</th>
                  <th>達標客戶數</th>
                  <th>不達標客戶數</th>
                  <th>總服務金額</th>
                  <th>總佣金金額</th>
                </tr>
              </thead>
              <tbody>
                ${u.map(e=>`
                  <tr>
                    <td>${e.introducerName}</td>
                    <td class="number">${e.qualifiedCustomers}</td>
                    <td class="number">${e.unqualifiedCustomers}</td>
                    <td class="number">$${e.totalServiceFee.toLocaleString()}</td>
                    <td class="number">$${e.totalCommission.toLocaleString()}</td>
                  </tr>
                `).join("")}
              </tbody>
            </table>
            
            <h3 style="color: #428bca; margin: 30px 0 15px 0;">整體統計總計</h3>
            <div class="total-stats">
              <div class="total-stat">
                <span class="total-stat-label">介紹人總數</span>
                <span class="total-stat-value">${o.size}</span>
              </div>
              <div class="total-stat">
                <span class="total-stat-label">總達標客戶</span>
                <span class="total-stat-value">${i}</span>
              </div>
              <div class="total-stat">
                <span class="total-stat-label">總不達標客戶</span>
                <span class="total-stat-value">${n}</span>
              </div>
              <div class="total-stat">
                <span class="total-stat-label">總服務時數</span>
                <span class="total-stat-value">${r.toFixed(1)}</span>
              </div>
              <div class="total-stat">
                <span class="total-stat-label">總服務金額</span>
                <span class="total-stat-value">$${a.toLocaleString()}</span>
              </div>
              <div class="total-stat">
                <span class="total-stat-label">總佣金</span>
                <span class="total-stat-value">$${l.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </body>
        </html>
      `,x=window.open("","_blank","width=1200,height=800,scrollbars=yes,resizable=yes");x?(x.document.write((0,s.f)(p)),x.document.close()):alert("請允許彈出視窗以顯示報告")}catch(e){alert("PDF導出失敗，請稍後再試")}},className:"btn-apple-primary col-span-2 sm:col-span-1 sm:flex-1 bg-green-600 hover:bg-green-700 text-xs sm:text-sm py-2 sm:py-3",children:"📄 導出PDF"}),(0,t.jsx)("button",{onClick:()=>{let e=new Map(h.map(e=>[e.introducer,e]));P(E.map(t=>e.get(t)||{introducer:t,first_month_commission:0,subsequent_month_commission:0,voucher_commission_percentage:null})),S(!0)},className:"btn-apple-secondary col-span-2 sm:col-span-1 sm:flex-1 text-xs sm:text-sm py-2 sm:py-3",children:"⚙️ 佣金設定"})]})]})})}),C&&(0,t.jsxs)("div",{className:"card-apple mb-6 fade-in-apple",children:[(0,t.jsxs)("div",{className:"bg-bg-secondary px-4 sm:px-6 py-4 border-b border-border-light rounded-t-apple flex justify-between items-center",children:[(0,t.jsx)("h2",{className:"text-lg font-semibold text-text-primary",children:"介紹人佣金費率設定"}),(0,t.jsx)("button",{onClick:()=>S(!1),className:"text-text-secondary hover:text-text-primary",children:"✕"})]}),(0,t.jsxs)("div",{className:"p-4 sm:p-6",children:[(0,t.jsx)("div",{className:"overflow-x-auto",children:(0,t.jsxs)("table",{className:"w-full text-sm",children:[(0,t.jsx)("thead",{className:"bg-bg-secondary",children:(0,t.jsxs)("tr",{children:[(0,t.jsx)("th",{className:"px-4 py-3 text-left font-medium text-text-secondary",children:"介紹人"}),(0,t.jsx)("th",{className:"px-4 py-3 text-center font-medium text-text-secondary",children:"首月佣金 ($)"}),(0,t.jsx)("th",{className:"px-4 py-3 text-center font-medium text-text-secondary",children:"後續月份佣金 ($)"}),(0,t.jsx)("th",{className:"px-4 py-3 text-center font-medium text-text-secondary",children:"社區券佣金 (%)"})]})}),(0,t.jsx)("tbody",{className:"divide-y divide-border-light",children:q.map((e,s)=>(0,t.jsxs)("tr",{className:"hover:bg-bg-secondary transition-colors",children:[(0,t.jsx)("td",{className:"px-4 py-3 font-medium text-text-primary",children:e.introducer}),(0,t.jsx)("td",{className:"px-4 py-3 text-center",children:(0,t.jsx)("input",{type:"number",value:e.first_month_commission||0,onChange:e=>{let t=[...q];t[s].first_month_commission=parseFloat(e.target.value)||0,P(t)},className:"form-input-apple w-24 text-center text-sm",min:"0"})}),(0,t.jsx)("td",{className:"px-4 py-3 text-center",children:(0,t.jsx)("input",{type:"number",value:e.subsequent_month_commission||0,onChange:e=>{let t=[...q];t[s].subsequent_month_commission=parseFloat(e.target.value)||0,P(t)},className:"form-input-apple w-24 text-center text-sm",min:"0"})}),(0,t.jsx)("td",{className:"px-4 py-3 text-center",children:(0,t.jsx)("input",{type:"number",value:e.voucher_commission_percentage??"",onChange:e=>{let t=[...q];t[s].voucher_commission_percentage=e.target.value?parseFloat(e.target.value):null,P(t)},className:"form-input-apple w-24 text-center text-sm",placeholder:"不設定",min:"0",max:"100",step:"0.5"})})]},e.introducer))})]})}),(0,t.jsxs)("div",{className:"mt-4 flex justify-end gap-3",children:[(0,t.jsx)("button",{onClick:()=>S(!1),className:"btn-apple-secondary text-sm py-2 px-4",disabled:k,children:"取消"}),(0,t.jsx)("button",{onClick:async()=>{M(!0);try{let{error:e}=await i.supabase.rpc("save_commission_rates",{p_rates:q});if(e)throw e;alert("佣金費率已保存！"),S(!1),await I()}catch(e){alert("保存失敗，請重試")}finally{M(!1)}},className:"btn-apple-primary text-sm py-2 px-4",disabled:k,children:k?"保存中...":"保存設定"})]}),(0,t.jsxs)("div",{className:"mt-4 p-3 bg-blue-50 rounded-lg text-sm text-blue-800",children:[(0,t.jsx)("p",{children:(0,t.jsx)("strong",{children:"說明："})}),(0,t.jsxs)("ul",{className:"list-disc list-inside mt-1 space-y-1",children:[(0,t.jsxs)("li",{children:[(0,t.jsx)("strong",{children:"首月/後續月份佣金："}),"固定金額佣金（$800, $700 等）"]}),(0,t.jsxs)("li",{children:[(0,t.jsx)("strong",{children:"社區券佣金 (%)："}),"按社區券費率計算的百分比佣金（例如 15% = 服務費 × 15%）"]})]})]})]})]}),(0,t.jsxs)("div",{className:"grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-4 mb-4 sm:mb-6",children:[(0,t.jsx)("div",{className:"card-apple fade-in-apple",style:{animationDelay:"0.1s"},children:(0,t.jsxs)("div",{className:"card-apple-content text-center py-3 sm:py-4",children:[(0,t.jsx)("h3",{className:"text-xs sm:text-sm font-medium text-text-secondary mb-1 sm:mb-2",children:"總佣金"}),(0,t.jsx)("p",{className:"text-sm sm:text-xl font-bold text-mingcare-green",children:R(W)})]})}),(0,t.jsx)("div",{className:"card-apple fade-in-apple",style:{animationDelay:"0.2s"},children:(0,t.jsxs)("div",{className:"card-apple-content text-center py-3 sm:py-4",children:[(0,t.jsx)("h3",{className:"text-xs sm:text-sm font-medium text-text-secondary mb-1 sm:mb-2",children:"介紹人數量"}),(0,t.jsx)("p",{className:"text-sm sm:text-xl font-bold text-primary",children:T.length})]})}),(0,t.jsx)("div",{className:"card-apple fade-in-apple",style:{animationDelay:"0.3s"},children:(0,t.jsxs)("div",{className:"card-apple-content text-center py-3 sm:py-4",children:[(0,t.jsx)("h3",{className:"text-xs sm:text-sm font-medium text-text-secondary mb-1 sm:mb-2",children:"首月佣金"}),(0,t.jsx)("p",{className:"text-sm sm:text-xl font-bold text-mingcare-purple",children:T.reduce((e,t)=>e+t.first_month_count,0)})]})}),(0,t.jsx)("div",{className:"card-apple fade-in-apple",style:{animationDelay:"0.4s"},children:(0,t.jsxs)("div",{className:"card-apple-content text-center py-3 sm:py-4",children:[(0,t.jsx)("h3",{className:"text-xs sm:text-sm font-medium text-text-secondary mb-1 sm:mb-2",children:"後續月份"}),(0,t.jsx)("p",{className:"text-sm sm:text-xl font-bold text-mingcare-orange",children:T.reduce((e,t)=>e+t.subsequent_month_count,0)})]})})]}),(0,t.jsx)("div",{className:"space-y-4 sm:space-y-6",children:T.map((e,s)=>{let a;return(0,t.jsxs)("div",{className:"card-apple fade-in-apple",style:{animationDelay:`${.1*(s+1)}s`},children:[(0,t.jsx)("div",{className:"bg-bg-secondary px-3 sm:px-6 py-3 sm:py-4 border-b border-border-light rounded-t-apple",children:(0,t.jsxs)("div",{className:"flex flex-col sm:flex-row sm:justify-between sm:items-start",children:[(0,t.jsxs)("div",{className:"mb-2 sm:mb-0",children:[(0,t.jsxs)("h2",{className:"text-base sm:text-lg font-semibold text-text-primary mb-1",children:["介紹人：",e.introducer]}),(a=h.find(t=>t.introducer===e.introducer))?(0,t.jsxs)("div",{className:"text-xs sm:text-sm text-text-secondary",children:[(0,t.jsxs)("span",{className:"inline-block bg-blue-100 text-blue-800 px-2 py-1 rounded mr-2 text-xs",children:["首月: ",R(a.first_month_commission)]}),(0,t.jsxs)("span",{className:"inline-block bg-green-100 text-green-800 px-2 py-1 rounded",children:["後續: ",R(a.subsequent_month_commission)]})]}):(0,t.jsx)("div",{className:"text-sm text-red-600",children:"未設定佣金率"})]}),(0,t.jsxs)("div",{className:"text-right",children:[(0,t.jsxs)("p",{className:"text-lg font-bold text-mingcare-green",children:["總佣金：",R(e.customers.reduce((e,t)=>e+t.commission_amount,0))]}),(0,t.jsxs)("p",{className:"text-sm text-text-secondary",children:["首月：",e.first_month_count," | 後續：",e.subsequent_month_count]})]})]})}),(0,t.jsx)("div",{className:"hidden sm:block overflow-x-auto",children:(0,t.jsxs)("table",{className:"w-full text-sm",children:[(0,t.jsx)("thead",{className:"bg-bg-secondary",children:(0,t.jsxs)("tr",{children:[(0,t.jsx)("th",{className:"px-4 py-3 text-left font-medium text-text-secondary",children:"客戶編號"}),(0,t.jsx)("th",{className:"px-4 py-3 text-left font-medium text-text-secondary",children:"客戶姓名"}),(0,t.jsx)("th",{className:"px-4 py-3 text-left font-medium text-text-secondary",children:"服務月份"}),(0,t.jsx)("th",{className:"px-4 py-3 text-right font-medium text-text-secondary",children:"服務時數"}),(0,t.jsx)("th",{className:"px-4 py-3 text-right font-medium text-text-secondary",children:"服務費用"}),(0,t.jsx)("th",{className:"px-4 py-3 text-center font-medium text-text-secondary",children:"月份序號"}),(0,t.jsx)("th",{className:"px-4 py-3 text-right font-medium text-text-secondary",children:"佣金金額"})]})}),(0,t.jsx)("tbody",{className:"divide-y divide-border-light",children:e.customers.map((e,s)=>(0,t.jsxs)("tr",{className:"hover:bg-bg-secondary transition-colors",children:[(0,t.jsx)("td",{className:"px-4 py-3 text-text-primary",children:e.customer_id}),(0,t.jsx)("td",{className:"px-4 py-3 text-text-primary",children:e.customer_name}),(0,t.jsx)("td",{className:"px-4 py-3 text-text-secondary",children:D(e.service_month)}),(0,t.jsxs)("td",{className:"px-4 py-3 text-right text-text-secondary",children:[e.monthly_hours.toFixed(1),"h"]}),(0,t.jsx)("td",{className:"px-4 py-3 text-right text-text-secondary",children:R(e.monthly_fee)}),(0,t.jsx)("td",{className:"px-4 py-3 text-center",children:e.is_qualified?(0,t.jsx)("span",{className:`px-2 py-1 rounded-apple-sm text-xs font-medium ${1===e.month_sequence?"bg-blue-100 text-blue-800":"bg-green-100 text-green-800"}`,children:1===e.month_sequence?"首月":`第${e.month_sequence}月`}):(0,t.jsx)("span",{className:"px-2 py-1 rounded-apple-sm text-xs font-medium bg-red-100 text-red-800",children:"不達標"})}),(0,t.jsx)("td",{className:"px-4 py-3 text-right font-semibold",children:e.commission_amount>0?(0,t.jsx)("span",{className:"text-mingcare-green",children:R(e.commission_amount)}):(0,t.jsx)("span",{className:"text-text-secondary",children:"$0"})})]},`${e.customer_id}-${e.service_month}`))})]})}),(0,t.jsx)("div",{className:"sm:hidden space-y-3 p-3",children:e.customers.map((e,s)=>(0,t.jsxs)("div",{className:"bg-white border border-border-light rounded-xl p-3 space-y-2",children:[(0,t.jsxs)("div",{className:"flex justify-between items-start",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("div",{className:"font-medium text-text-primary text-sm",children:e.customer_name}),(0,t.jsx)("div",{className:"text-xs text-text-secondary",children:e.customer_id})]}),(0,t.jsx)("div",{className:"text-right",children:e.is_qualified?(0,t.jsx)("span",{className:`px-2 py-1 rounded text-xs font-medium ${1===e.month_sequence?"bg-blue-100 text-blue-800":"bg-green-100 text-green-800"}`,children:1===e.month_sequence?"首月":`第${e.month_sequence}月`}):(0,t.jsx)("span",{className:"px-2 py-1 rounded text-xs font-medium bg-red-100 text-red-800",children:"不達標"})})]}),(0,t.jsxs)("div",{className:"grid grid-cols-2 gap-2 text-xs",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("span",{className:"text-text-secondary",children:"服務月份："}),(0,t.jsx)("span",{className:"text-text-primary",children:D(e.service_month)})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("span",{className:"text-text-secondary",children:"服務時數："}),(0,t.jsxs)("span",{className:"text-text-primary",children:[e.monthly_hours.toFixed(1),"h"]})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("span",{className:"text-text-secondary",children:"服務費用："}),(0,t.jsx)("span",{className:"text-text-primary",children:R(e.monthly_fee)})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("span",{className:"text-text-secondary",children:"佣金金額："}),e.commission_amount>0?(0,t.jsx)("span",{className:"font-semibold text-mingcare-green",children:R(e.commission_amount)}):(0,t.jsx)("span",{className:"text-text-secondary",children:"$0"})]})]})]},`${e.customer_id}-${e.service_month}`))})]},e.introducer)})}),0===T.length&&!d&&(0,t.jsx)("div",{className:"card-apple fade-in-apple",children:(0,t.jsxs)("div",{className:"card-apple-content text-center py-12",children:[(0,t.jsx)("div",{className:"mx-auto w-16 h-16 bg-bg-tertiary rounded-full flex items-center justify-center mb-4",children:(0,t.jsx)("svg",{className:"h-8 w-8 text-text-tertiary",fill:"none",viewBox:"0 0 24 24",stroke:"currentColor",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:1.5,d:"M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"})})}),(0,t.jsx)("h3",{className:"text-lg font-semibold text-text-primary mb-2",children:"暫無符合條件的佣金數據"}),(0,t.jsx)("p",{className:"text-text-secondary",children:"請檢查是否有符合計算條件的客戶和服務記錄"})]})})]})]})}])},77768,e=>{"use strict";var t=e.i(43476),s=e.i(25164),a=e.i(16025);e.s(["f",0,function({message:e="載入中...",showProgress:r=!0}){return(0,t.jsxs)("div",{className:"loading-screen",children:[(0,t.jsx)("div",{className:"loading-bg-glow loading-bg-glow-1"}),(0,t.jsx)("div",{className:"loading-bg-glow loading-bg-glow-2"}),(0,t.jsx)("div",{className:"loading-bg-glow loading-bg-glow-3"}),(0,t.jsxs)("div",{className:"loading-logo-container",children:[(0,t.jsx)("div",{className:"loading-ring loading-ring-outer"}),(0,t.jsx)("div",{className:"loading-ring loading-ring-middle"}),(0,t.jsx)("div",{className:"loading-ring loading-ring-inner"}),(0,t.jsx)("div",{className:"loading-logo",children:(0,t.jsx)(s.default,{src:(0,a.f)("images/mingcare-logo.png"),alt:"明家護理服務",width:120,height:120,className:"loading-logo-image",priority:!0})}),(0,t.jsx)("div",{className:"loading-pulse"})]}),(0,t.jsxs)("div",{className:"loading-text-container",children:[(0,t.jsx)("h2",{className:"loading-title",children:"明家護理服務"}),(0,t.jsx)("p",{className:"loading-subtitle",children:"MingCare Intranet"}),r&&(0,t.jsxs)("div",{className:"loading-progress",children:[(0,t.jsx)("div",{className:"loading-progress-bar",children:(0,t.jsx)("div",{className:"loading-progress-fill"})}),(0,t.jsx)("p",{className:"loading-message",children:e})]})]}),(0,t.jsxs)("div",{className:"loading-dots",children:[(0,t.jsx)("span",{className:"loading-dot",style:{animationDelay:"0s"}}),(0,t.jsx)("span",{className:"loading-dot",style:{animationDelay:"0.2s"}}),(0,t.jsx)("span",{className:"loading-dot",style:{animationDelay:"0.4s"}})]})]})}])},37066,e=>{"use strict";async function t(e,s=500){if(!Number.isInteger(s)||s<1)throw Error("無效的分頁大小");let a=[];for(;;){let{data:t,error:r}=await e(a.length,a.length+s-1);if(r)throw Error(r.message||"載入資料失敗");if(!t?.length)return a;a.push(...t)}}e.s(["f",0,t])},70975,e=>{"use strict";e.i(47167);e.s(["h",0,function(){return null},"a",0,"preview@mingcare.local","q",0,!1,"J",0,"MingcarePreview2026!","D",0,function(e,t){return!1},"r",0,function(){sessionStorage.removeItem("mingcare_local_preview_user")}])},6085,e=>{"use strict";var t="u">typeof self?self:"u">typeof window?window:e.g;let s=t.fetch,a=t.fetch.bind(t),r=t.Headers,i=t.Request,n=t.Response;e.s(["Headers",0,r,"Request",0,i,"Response",0,n,"default",0,a,"fetch",0,s])},5500,(e,t,s)=>{"use strict";e.i(47167),Object.defineProperty(s,"__esModule",{value:!0}),Object.defineProperty(s,"Image",{enumerable:!0,get:function(){return y}});let a=e.r(55682),r=e.r(90809),i=e.r(43476),n=r._(e.r(71645)),l=a._(e.r(74080)),o=a._(e.r(25633)),c=e.r(8927),d=e.r(65856),m=e.r(49381),u=a._(e.r(1948)),p=e.r(18581);function h(e,t,s,a,r,i,n){let l=e?.src;e&&e["data-loaded-src"]!==l&&(e["data-loaded-src"]=l,("decode"in e?e.decode():Promise.resolve()).catch(()=>{}).then(()=>{if(e.parentElement&&e.isConnected){if("empty"!==t&&r(!0),s?.current){let t=new Event("load");Object.defineProperty(t,"target",{writable:!1,value:e});let a=!1,r=!1;s.current({...t,nativeEvent:t,currentTarget:e,target:e,isDefaultPrevented:()=>a,isPropagationStopped:()=>r,persist:()=>{},preventDefault:()=>{a=!0,t.preventDefault()},stopPropagation:()=>{r=!0,t.stopPropagation()}})}a?.current&&a.current(e)}}))}function x(e){return n.use?{fetchPriority:e}:{fetchpriority:e}}"u"<typeof window&&(globalThis.__NEXT_IMAGE_IMPORTED=!0);let f="u"<typeof window?n.useEffect:n.useLayoutEffect,g=(0,n.forwardRef)(({src:e,srcSet:t,sizes:s,height:a,width:r,decoding:l,className:o,style:c,fetchPriority:d,placeholder:m,loading:u,unoptimized:g,fill:b,onLoadRef:y,onLoadingCompleteRef:v,setBlurComplete:_,setShowAltText:j,sizesInput:N,onLoad:w,onError:$,...C},S)=>{let q=(0,n.useRef)(!1),P=(0,n.useRef)(null);f(()=>{let{current:e}=q,{current:t}=P;e||null===t||($&&(t.src=t.src),t.complete&&h(t,m,y,v,_,g,N),q.current=!0)},[e,m,y,v,$,g,N]);let k=(0,p.useMergedRef)(S,P);return(0,i.jsx)("img",{...C,...x(d),loading:u,width:r,height:a,decoding:l,"data-nimg":b?"fill":"1",className:o,style:c,sizes:s,srcSet:t,src:e,ref:k,onLoad:e=>{h(e.currentTarget,m,y,v,_,g,N)},onError:e=>{j(!0),"empty"!==m&&_(!0),$&&$(e)}})});function b({isAppRouter:e,imgAttributes:t}){let s={as:"image",imageSrcSet:t.srcSet,imageSizes:t.sizes,crossOrigin:t.crossOrigin,referrerPolicy:t.referrerPolicy,...x(t.fetchPriority)};return e&&l.default.preload?(l.default.preload(t.src,s),null):(0,i.jsx)(o.default,{children:(0,i.jsx)("link",{rel:"preload",href:t.srcSet?void 0:t.src,...s},"__nimg-"+t.src+t.srcSet+t.sizes)})}let y=(0,n.forwardRef)((e,t)=>{let s=(0,n.useContext)(d.RouterContext),a=(0,m.useImageConfig)(),{onLoad:r,onLoadingComplete:l}=e,o=(0,n.useRef)(r);(0,n.useEffect)(()=>{o.current=r},[r]);let p=(0,n.useRef)(l);(0,n.useEffect)(()=>{p.current=l},[l]);let[h,x]=(0,n.useState)(!1),[f,y]=(0,n.useState)(!1),{props:v,meta:_}=(0,c.getImgProps)(e,{defaultLoader:u.default,imgConf:a,blurComplete:h,showAltText:f});return(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(g,{...v,unoptimized:_.unoptimized,placeholder:_.placeholder,fill:_.fill,onLoadRef:o,onLoadingCompleteRef:p,setBlurComplete:x,setShowAltText:y,sizesInput:e.sizes,ref:t}),_.preload?(0,i.jsx)(b,{isAppRouter:!s,imgAttributes:v}):null]})});("function"==typeof s.default||"object"==typeof s.default&&null!==s.default)&&void 0===s.default.__esModule&&(Object.defineProperty(s.default,"__esModule",{value:!0}),Object.assign(s.default,s),t.exports=s.default)},25164,e=>{"use strict";var t=e.i(5500);e.s(["default",()=>t.Image])},49381,(e,t,s)=>{"use strict";e.i(47167),Object.defineProperty(s,"__esModule",{value:!0}),Object.defineProperty(s,"useImageConfig",{enumerable:!0,get:function(){return l}});let a=e.r(71645),r=e.r(87690),i=e.r(18556),n={deviceSizes:[640,750,828,1080,1200,1920,2048,3840],imageSizes:[32,48,64,96,128,256,384],qualities:[75,100],path:"/mingcare-intranet-test/_next/image/",loader:"default",dangerouslyAllowSVG:!1,unoptimized:!0};function l(){let e=(0,a.useContext)(i.ImageConfigContext);return(0,r.prepareImageConfig)(n,e)}("function"==typeof s.default||"object"==typeof s.default&&null!==s.default)&&void 0===s.default.__esModule&&(Object.defineProperty(s.default,"__esModule",{value:!0}),Object.assign(s.default,s),t.exports=s.default)},18581,(e,t,s)=>{"use strict";Object.defineProperty(s,"__esModule",{value:!0}),Object.defineProperty(s,"useMergedRef",{enumerable:!0,get:function(){return r}});let a=e.r(71645);function r(e,t){let s=(0,a.useRef)(null),r=(0,a.useRef)(null);return(0,a.useCallback)(a=>{if(null===a){let e=s.current;e&&(s.current=null,e());let t=r.current;t&&(r.current=null,t())}else e&&(s.current=i(e,a)),t&&(r.current=i(t,a))},[e,t])}function i(e,t){if("function"!=typeof e)return e.current=t,()=>{e.current=null};{let s=e(t);return"function"==typeof s?s:()=>e(null)}}("function"==typeof s.default||"object"==typeof s.default&&null!==s.default)&&void 0===s.default.__esModule&&(Object.defineProperty(s.default,"__esModule",{value:!0}),Object.assign(s.default,s),t.exports=s.default)},70965,(e,t,s)=>{"use strict";function a(e,t){let s=e||75;return t?.qualities?.length?t.qualities.reduce((e,t)=>Math.abs(t-s)<Math.abs(e-s)?t:e,t.qualities[0]):s}Object.defineProperty(s,"__esModule",{value:!0}),Object.defineProperty(s,"findClosestQuality",{enumerable:!0,get:function(){return a}})},8927,(e,t,s)=>{"use strict";e.i(47167),Object.defineProperty(s,"__esModule",{value:!0}),Object.defineProperty(s,"getImgProps",{enumerable:!0,get:function(){return o}});let a=e.r(43369),r=e.r(67423),i=["-moz-initial","fill","none","scale-down",void 0];function n(e){return void 0!==e.default}function l(e){return void 0===e?e:"number"==typeof e?Number.isFinite(e)?e:0/0:"string"==typeof e&&/^[0-9]+$/.test(e)?parseInt(e,10):0/0}function o({src:e,sizes:t,unoptimized:s=!1,priority:c=!1,preload:d=!1,loading:m,className:u,quality:p,width:h,height:x,fill:f=!1,style:g,overrideSrc:b,onLoad:y,onLoadingComplete:v,placeholder:_="empty",blurDataURL:j,fetchPriority:N,decoding:w="async",layout:$,objectFit:C,objectPosition:S,lazyBoundary:q,lazyRoot:P,...k},M){var E;let O,z,{imgConf:I,showAltText:R,blurComplete:D,defaultLoader:A}=M;if(void 0===A)throw Error("images.loaderFile detected but the file is missing default export.\nRead more: https://nextjs.org/docs/messages/invalid-images-config");let F=k.loader||A;delete k.loader,delete k.srcSet;let L="__next_img_default"in F;if(L){if("custom"===I.loader)throw Error(`Image with src "${e}" is missing "loader" prop.
Read more: https://nextjs.org/docs/messages/next-image-missing-loader`)}else{let e=F;F=t=>{let{config:s,...a}=t;return e(a)}}if($){"fill"===$&&(f=!0);let e={intrinsic:{maxWidth:"100%",height:"auto"},responsive:{width:"100%",height:"auto"}}[$];e&&(g={...g,...e});let s={responsive:"100vw",fill:"100vw"}[$];s&&!t&&(t=s)}let T="",W=l(h),U=l(x);if((E=e)&&"object"==typeof E&&(n(E)||void 0!==E.src)){let t=n(e)?e.default:e;if(!t.src)throw Error(`An object should only be passed to the image component src parameter if it comes from a static image import. It must include src. Received ${JSON.stringify(t)}`);if(!t.height||!t.width)throw Error(`An object should only be passed to the image component src parameter if it comes from a static image import. It must include height and width. Received ${JSON.stringify(t)}`);if(O=t.blurWidth,z=t.blurHeight,j=j||t.blurDataURL,T=t.src,!f)if(W||U){if(W&&!U){let e=W/t.width;U=Math.round(t.height*e)}else if(!W&&U){let e=U/t.height;W=Math.round(t.width*e)}}else W=t.width,U=t.height}let H=!c&&!d&&("lazy"===m||void 0===m);(!(e="string"==typeof e?e:T)||e.startsWith("data:")||e.startsWith("blob:"))&&(s=!0,H=!1),I.unoptimized&&(s=!0),L&&!I.dangerouslyAllowSVG&&e.split("?",1)[0].endsWith(".svg")&&(s=!0);let B=l(p),G=Object.assign(f?{position:"absolute",height:"100%",width:"100%",left:0,top:0,right:0,bottom:0,objectFit:C,objectPosition:S}:{},R?{}:{color:"transparent"},g),V=D||"empty"===_?null:"blur"===_?`url("data:image/svg+xml;charset=utf-8,${(0,r.getImageBlurSvg)({widthInt:W,heightInt:U,blurWidth:O,blurHeight:z,blurDataURL:j||"",objectFit:G.objectFit})}")`:`url("${_}")`,Q=i.includes(G.objectFit)?"fill"===G.objectFit?"100% 100%":"cover":G.objectFit,J=V?{backgroundSize:Q,backgroundPosition:G.objectPosition||"50% 50%",backgroundRepeat:"no-repeat",backgroundImage:V}:{},K=function({config:e,src:t,unoptimized:s,width:r,quality:i,sizes:n,loader:l}){if(s){if(t.startsWith("/")&&!t.startsWith("//")){let e=(0,a.getDeploymentId)();if(t.includes("/_next/static/immutable")&&!(0,a.getAssetToken)())e=void 0;else if(e){let s=t.indexOf("?");if(-1!==s){let a=new URLSearchParams(t.slice(s+1));a.get("dpl")||(a.append("dpl",e),t=t.slice(0,s)+"?"+a.toString())}else t+=`?dpl=${e}`}}return{src:t,srcSet:void 0,sizes:void 0}}let{widths:o,kind:c}=function({deviceSizes:e,allSizes:t},s,a){if(a){let s=/(^|\s)(1?\d?\d)vw/g,r=[];for(let e;e=s.exec(a);)r.push(parseInt(e[2]));if(r.length){let s=.01*Math.min(...r);return{widths:t.filter(t=>t>=e[0]*s),kind:"w"}}return{widths:t,kind:"w"}}return"number"!=typeof s?{widths:e,kind:"w"}:{widths:[...new Set([s,2*s].map(e=>t.find(t=>t>=e)||t[t.length-1]))],kind:"x"}}(e,r,n),d=o.length-1;return{sizes:n||"w"!==c?n:"100vw",srcSet:o.map((s,a)=>`${l({config:e,src:t,quality:i,width:s})} ${"w"===c?s:a+1}${c}`).join(", "),src:l({config:e,src:t,quality:i,width:o[d]})}}({config:I,src:e,unoptimized:s,width:W,quality:B,sizes:t,loader:F}),Y=H?"lazy":m;return{props:{...k,loading:Y,fetchPriority:N,width:W,height:U,decoding:w,className:u,style:{...G,...J},sizes:K.sizes,srcSet:K.srcSet,src:b||K.src},meta:{unoptimized:s,preload:d||c,placeholder:_,fill:f}}}},25633,(e,t,s)=>{"use strict";e.i(47167),Object.defineProperty(s,"__esModule",{value:!0});var a={default:function(){return x},defaultHead:function(){return m}};for(var r in a)Object.defineProperty(s,r,{enumerable:!0,get:a[r]});let i=e.r(55682),n=e.r(90809),l=e.r(43476),o=n._(e.r(71645)),c=i._(e.r(98879)),d=e.r(42732);function m(){return[(0,l.jsx)("meta",{charSet:"utf-8"},"charset"),(0,l.jsx)("meta",{name:"viewport",content:"width=device-width"},"viewport")]}function u(e,t){return"string"==typeof t||"number"==typeof t?e:t.type===o.default.Fragment?e.concat(o.default.Children.toArray(t.props.children).reduce((e,t)=>"string"==typeof t||"number"==typeof t?e:e.concat(t),[])):e.concat(t)}let p=["name","httpEquiv","charSet","itemProp"];function h(e){let t,s,a,r;return e.reduce(u,[]).reverse().concat(m().reverse()).filter((t=new Set,s=new Set,a=new Set,r={},e=>{let i=!0,n=!1;if(e.key&&"number"!=typeof e.key&&e.key.indexOf("$")>0){n=!0;let s=e.key.slice(e.key.indexOf("$")+1);t.has(s)?i=!1:t.add(s)}switch(e.type){case"title":case"base":s.has(e.type)?i=!1:s.add(e.type);break;case"meta":for(let t=0,s=p.length;t<s;t++){let s=p[t];if(e.props.hasOwnProperty(s))if("charSet"===s)a.has(s)?i=!1:a.add(s);else{let t=e.props[s],a=r[s]||new Set;("name"!==s||!n)&&a.has(t)?i=!1:(a.add(t),r[s]=a)}}}return i})).reverse().map((e,t)=>{let s=e.key||t;return o.default.cloneElement(e,{key:s})})}let x=function({children:e}){let t=(0,o.useContext)(d.HeadManagerContext);return(0,l.jsx)(c.default,{reduceComponentsToState:h,headManager:t,children:e})};("function"==typeof s.default||"object"==typeof s.default&&null!==s.default)&&void 0===s.default.__esModule&&(Object.defineProperty(s.default,"__esModule",{value:!0}),Object.assign(s.default,s),t.exports=s.default)},67423,(e,t,s)=>{"use strict";function a({widthInt:e,heightInt:t,blurWidth:s,blurHeight:r,blurDataURL:i,objectFit:n}){let l=s?40*s:e,o=r?40*r:t,c=l&&o?`viewBox='0 0 ${l} ${o}'`:"";return`%3Csvg xmlns='http://www.w3.org/2000/svg' ${c}%3E%3Cfilter id='b' color-interpolation-filters='sRGB'%3E%3CfeGaussianBlur stdDeviation='20'/%3E%3CfeColorMatrix values='1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 100 -1' result='s'/%3E%3CfeFlood x='0' y='0' width='100%25' height='100%25'/%3E%3CfeComposite operator='out' in='s'/%3E%3CfeComposite in2='SourceGraphic'/%3E%3CfeGaussianBlur stdDeviation='20'/%3E%3C/filter%3E%3Cimage width='100%25' height='100%25' x='0' y='0' preserveAspectRatio='${c?"none":"contain"===n?"xMidYMid":"cover"===n?"xMidYMid slice":"none"}' style='filter: url(%23b);' href='${i}'/%3E%3C/svg%3E`}Object.defineProperty(s,"__esModule",{value:!0}),Object.defineProperty(s,"getImageBlurSvg",{enumerable:!0,get:function(){return a}})},18556,(e,t,s)=>{"use strict";e.i(47167),Object.defineProperty(s,"__esModule",{value:!0}),Object.defineProperty(s,"ImageConfigContext",{enumerable:!0,get:function(){return i}});let a=e.r(55682)._(e.r(71645)),r=e.r(87690),i=a.default.createContext(r.imageConfigDefault)},87690,(e,t,s)=>{"use strict";Object.defineProperty(s,"__esModule",{value:!0});var a={VALID_LOADERS:function(){return i},imageConfigDefault:function(){return c},prepareImageConfig:function(){return o}};for(var r in a)Object.defineProperty(s,r,{enumerable:!0,get:a[r]});let i=["default","imgix","cloudinary","akamai","custom"],n={},l=new WeakMap;function o(e,t){let s=e??n,a=t??n,r=l.get(s);if(r){let e=r.get(a);if(e)return e}let i=e||t||c,o=[...i.deviceSizes].sort((e,t)=>e-t),d=[...i.imageSizes],m={deviceSizes:o,imageSizes:d,allSizes:[...o,...d].sort((e,t)=>e-t),qualities:void 0===i.qualities?void 0:[...i.qualities].sort((e,t)=>e-t),path:i.path,loader:i.loader,dangerouslyAllowSVG:i.dangerouslyAllowSVG,unoptimized:i.unoptimized,domains:i.domains,remotePatterns:i.remotePatterns,localPatterns:"u"<typeof window&&void 0!==t?t.localPatterns:i.localPatterns,output:i.output};return r||(r=new WeakMap,l.set(s,r)),r.set(a,m),m}let c={deviceSizes:[640,750,828,1080,1200,1920,2048,3840],imageSizes:[32,48,64,96,128,256,384],path:"/_next/image",loader:"default",loaderFile:"",domains:[],disableStaticImages:!1,minimumCacheTTL:14400,formats:["image/webp"],maximumDiskCacheSize:void 0,maximumRedirects:3,maximumResponseBody:5e7,dangerouslyAllowLocalIP:!1,dangerouslyAllowSVG:!1,contentSecurityPolicy:"script-src 'none'; frame-src 'none'; sandbox;",contentDispositionType:"attachment",localPatterns:void 0,remotePatterns:[],qualities:[75],unoptimized:!1,customCacheHandler:!1}},1948,(e,t,s)=>{"use strict";e.i(47167),Object.defineProperty(s,"__esModule",{value:!0}),Object.defineProperty(s,"default",{enumerable:!0,get:function(){return n}});let a=e.r(70965),r=e.r(43369);function i({config:e,src:t,width:s,quality:n}){let l=(0,r.getDeploymentId)();if(t.startsWith("/")&&!t.startsWith("//"))if(t.includes("/_next/static/immutable")&&!(0,r.getAssetToken)())l=void 0;else{let e=t.indexOf("?");if(-1!==e){let s=new URLSearchParams(t.slice(e+1)),a=s.get("dpl");if(a){l=a,s.delete("dpl");let r=s.toString();t=t.slice(0,e)+(r?"?"+r:"")}}}if(t.startsWith("/")&&t.includes("?")&&e.localPatterns?.length===1&&"**"===e.localPatterns[0].pathname&&""===e.localPatterns[0].search)throw Error(`Image with src "${t}" is using a query string which is not configured in images.localPatterns.
Read more: https://nextjs.org/docs/messages/next-image-unconfigured-localpatterns`);let o=(0,a.findClosestQuality)(n,e);return`${e.path}?url=${encodeURIComponent(t)}&w=${s}&q=${o}${t.startsWith("/")&&l?`&dpl=${l}`:""}`}i.__next_img_default=!0;let n=i},65856,(e,t,s)=>{"use strict";e.i(47167),Object.defineProperty(s,"__esModule",{value:!0}),Object.defineProperty(s,"RouterContext",{enumerable:!0,get:function(){return a}});let a=(e.r(55682)._(e.r(71645))).default.createContext(null)},98879,(e,t,s)=>{"use strict";Object.defineProperty(s,"__esModule",{value:!0}),Object.defineProperty(s,"default",{enumerable:!0,get:function(){return l}});let a=e.r(71645),r="u"<typeof window,i=r?()=>{}:a.useLayoutEffect,n=r?()=>{}:a.useEffect;function l(e){let{headManager:t,reduceComponentsToState:s}=e;function l(){if(t&&t.mountedInstances){let e=a.Children.toArray(Array.from(t.mountedInstances).filter(Boolean));t.updateHead(s(e))}}return r&&(t?.mountedInstances?.add(e.children),l()),i(()=>(t?.mountedInstances?.add(e.children),()=>{t?.mountedInstances?.delete(e.children)})),i(()=>(t&&(t._pendingUpdate=l),()=>{t&&(t._pendingUpdate=l)})),n(()=>(t&&t._pendingUpdate&&(t._pendingUpdate(),t._pendingUpdate=null),()=>{t&&t._pendingUpdate&&(t._pendingUpdate(),t._pendingUpdate=null)})),null}},18566,(e,t,s)=>{t.exports=e.r(76562)},16025,e=>{"use strict";e.i(47167),e.s(["f",0,function(e){let t="/mingcare-intranet-test".trim().replace(/\/+$/,"")||"",s=e.startsWith("/")?e:`/${e}`;return!t||s===t||s.startsWith(`${t}/`)?s:`${t}${s}`}])}]);