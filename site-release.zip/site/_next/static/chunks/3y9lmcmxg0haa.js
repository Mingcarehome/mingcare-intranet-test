(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,64069,e=>{"use strict";var t=e.i(43476),r=e.i(74431),a=e.i(44342),s=e.i(17927);async function l(){let{data:e,error:t}=await s.supabase.storage.from("care-staff-files").download("care-staff/system-assets/company-stamp.png");if(t||!e||e.size>2097152)throw Error("未能讀取私人公司印章，請檢查登入權限");let r=new Uint8Array(await e.arrayBuffer());if(![137,80,78,71,13,10,26,10].every((e,t)=>r[t]===e))throw Error("公司印章格式無效");let a="";for(let e=0;e<r.length;e+=32768)a+=String.fromCharCode(...r.subarray(e,e+32768));return`data:image/png;base64,${btoa(a)}`}var n=e.i(71645),o=e.i(759),i=e.i(37066),d=e.i(74080),c=e.i(18566),m=e.i(16025),x=e.i(77768);let p=({careStaffList:e,value:r,onChange:a,loading:s=!1,placeholder:l="選擇護理人員",className:o=""})=>{let[i,d]=(0,n.useState)(!1),[c,m]=(0,n.useState)(""),x=i?c:r,p=(0,n.useRef)(null),u=(0,n.useRef)(null),h=e.filter(e=>e.name_chinese.toLowerCase().includes(c.toLowerCase()));(0,n.useEffect)(()=>{let e=e=>{p.current&&!p.current.contains(e.target)&&(d(!1),m(""))};return document.addEventListener("mousedown",e),()=>document.removeEventListener("mousedown",e)},[]);let g=()=>{a(""),m(""),d(!1)};return(0,t.jsxs)("div",{className:`relative ${o}`,ref:p,children:[(0,t.jsxs)("div",{className:"relative",children:[(0,t.jsx)("input",{ref:u,type:"text",value:i?c:x,onChange:e=>{m(e.target.value),d(!0)},onFocus:()=>{d(!0),m(x)},placeholder:s?"載入中...":l,disabled:s,className:"w-full px-4 py-2.5 border border-border-light rounded-xl focus:ring-2 focus:ring-primary/30 focus:border-primary bg-bg-secondary text-sm transition-all duration-300 pr-20"}),x&&(0,t.jsx)("button",{type:"button",onClick:g,className:"absolute right-8 top-1/2 transform -translate-y-1/2 w-4 h-4 text-text-secondary hover:text-text-primary transition-colors",children:(0,t.jsx)("svg",{fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M6 18L18 6M6 6l12 12"})})}),(0,t.jsx)("svg",{className:"absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-text-secondary pointer-events-none",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M19 9l-7 7-7-7"})})]}),i&&(0,t.jsx)("div",{className:"absolute top-full left-0 right-0 mt-1 bg-bg-primary border border-border-light rounded-xl shadow-xl z-[100] max-h-60 overflow-y-auto",children:s?(0,t.jsx)("div",{className:"px-4 py-3 text-text-secondary text-sm",children:"載入中..."}):0===h.length?(0,t.jsx)("div",{className:"px-4 py-3 text-text-secondary text-sm",children:c?"未找到匹配的護理人員":"沒有可選的護理人員"}):(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("div",{className:"px-4 py-3 cursor-pointer hover:bg-bg-secondary text-text-secondary border-b border-border-light transition-colors text-sm",onClick:g,children:(0,t.jsx)("span",{className:"italic",children:"清除選擇"})}),h.map((e,s)=>{let l=e.name_chinese===r;return(0,t.jsxs)("div",{className:`px-4 py-3 cursor-pointer hover:bg-bg-secondary flex items-center justify-between transition-colors text-sm ${l?"bg-primary/5 text-primary":"text-text-primary"}`,onClick:()=>{a(e.name_chinese),m(""),d(!1)},children:[(0,t.jsx)("span",{children:e.name_chinese}),l&&(0,t.jsx)("svg",{className:"w-4 h-4 text-primary",fill:"currentColor",viewBox:"0 0 20 20",children:(0,t.jsx)("path",{fillRule:"evenodd",d:"M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z",clipRule:"evenodd"})})]},s)})]})})]})};var u=e.i(3548);let h=[{value:"Kanas Leung",label:"Kanas Leung"},{value:"Joe Cheung",label:"Joe Cheung"},{value:"Candy Ho",label:"Candy Ho"},{value:"Tracy Yau",label:"Tracy Yau"},{value:"Steven Kwok",label:"Steven Kwok"},{value:"Dr.Lee",label:"Dr.Lee"},{value:"Annie",label:"Annie"},{value:"Janet",label:"Janet"},{value:"raymond",label:"raymond"},{value:"陸sir",label:"陸sir"},{value:"吳翹政",label:"吳翹政"},{value:"余翠英",label:"余翠英"},{value:"陳小姐MC01",label:"陳小姐MC01"},{value:"曾先生",label:"曾先生"},{value:"梁曉峰",label:"梁曉峰"}],g=[{value:"ES-護送服務(陪診)",label:"ES-護送服務(陪診)"},{value:"FD-送飯服務",label:"FD-送飯服務"},{value:"HC-家居服務",label:"HC-家居服務"},{value:"NA-護理服務（輔助人員）",label:"NA-護理服務（輔助人員）"},{value:"NC-護理服務(專業⼈員)",label:"NC-護理服務(專業⼈員)"},{value:"PC-到⼾看顧(輔助⼈員)",label:"PC-到⼾看顧(輔助⼈員)"},{value:"RA-復康運動(輔助⼈員)",label:"RA-復康運動(輔助⼈員)"},{value:"RT-復康運動(OTA輔助⼈員)",label:"RT-復康運動(OTA輔助⼈員)"},{value:"RT-復康運動(專業⼈員)",label:"RT-復康運動(專業⼈員)"},{value:"上門評估服務",label:"上門評估服務"},{value:"傷口護理",label:"傷口護理"},{value:"免費服務體驗",label:"免費服務體驗"},{value:"外傭培訓服務",label:"外傭培訓服務"},{value:"新員工培訓課師",label:"新員工培訓課師"},{value:"社區活動",label:"社區活動"},{value:"認知障礙訓練",label:"認知障礙訓練"},{value:"介紹人獎金(一)",label:"介紹人獎金(一)"},{value:"介紹人獎金(二)",label:"介紹人獎金(二)"},{value:"介紹人獎金(三)",label:"介紹人獎金(三)"},{value:"介紹人獎金(四)",label:"介紹人獎金(四)"}],f=[{value:"MC社區券(醫點）",label:"MC社區券(醫點）"},{value:"MC街客",label:"MC街客"},{value:"Steven140",label:"Steven140"},{value:"Steven200",label:"Steven200"},{value:"Steven醫點",label:"Steven醫點"},{value:"俊佳",label:"俊佳"},{value:"安心同行",label:"安心同行"},{value:"卓力醫療",label:"卓力醫療"}],b=[{value:"Candy Ho",label:"Candy Ho"},{value:"Joe Cheung",label:"Joe Cheung"},{value:"Kanas Leung",label:"Kanas Leung"},{value:"Tracy Yau",label:"Tracy Yau"}],v=["社區券客戶","明家街客","家訪客戶"];function y(e){return Math.round(100*e)/100}function _(e){let[t,r,a]=e.split("-").map(Number);return new Date(t,r-1,a)}function j(e){let t=e.getFullYear(),r=String(e.getMonth()+1).padStart(2,"0"),a=String(e.getDate()).padStart(2,"0");return`${t}-${r}-${a}`}function N(e){return e?Array.isArray(e)?e:[e]:[]}async function w(e,t=1,r=50){try{let a=null;if(e.introducer&&(a=(await (0,i.f)((t,r)=>s.supabase.from("customer_personal_data").select("customer_id").eq("introducer",e.introducer).order("id").range(t,r))||[]).map(e=>e.customer_id).filter(e=>null!=e))&&0===a.length)return{success:!0,data:{data:[],total:0,page:t,pageSize:r,totalPages:0}};let l=s.supabase.from("billing_salary_data").select("*",{count:"exact"});e.dateRange.start&&e.dateRange.end&&(l=l.gte("service_date",e.dateRange.start).lte("service_date",e.dateRange.end)),e.serviceType&&(l=l.eq("service_type",e.serviceType));let n=N(e.projectCategory);if(n.length>0&&(l=l.in("project_category",n)),e.projectManager&&(l=l.eq("project_manager",e.projectManager)),e.careStaffName&&(l=l.ilike("care_staff_name",`%${e.careStaffName}%`)),a&&a.length>0)if(e.selectedCustomerIds&&e.selectedCustomerIds.length>0){let s=e.selectedCustomerIds.filter(e=>a.includes(e));if(0===s.length)return{success:!0,data:{data:[],total:0,page:t,pageSize:r,totalPages:0}};l=l.in("customer_id",s)}else l=l.in("customer_id",a);else e.selectedCustomerIds&&e.selectedCustomerIds.length>0?l=l.in("customer_id",e.selectedCustomerIds):e.searchTerm&&e.searchTerm.length>=2&&(l=l.or(`customer_name.ilike.%${e.searchTerm}%,phone.ilike.%${e.searchTerm}%,customer_id.ilike.%${e.searchTerm}%`));let o=(t-1)*r,{data:d,error:c,count:m}=await l.order("service_date",{ascending:!1}).order("start_time",{ascending:!0}).order("id",{ascending:!0}).range(o,o+r-1);if(c)return console.error("Error fetching billing salary records:",c),{success:!1,error:c.message};let x=(d||[]).map(e=>({...e,profit:(e.service_fee||0)-(e.staff_salary||0)}));return{success:!0,data:{data:x,total:m||0,page:t,pageSize:r,totalPages:Math.ceil((m||0)/r)}}}catch(e){return console.error("Error in fetchBillingSalaryRecords:",e),{success:!1,error:e instanceof Error?e.message:"獲取記錄時發生錯誤"}}}async function k(e){try{let t=null;if(e.introducer&&(t=(await (0,i.f)((t,r)=>s.supabase.from("customer_personal_data").select("customer_id").eq("introducer",e.introducer).order("id").range(t,r))||[]).map(e=>e.customer_id).filter(e=>null!=e))&&0===t.length)return{success:!0,data:[],message:"該介紹人沒有相關客戶記錄"};let r=[],a=0,l=!0;for(;l;){let n=a,o=n+1e3-1,i=s.supabase.from("billing_salary_data").select("*");e.dateRange.start&&e.dateRange.end&&(i=i.gte("service_date",e.dateRange.start).lte("service_date",e.dateRange.end)),e.serviceType&&(i=i.eq("service_type",e.serviceType));let d=N(e.projectCategory);if(d.length>0&&(i=i.in("project_category",d)),e.projectManager&&(i=i.eq("project_manager",e.projectManager)),e.careStaffName&&(i=i.ilike("care_staff_name",`%${e.careStaffName}%`)),t&&t.length>0)if(e.selectedCustomerIds&&e.selectedCustomerIds.length>0){let r=e.selectedCustomerIds.filter(e=>t.includes(e));if(0===r.length)return{success:!0,data:[],message:"沒有符合條件的記錄"};i=i.in("customer_id",r)}else i=i.in("customer_id",t);else e.selectedCustomerIds&&e.selectedCustomerIds.length>0?i=i.in("customer_id",e.selectedCustomerIds):e.searchTerm&&e.searchTerm.length>=2&&(i=i.or(`customer_name.ilike.%${e.searchTerm}%,phone.ilike.%${e.searchTerm}%,customer_id.ilike.%${e.searchTerm}%`));let{data:c,error:m}=await i.order("service_date",{ascending:!1}).order("start_time",{ascending:!0}).order("id",{ascending:!0}).order("id",{ascending:!0}).range(n,o);if(m)throw console.error("Error fetching records:",m),m;c&&c.length>0?(r=r.concat(c),l=!0,a+=c.length,console.log(`已獲取 ${r.length} 條記錄...`)):l=!1}let n=r.map(e=>({...e,profit:(e.service_fee||0)-(e.staff_salary||0)}));return{success:!0,data:n,message:`成功獲取 ${n.length} 條記錄`}}catch(e){return console.error("Error in fetchAllBillingSalaryRecords:",e),{success:!1,error:e instanceof Error?e.message:"獲取所有記錄時發生錯誤"}}}async function $(e,t){try{let{data:r,error:a}=await s.supabase.rpc("save_service_schedule_batch",{p_request_key:e,p_records:t});if(a)throw a;return{success:!0,data:r}}catch(e){return{success:!1,error:e instanceof Error?e.message:"儲存排程失敗，請重試"}}}async function S(e,t){try{console.log("🔄 updateBillingSalaryRecord 開始:",{id:e,formData:t});let{data:r,error:a}=await s.supabase.from("billing_salary_data").update(t).eq("id",e).select().single();if(console.log("🔄 updateBillingSalaryRecord 查詢結果:",{data:r,error:a}),a)return console.error("❌ 更新記錄錯誤:",a),{success:!1,error:a.message};return{success:!0,data:r,message:"記錄更新成功"}}catch(e){return console.error("❌ updateBillingSalaryRecord 異常:",e),{success:!1,error:e instanceof Error?e.message:"更新記錄時發生錯誤"}}}async function C(e){try{console.log("🗑️ deleteBillingSalaryRecord 開始:",e);let{error:t}=await s.supabase.from("billing_salary_data").delete().eq("id",e);if(console.log("🗑️ deleteBillingSalaryRecord 查詢結果:",{error:t}),t)return console.error("❌ 刪除記錄錯誤:",t),{success:!1,error:t.message};return{success:!0,message:"記錄刪除成功"}}catch(e){return console.error("❌ deleteBillingSalaryRecord 異常:",e),{success:!1,error:e instanceof Error?e.message:"刪除記錄時發生錯誤"}}}async function D(e){try{console.log("🔍 業務概覽 KPI 計算開始:",{dateRange:e,startDate:e.start,endDate:e.end});let t=async()=>{let t=[],r=0,a=!0;for(;a;){let l=r,n=l+1e3-1,{data:o,error:i}=await s.supabase.from("billing_salary_data").select("service_fee, staff_salary, service_hours").gte("service_date",e.start).lte("service_date",e.end).order("id",{ascending:!0}).range(l,n);if(i)throw Error(i.message);o&&o.length>0?(t=t.concat(o),a=!0,r+=o.length):a=!1}return t},{count:r,error:a}=await s.supabase.from("billing_salary_data").select("*",{count:"exact",head:!0}).gte("service_date",e.start).lte("service_date",e.end);if(a)return console.error("❌ 查詢總記錄數錯誤:",a),{success:!1,error:a.message};let l=await t();console.log("📊 查詢結果:",{recordCount:l?.length||0,totalCount:r||0,isComplete:(l?.length||0)===(r||0),dateRange:`${e.start} ~ ${e.end}`,sampleRecords:l?.slice(0,3)||[]}),console.log(`✅ 數據完整性檢查: 獲取 ${l?.length||0} / ${r||0} 筆記錄 ${(l?.length||0)===(r||0)?"✅ 完整":"❌ 不完整"}`);let n=_(e.start),o=_(e.end),i=new Date(n.getFullYear(),n.getMonth()-1,n.getDate()),d=new Date(o.getFullYear(),o.getMonth()-1,o.getDate()),c=async()=>{let e=[],t=0,r=!0;for(;r;){let a=t,l=a+1e3-1,{data:n,error:o}=await s.supabase.from("billing_salary_data").select("service_fee, staff_salary, service_hours").gte("service_date",j(i)).lte("service_date",j(d)).order("id",{ascending:!0}).range(a,l);if(o)return console.warn("Error getting last month data:",o),[];n&&n.length>0?(e=e.concat(n),r=!0,t+=n.length):r=!1}return e},m=await c(),x=y(l?.reduce((e,t)=>e+(t.service_fee||0),0)||0),p=y(l?.reduce((e,t)=>e+(t.staff_salary||0),0)||0),u=y(x-p),h=y(l?.reduce((e,t)=>e+(t.service_hours||0),0)||0),g=h>0?y(u/h):0;console.log("💰 KPI 計算結果:",{recordCount:l?.length||0,totalRevenue:x.toLocaleString(),totalStaffSalary:p.toLocaleString(),totalProfit:u.toLocaleString(),totalServiceHours:h.toFixed(1),avgProfitPerHour:g.toFixed(2)});let f=y(m?.reduce((e,t)=>e+(t.service_fee||0),0)||0),b=f>0?(x-f)/f*100:100*(x>0);return console.log("KPI Debug:",{currentPeriod:`${e.start} to ${e.end}`,lastMonthPeriod:`${j(i)} to ${j(d)}`,currentRecords:l?.length||0,lastMonthRecords:m?.length||0,totalRevenue:x,lastMonthRevenue:f,revenueGrowthRate:b}),{success:!0,data:{totalRevenue:x,totalProfit:u,totalServiceHours:h,avgProfitPerHour:g,revenueGrowthRate:b}}}catch(e){return console.error("Error in getBusinessKPI:",e),{success:!1,error:e instanceof Error?e.message:"獲取 KPI 時發生錯誤"}}}async function M(e){try{console.log("📊 項目分類統計開始:",{dateRange:e,startDate:e.start,endDate:e.end});let{count:t,error:r}=await s.supabase.from("billing_salary_data").select("*",{count:"exact",head:!0}).gte("service_date",e.start).lte("service_date",e.end);r?console.error("❌ 查詢總記錄數錯誤:",r):console.log(`📈 日期範圍內總記錄數: ${t}`);let a=async()=>{let t=[],r=0,a=!0;for(;a;){let l=r,n=l+1e3-1,{data:o,error:i}=await s.supabase.from("billing_salary_data").select("project_category, service_fee, staff_salary, service_hours, customer_name, service_date").gte("service_date",e.start).lte("service_date",e.end).order("id",{ascending:!0}).range(l,n);if(i)throw Error(i.message);o&&o.length>0?(t=t.concat(o),console.log(`📦 第 ${r+1} 批: 獲取 ${o.length} 筆記錄，累計 ${t.length} 筆`),a=!0,r+=o.length):a=!1}return t},l=await a();console.log(`✅ 數據完整性檢查: 獲取 ${l.length} / ${t||"unknown"} 筆記錄`);let n=new Map,o=new Map;l.forEach(e=>{let t=e.project_category;if(!t)return;let r=n.get(t)||{category:t,totalFee:0,totalHours:0,totalProfit:0,recordCount:0,uniqueCustomers:0};r.totalFee=y(r.totalFee+(e.service_fee||0)),r.totalHours=y(r.totalHours+(e.service_hours||0)),r.totalProfit=y(r.totalProfit+(e.service_fee||0)-(e.staff_salary||0)),r.recordCount+=1,n.set(t,r),o.has(t)||o.set(t,new Set),e.customer_name&&o.get(t)?.add(e.customer_name)}),n.forEach((e,t)=>{e.uniqueCustomers=o.get(t)?.size||0});let i=Array.from(n.values()).sort((e,t)=>t.totalFee-e.totalFee);return console.log("📊 項目分類統計結果:"),i.forEach(e=>{console.log(`  - ${e.category}: ${e.recordCount} 筆, $${e.totalFee.toLocaleString()}, ${e.totalHours.toFixed(1)}h, ${e.uniqueCustomers} 位客戶`)}),{success:!0,data:i}}catch(e){return console.error("Error in getProjectCategorySummary:",e),{success:!1,error:e instanceof Error?e.message:"獲取項目分類統計時發生錯誤"}}}async function F(){try{let{data:e,error:t}=await s.supabase.from("care_staff_profiles").select("name_chinese").not("name_chinese","is",null).order("name_chinese");if(t)throw t;let r=(e||[]).map(e=>e.name_chinese).filter(e=>e&&"string"==typeof e&&e.trim().length>0),a=Array.from(new Set(r)).map(e=>({name_chinese:e}));return{success:!0,data:a}}catch(e){return console.error("獲取護理人員列表失敗:",e),{success:!1,error:e instanceof Error?e.message:"獲取護理人員列表失敗"}}}function z(e,t,r){let a=e.filter(e=>e.service_type===t).sort((e,t)=>t.effective_date.localeCompare(e.effective_date));if(!r)return a[0]?.service_rate||0;let s=a.find(e=>e.effective_date<=r);return s?.service_rate||a[a.length-1]?.service_rate||0}async function L(){try{let{data:e,error:t}=await s.supabase.from("voucher_rate").select("*").order("service_type",{ascending:!0}).order("effective_date",{ascending:!1});if(t)throw t;return{success:!0,data:e||[]}}catch(e){return console.error("獲取社區券費率失敗:",e),{success:!1,error:e instanceof Error?e.message:"獲取社區券費率失敗"}}}async function R(e){try{let t=await L();if(!t.success||!t.data)throw Error("無法獲取社區券費率");let r=t.data,a=await w(e,1,5e4);if(!a.success||!a.data)throw Error("無法獲取服務記錄");let s=a.data.data,l=new Map;s.forEach(e=>{let t=e.service_type,a=e.service_hours||0,s=z(r,t,e.service_date);l.has(t)||l.set(t,{count:0,total_hours:0,total_amount:0});let n=l.get(t);n.count+=1,n.total_hours+=a,n.total_amount+=Math.round(a*s*100)/100});let n=Array.from(l.entries()).map(([e,t])=>{let a=s.find(t=>t.service_type===e)?.service_date,l=z(r,e,a);return{service_type:e,count:t.count,total_hours:t.total_hours,total_rate:l,total_amount:Math.round(100*t.total_amount)/100}}).sort((e,t)=>e.service_type.localeCompare(t.service_type)),o={total_count:n.reduce((e,t)=>e+t.count,0),total_hours:Math.round(100*n.reduce((e,t)=>e+t.total_hours,0))/100,total_amount:Math.round(100*n.reduce((e,t)=>e+t.total_amount,0))/100};return{success:!0,data:{serviceTypeSummary:n,grandTotal:o}}}catch(e){return console.error("計算社區券統計失敗:",e),{success:!1,error:e instanceof Error?e.message:"計算社區券統計失敗"}}}async function T(e){try{var t,r;let a=e.format??"pdf";console.log("🚀 開始導出日曆，格式:",a,"選項:",e);let l=await E(e.filters);if(!l.success||!l.data)return{success:!1,error:l.error||"無法獲取排班數據"};let n=(t=l.data,r=e,t.map((e,t)=>{let a=new Date(e.service_date),s=e.start_time||"09:00",l=e.end_time||"17:00",n=new Date(a),[o,i]=s.split(":").map(Number);n.setHours(o,i,0,0);let d=new Date(a),[c,m]=l.split(":").map(Number);d.setHours(c,m,0,0);let x=`${e.customer_name} - ${e.service_type}`;r.includeStaffDetails&&e.care_staff_name&&(x+=` (${e.care_staff_name})`);let p=`服務類型: ${e.service_type}
`;return p+=`客戶: ${e.customer_name}
`,r.includeStaffDetails&&e.care_staff_name&&(p+=`護理員: ${e.care_staff_name}
`),r.includeCustomerDetails&&(e.customer_id&&(p+=`客戶編號: ${e.customer_id}
`),e.phone&&(p+=`聯絡電話: ${e.phone}
`)),e.service_hours&&(p+=`服務時數: ${e.service_hours} 小時
`),e.project_category&&(p+=`所屬項目: ${e.project_category}
`),e.project_manager&&(p+=`項目經理: ${e.project_manager}
`),{uid:`mingcare-${e.id||t}-${Date.now()}@mingcarehome.com`,title:x,description:p.trim(),startDate:n,endDate:d,location:e.service_address||void 0,categories:[e.project_category||"護理服務",e.service_type||"一般服務"],organizer:e.project_manager||"MingCare",attendees:e.care_staff_name?[e.care_staff_name]:void 0}})),o=new Map;if(!e.filters.careStaffName){let e=Array.from(new Set(l.data.map(e=>e.customer_id).filter(e=>!!e)));if(e.length>0){let t=await (0,i.f)((t,r)=>s.supabase.from("customer_personal_data").select("customer_id, voucher_number").in("customer_id",e).order("id").range(t,r));t&&t.forEach(e=>{o.set(e.customer_id,{voucher_number:e.voucher_number||""})})}}return function(e,t,r,a=new Map){try{let s=[...t].sort((e,t)=>{let r=new Date(e.service_date).getTime()-new Date(t.service_date).getTime();if(0!==r)return r;let a=(e.start_time||"").localeCompare(t.start_time||"");return 0!==a?a:(e.customer_name||"").localeCompare(t.customer_name||"")}),l=e=>{if(!e)return"—";let[t,r]=e.split(":");return`${t}:${r}`},n=r.filters,o=n.dateRange?.start&&n.dateRange?.end?`${n.dateRange.start} 至 ${n.dateRange.end}`:"未指定日期範圍",i=(()=>{if(n.dateRange?.start){let e=new Date(n.dateRange.start);if(!Number.isNaN(e.getTime()))return e}if(s.length>0){let e=new Date(s[0].service_date);if(!Number.isNaN(e.getTime()))return e}return new Date})(),d=`${i.getFullYear()}年${String(i.getMonth()+1).padStart(2,"0")}月`,c=Array.from(new Set(s.map(e=>e.customer_name).filter(e=>!!e))),m=Array.from(new Set(s.map(e=>e.care_staff_name).filter(e=>!!e))),x="staff"===r.nameMode,p=0===c.length?"全部客戶":1===c.length?c[0]:`${c[0]} 等 ${c.length} 位客戶`,u=x?r.selectedStaffName||(1===m.length?m[0]:`${m[0]||"護理員"} 等 ${m.length} 位護理員`):"",h=s.find(e=>e.customer_name)||s[0],g=h?.customer_name||"全部客戶",f=h?.customer_id||"無編號",b=s.reduce((e,t)=>e+(t.service_hours||0),0),v=x?[u,p,o]:[p,o];if(n.careStaffName&&!x&&v.push(`護理員 ${n.careStaffName}`),!n.careStaffName&&a.size>0){if(1===c.length&&h){let e=a.get(h.customer_id);e&&e.voucher_number&&v.push(`CCSV: ${e.voucher_number}`)}else if(c.length>1){let e=[];s.forEach(t=>{if(t.customer_id&&!e.some(e=>e.startsWith(t.customer_name||""))){let r=a.get(t.customer_id);if(r&&r.voucher_number){let a=[t.customer_name||t.customer_id];a.push(`CCSV: ${r.voucher_number}`),e.push(a.join(" / "))}}}),e.length>0&&v.push(e.join(" | "))}}v.push(`${e.length} 筆排班`,`${b.toFixed(1)} 小時`,c.length?`${c.length} 位客戶`:"0 位客戶");let y=v.map(e=>P(e).replace(/ /g,"&nbsp;")).join('<span class="info-separator">·</span>'),_=x?O(r.selectedStaffName||m[0]||g):O(g),j=x?O(r.selectedStaffName||m[0]||"護理員"):O(f),N=`${_}${O(d)}更表-${j}-明家居家護理服務`,w=Math.max(1,Math.ceil(e.length/10)),k=`${N} (${w}).pdf`,$=k.replace(/\.pdf$/,""),S=e=>{let t=e.getFullYear(),r=String(e.getMonth()+1).padStart(2,"0"),a=String(e.getDate()).padStart(2,"0");return`${t}-${r}-${a}`},C=s.reduce((e,t)=>{let r=t.service_date;return e[r]=e[r]||[],e[r].push(t),e},{}),D=i.getFullYear(),M=i.getMonth(),F=new Date(D,M,1),z=new Date(D,M+1,0),L=n.dateRange?.start?I(n.dateRange.start):F,R=n.dateRange?.end?I(n.dateRange.end):z,T=new Date(L);T.setDate(T.getDate()-T.getDay());let E=new Date(R),H=6-E.getDay();E.setDate(E.getDate()+(H>=0?H:0));let B=[];for(let e=T.getTime();e<=E.getTime();e+=864e5)B.push(new Date(e));let Y=L.getTime(),A=R.getTime(),U=Math.ceil(B.length/7),W=S(new Date),V=[];for(let e=0;e<U;e++){let t=B.slice(7*e,7*e+7).map(e=>{let t=S(e),r=C[t]||[],a=e.getMonth()===M&&e.getFullYear()===D,s=e.getTime()>=Y&&e.getTime()<=A,n=["calendar-cell"];a||n.push("other-month"),s||n.push("out-of-range"),t===W&&n.push("today"),(0===e.getDay()||6===e.getDay())&&n.push("weekend");let o=s&&r.length>=5?"density-high":s&&r.length>=3?"density-medium":"density-low",i=s&&r.length>0?r.map(e=>{let t=`${l(e.start_time)}${e.end_time?` - ${l(e.end_time)}`:""}`,r=e.service_hours?` (${e.service_hours.toFixed(1)} 小時)`:"",a=`${t}${r}`,s=[];e.customer_name&&s.push(P(e.customer_name)),e.care_staff_name&&s.push(P(e.care_staff_name));let n=e.service_type?`<div class="event-line event-line--service">${P(e.service_type)}</div>`:"",o=e.service_address?`<div class="event-line event-line--location">${P(e.service_address)}</div>`:"";return`
                <div class="event">
                  <div class="event-line event-line--time">${P(a)}</div>
                  ${s.length>0?`<div class="event-line">${s.join(" · ")}</div>`:""}
                  ${n}
                  ${o}
                </div>
              `}).join(""):s?'<div class="no-events">無排班</div>':"";return`
          <td class="${n.join(" ")}">
            <div class="day-number">${e.getDate()}</div>
            <div class="events ${o}">${i}</div>
          </td>
        `});V.push(`<tr>${t.join("")}</tr>`)}let q=`
      <table class="calendar-grid">
        <thead>
          <tr>${["日","一","二","三","四","五","六"].map(e=>`<th>${e}</th>`).join("")}</tr>
        </thead>
        <tbody>
          ${V.join("\n")}
        </tbody>
      </table>
    `,K=`
      <!DOCTYPE html>
      <html lang="zh-HK">
      <head>
        <meta charset="UTF-8" />
        <title>${P($)}</title>
        <style>
          @page {
            size: A4 landscape;
            margin: 6mm;
          }
          :root {
            color-scheme: light;
          }
          body {
            font-family: "PingFang TC", "Microsoft JhengHei", "SimSun", sans-serif;
            margin: 0;
            padding: 16px;
            background: #f8fafc;
            color: #1f2933;
            line-height: 1.5;
          }
          .header {
            display: flex;
            flex-direction: column;
            gap: 8px;
            margin-bottom: 12px;
          }
          .header-actions {
            align-self: flex-end;
          }
          .download-button {
            background: linear-gradient(135deg, #2563eb, #1d4ed8);
            border: none;
            color: #fff;
            padding: 6px 14px;
            border-radius: 9999px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            box-shadow: 0 8px 16px rgba(37, 99, 235, 0.25);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
          }
          .download-button:hover {
            transform: translateY(-1px);
            box-shadow: 0 12px 20px rgba(29, 78, 216, 0.3);
          }
          .download-button:active {
            transform: translateY(0);
            box-shadow: 0 6px 14px rgba(37, 99, 235, 0.25);
          }
          .header-info {
            display: flex;
            flex-direction: column;
            gap: 8px;
            width: 100%;
          }
          .info-strip {
            background: #fff;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 8px 12px;
            display: block;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            font-size: 15px;
            font-weight: 600;
            color: #1f2937;
            line-height: 1.4;
          }
          .info-strip span {
            white-space: nowrap;
          }
          .info-separator {
            color: #cbd5f5;
            font-size: 11px;
          }
          .calendar-grid {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 18px 45px rgba(15, 23, 42, 0.12);
            page-break-inside: avoid;
          }
          .calendar-grid th {
            background: linear-gradient(135deg, #2563eb, #1d4ed8);
            color: #fff;
            padding: 12px 8px;
            font-weight: 600;
            text-align: center;
            font-size: 13px;
            letter-spacing: 0.12em;
          }
          .calendar-grid td {
            width: 14.285%;
            min-height: 120px;
            border: 1px solid #e2e8f0;
            vertical-align: top;
            padding: 8px;
            position: relative;
            background: #fff;
            transition: background 0.2s ease;
          }
          .calendar-cell.other-month {
            background: #f8fafc;
            color: #94a3b8;
          }
          .calendar-cell.out-of-range {
            background: #f1f5f9;
            color: #cbd5f5;
          }
          .calendar-cell.out-of-range .day-number {
            color: #cbd5f5;
          }
          .calendar-cell.weekend {
            background: #fff7ed;
          }
          .calendar-cell.weekend.other-month {
            background: #fff1e6;
          }
          .calendar-cell.today {
            box-shadow: inset 0 0 0 2px #2563eb;
            background: #eff6ff;
          }
          .day-number {
            font-weight: 700;
            font-size: 15px;
            color: #0f172a;
            margin-bottom: 6px;
          }
          .calendar-cell.other-month .day-number {
            color: #94a3b8;
          }
          .events {
            display: flex;
            flex-direction: column;
            gap: 8px;
          }
          .events.density-medium {
            gap: 6px;
          }
          .events.density-high {
            gap: 4px;
          }
          .event {
            border-left: 3px solid #2563eb;
            background: #eef2ff;
            padding: 6px 8px;
            border-radius: 10px;
            box-shadow: 0 10px 18px rgba(37, 99, 235, 0.15);
          }
          .events.density-medium .event {
            padding: 5px 7px;
            border-radius: 8px;
          }
          .events.density-high .event {
            padding: 4px 6px;
            border-radius: 6px;
          }
          .calendar-cell.weekend .event {
            border-left-color: #db2777;
            background: #fce7f3;
          }
          .calendar-cell.today .event {
            border-left-color: #1d4ed8;
          }
          .event-line {
            font-size: 12px;
            color: #0f172a;
            margin-top: 2px;
            line-height: 1.4;
          }
          .event-line:first-child {
            margin-top: 0;
          }
          .event-line--time {
            font-weight: 600;
            color: #1d4ed8;
          }
          .event-line--service {
            color: #475569;
          }
          .event-line--location {
            color: #94a3b8;
            word-break: break-word;
          }
          .events.density-medium .event-line {
            font-size: 10.8px;
          }
          .events.density-medium .event-line--time {
            font-size: 11.5px;
          }
          .events.density-high .event-line {
            font-size: 10px;
          }
          .events.density-high .event-line--time {
            font-size: 10.5px;
          }
          .no-events {
            font-size: 11px;
            color: #94a3b8;
            font-style: italic;
          }
          .calendar-cell.out-of-range .events {
            display: none;
          }
          .footer-note {
            margin-top: 32px;
            font-size: 12px;
            color: #64748b;
            text-align: center;
          }
          @media print {
            body {
              background: transparent;
              padding: 4mm 6mm;
            }
            .download-button {
              display: none;
            }
            .header-info {
              gap: 6px;
            }
            .info-strip {
              font-size: 12px;
              padding: 5px 8px;
            }
            .calendar-grid {
              box-shadow: none;
              border: 1px solid #cbd5f5;
              font-size: 11px;
              page-break-inside: avoid;
            }
            .calendar-grid tr,
            .calendar-grid td {
              page-break-inside: avoid;
            }
            .calendar-grid th {
              background: #1e3a8a;
              -webkit-print-color-adjust: exact;
              padding: 6px 5px;
              font-size: 11px;
            }
            .calendar-cell.weekend {
              background: #fff0f6 !important;
            }
            .calendar-cell.other-month {
              background: #f5f5f5 !important;
            }
            .calendar-cell.out-of-range {
              background: #f8fafc !important;
              color: #d1d5db !important;
            }
            .calendar-cell.out-of-range .day-number {
              color: #d1d5db !important;
            }
            .calendar-grid td {
              min-height: 90px;
              padding: 4px;
            }
            .event {
              border-left-width: 2px;
              padding: 3px 5px;
              box-shadow: none;
            }
            .events.density-medium {
              gap: 3px;
            }
            .events.density-high {
              gap: 2px;
            }
            .events.density-medium .event {
              padding: 2px 4px;
            }
            .events.density-high .event {
              padding: 2px 3px;
            }
            .event-line {
              font-size: 9.4px;
            }
            .event-line--time {
              font-size: 10px;
            }
            .events.density-medium .event-line {
              font-size: 9px;
            }
            .events.density-medium .event-line--time {
              font-size: 9.6px;
            }
            .events.density-high .event-line {
              font-size: 8.6px;
            }
            .events.density-high .event-line--time {
              font-size: 9.2px;
            }
            .calendar-cell.out-of-range .events {
              display: none;
            }
            .footer-note {
              margin-top: 8px;
              font-size: 10px;
            }
          }
        </style>
      </head>
      <body>
        <header class="header">
          <div class="header-actions">
            <button class="download-button" data-intranet-print>儲存 PDF</button>
          </div>
          <div class="header-info">
            <div class="info-strip">${y}</div>
          </div>
        </header>
        ${q}
        <p class="footer-note">此文件由 MingCare Intranet 於 ${P(new Date().toLocaleString("zh-TW"))} 生成。使用瀏覽器「列印」功能即可匯出為 PDF 並分享。</p>
      </body>
      </html>
    `;return{success:!0,data:K,filename:k}}catch(e){return console.error("PDF 導出錯誤:",e),{success:!1,error:e instanceof Error?e.message:"PDF 導出失敗"}}}(n,l.data,e,o)}catch(e){return console.error("❌ 日曆導出失敗:",e),{success:!1,error:e instanceof Error?e.message:"導出失敗"}}}async function E(e){return k(e)}function I(e){let[t,r,a]=e.split("-").map(Number);return new Date(t,(r||1)-1,a||1)}function P(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function O(e){return e.replace(/[\\/:*?"<>|]/g,"").replace(/\s+/g,"").slice(0,100)}let H={"2026-01-01":"元旦","2026-02-17":"農曆年初一","2026-02-18":"農曆年初二","2026-02-19":"農曆年初三","2026-04-03":"耶穌受難節","2026-04-04":"耶穌受難節翌日","2026-04-06":"清明節翌日","2026-04-07":"復活節星期一翌日","2026-05-01":"勞動節","2026-05-25":"佛誕翌日","2026-06-19":"端午節","2026-07-01":"香港特別行政區成立紀念日","2026-09-26":"中秋節翌日","2026-10-01":"國慶日","2026-10-19":"重陽節翌日","2026-12-25":"聖誕節","2026-12-26":"聖誕節後第一個週日"},B=e=>{let t=H[A(e)];return 0===e.getDay()?{isHoliday:!0,name:t||"星期日"}:{isHoliday:!!t,name:t||null}};function Y(e){let t=e.getFullYear(),r=String(e.getMonth()+1).padStart(2,"0"),a=String(e.getDate()).padStart(2,"0");return`${t}-${r}-${a}`}let A=e=>{if(!e||!(e instanceof Date)||isNaN(e.getTime()))return new Date().toISOString().split("T")[0];let t=e.getFullYear(),r=String(e.getMonth()+1).padStart(2,"0"),a=String(e.getDate()).padStart(2,"0");return`${t}-${r}-${a}`};function U({filters:e,onEdit:r,onDelete:a,refreshTrigger:s,recordUpdateTimes:l}){let[o,i]=(0,n.useState)({}),[c,m]=(0,n.useState)(!0),[x,p]=(0,n.useState)(()=>{if(e.dateRange?.start){let[t,r]=e.dateRange.start.split("-").map(Number);return new Date(t,r-1,1)}return new Date}),[u,h]=(0,n.useState)(!1),[g,f]=(0,n.useState)("cards"),[b,v]=(0,n.useState)([]),[y,_]=(0,n.useState)(()=>Date.now());(0,n.useEffect)(()=>{let e=window.setInterval(()=>_(Date.now()),6e4);return()=>window.clearInterval(e)},[]),(0,n.useEffect)(()=>{console.log("📅 ReportsCalendarView 收到 recordUpdateTimes:",l),console.log("📅 recordUpdateTimes 鍵數量:",l?Object.keys(l).length:0)},[l]);let[j,N]=(0,n.useState)(e.dateRange.start);if(j!==e.dateRange.start&&(N(e.dateRange.start),e.dateRange.start)){let[t,r]=e.dateRange.start.split("-").map(Number);p(new Date(t,r-1,1))}(0,n.useEffect)(()=>{let e=()=>{h(window.innerWidth<640)};return e(),window.addEventListener("resize",e),()=>{window.removeEventListener("resize",e)}},[]);let[k,$]=(0,n.useState)(null),[S,C]=(0,n.useState)(!1),[D,M]=(0,n.useState)(new Set);(0,n.useEffect)(()=>{(async()=>{m(!0);try{let t=await w(e,1,1e5);if(t.success&&t.data){let e=t.data.data||[];v(e);let r={};e.forEach(e=>{let t=e.service_date;if(r[t]||(r[t]=[]),r[t].push(e),e.start_time&&e.end_time&&e.start_time>e.end_time){let a=function(e){let[t,r,a]=e.split("-").map(Number);return new Date(t,r-1,a)}(t);a.setDate(a.getDate()+1);let s=Y(a);if(s!==t){r[s]||(r[s]=[]);let t={...e,_isOvernightEndDay:!0};r[s].push(t)}}}),Object.keys(r).forEach(e=>{let t=new Set;r[e]=r[e].filter(e=>!t.has(e.id)&&(t.add(e.id),!0))}),i(r)}}catch(e){console.error("載入月曆數據失敗:",e)}finally{m(!1)}})()},[e,s]);let F=e=>{let t=new Date(x);t.setMonth(x.getMonth()+("next"===e?1:-1)),p(t)},z=(()=>{let e=new Date(x.getFullYear(),x.getMonth(),1),t=new Date(e);t.setDate(t.getDate()-e.getDay());let r=[],a=new Date(t);for(let e=0;e<42;e++)r.push(new Date(a)),a.setDate(a.getDate()+1);return r})(),L=x.getMonth();return c?(0,t.jsxs)("div",{className:"flex items-center justify-center py-12",children:[(0,t.jsx)("div",{className:"inline-block animate-spin rounded-full h-8 w-8 border-2 border-primary border-t-transparent"}),(0,t.jsx)("span",{className:"ml-3 text-text-secondary",children:"載入月曆數據中..."})]}):(0,t.jsxs)("div",{className:"space-y-4 sm:space-y-6",children:[(0,t.jsxs)("div",{className:"flex justify-between items-center px-2 sm:px-0",children:[(0,t.jsxs)("div",{className:"flex items-center space-x-2",children:[(0,t.jsx)("button",{onClick:()=>F("prev"),className:"p-2 sm:p-3 rounded-xl border border-border-light hover:bg-bg-secondary transition-all duration-300",children:(0,t.jsx)("svg",{className:"w-4 h-4 sm:w-5 sm:h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M15 19l-7-7 7-7"})})}),(0,t.jsxs)("h4",{className:"text-base sm:text-lg font-medium text-text-primary",children:[x.getFullYear(),"年 ",x.getMonth()+1,"月"]}),(0,t.jsx)("button",{onClick:()=>F("next"),className:"p-2 sm:p-3 rounded-xl border border-border-light hover:bg-bg-secondary transition-all duration-300",children:(0,t.jsx)("svg",{className:"w-4 h-4 sm:w-5 sm:h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M9 5l7 7-7 7"})})})]}),(0,t.jsxs)("div",{className:"flex rounded-xl border border-border-light overflow-hidden bg-bg-secondary/50 backdrop-blur-sm",children:[(0,t.jsxs)("button",{onClick:()=>f("cards"),className:`px-4 py-2.5 text-sm font-medium transition-all duration-300 flex items-center space-x-2 ${"cards"===g?"bg-primary text-white shadow-lg":"bg-transparent text-text-secondary hover:bg-bg-tertiary hover:text-text-primary"}`,children:[(0,t.jsx)("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"})}),(0,t.jsx)("span",{children:"卡片"})]}),(0,t.jsxs)("button",{onClick:()=>f("calendar"),className:`px-4 py-2.5 text-sm font-medium transition-all duration-300 flex items-center space-x-2 ${"calendar"===g?"bg-primary text-white shadow-lg":"bg-transparent text-text-secondary hover:bg-bg-tertiary hover:text-text-primary"}`,children:[(0,t.jsx)("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"})}),(0,t.jsx)("span",{children:"日曆"})]})]})]}),"calendar"===g?(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("div",{className:"grid grid-cols-7 gap-0.5 sm:gap-1 mb-2",children:["日","一","二","三","四","五","六"].map(e=>(0,t.jsx)("div",{className:"p-1 sm:p-2 text-center font-medium text-text-secondary bg-bg-secondary rounded text-xs sm:text-sm",children:e},e))}),(0,t.jsx)("div",{className:"grid grid-cols-7 gap-0.5 sm:gap-1",style:{overflow:"visible"},children:z&&z.map((e,r)=>{let a,s,n,i=A(e),d=e.getMonth()===L,c=i===A(new Date),m=0===e.getDay()||6===e.getDay(),x=B(e),p=o[i]||[],h=u?80:120,g=p.length>0?Math.max(h,h+(p.length-1)*(u?50:80)):h;return(0,t.jsxs)("div",{style:{minHeight:`${g}px`,overflow:"visible"},className:`
                p-1 sm:p-2 border rounded-xl
                ${!d?"bg-bg-secondary text-text-tertiary border-border-light":x.isHoliday?"bg-red-50 border-red-300":m?"bg-blue-50 border-blue-200":"bg-bg-primary border-border-light"}
                ${c?"ring-1 sm:ring-2 ring-primary border-primary":""}
              `,children:[(0,t.jsxs)("div",{className:`
                text-xs sm:text-sm font-bold mb-1 sm:mb-2 flex items-center gap-1
                ${c?"text-primary":x.isHoliday?"text-red-600":d?"text-text-primary":"text-text-tertiary"}
              `,children:[(0,t.jsx)("span",{children:e.getDate()}),x.isHoliday&&x.name&&"星期日"!==x.name&&(0,t.jsx)("span",{className:"text-xs text-red-500 truncate hidden sm:inline",title:x.name,children:x.name.length>4?x.name.substring(0,4)+"..":x.name})]}),d&&p.length>0&&(0,t.jsxs)("div",{className:"space-y-0.5 sm:space-y-1",style:{overflow:"visible"},children:[(a=A(e),s=D.has(a),n=[...p].sort((e,t)=>{let r=l?.[e.id]?.getTime()??0;return(l?.[t.id]?.getTime()??0)-r}),((s?n:n.slice(0,u?2:3))||[]).map((e,r)=>(0,t.jsxs)("div",{onClick:()=>{$(e),C(!0)},className:`text-xs sm:text-sm border border-border-light rounded p-1 sm:p-2 shadow-sm cursor-pointer hover:shadow-md hover:border-primary transition-all duration-300 relative overflow-visible ${l?.[e.id]?"bg-green-50 border-green-300 ring-1 ring-green-400":"bg-white"}`,"data-updated":l?.[e.id]?"true":"false",children:[(()=>{let r=l?.[e.id];if(!r)return null;let a=Math.floor((Date.now()-r.getTime())/6e4),s=a<1?"剛剛":1===a?"1分鐘前":`${a}分鐘前`;return(0,t.jsxs)("div",{className:"text-center mb-2 bg-green-600 text-white font-bold text-sm py-1 rounded",children:[s,"更新"]})})(),(0,t.jsxs)("div",{className:"font-medium text-text-primary mb-0.5 sm:mb-1 leading-tight text-xs sm:text-sm",children:[(0,t.jsxs)("span",{className:"hidden sm:inline",children:[e.customer_name,"/",e.care_staff_name]}),(0,t.jsxs)("span",{className:"sm:hidden",children:[e.customer_name.substring(0,6),"/",e.care_staff_name.substring(0,6)]})]}),(0,t.jsx)("div",{className:"text-blue-600 mb-0.5 sm:mb-1 leading-tight text-xs",children:e.service_type}),(0,t.jsxs)("div",{className:"text-text-secondary text-xs flex items-center gap-1",children:[e.start_time&&e.end_time&&e.start_time>e.end_time&&(0,t.jsx)("span",{title:"跨夜更",className:"text-orange-500",children:"🌙"}),e._isOvernightEndDay&&(0,t.jsx)("span",{className:"text-xs text-orange-600 font-semibold",children:"(隔天)"}),e.start_time,"-",e.end_time]})]},`${e.id}-${r}`))),p.length>3&&(0,t.jsx)("button",{onClick:t=>{t.stopPropagation();let r=A(e),a=new Set(D);D.has(r)?a.delete(r):a.add(r),M(a)},className:"w-full text-sm text-primary hover:text-blue-700 text-center py-1 rounded hover:bg-blue-50 transition-colors",children:D.has(A(e))?"收合記錄":`還有 ${p.length-3} 筆記錄...`})]})]},r)})}),S&&k&&(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("div",{className:"fixed inset-0 bg-black/40 z-[9998]",onClick:()=>{C(!1),$(null)}}),(0,t.jsx)("div",{className:"fixed inset-0 z-[9999] flex items-center justify-center p-4 pointer-events-none",children:(0,t.jsxs)("div",{className:"bg-white rounded-2xl p-6 w-full max-w-sm shadow-2xl pointer-events-auto",onClick:e=>e.stopPropagation(),children:[(0,t.jsx)("h3",{className:"text-lg font-semibold text-gray-900 mb-4",children:"選擇操作"}),(0,t.jsxs)("div",{className:"bg-gray-50 rounded-xl p-4 mb-5 border border-gray-100",children:[(0,t.jsxs)("div",{className:"text-sm text-gray-500 mb-1",children:[k.service_date," ",k.start_time,"-",k.end_time]}),(0,t.jsx)("div",{className:"font-semibold text-gray-900",children:k.customer_name}),(0,t.jsxs)("div",{className:"text-sm text-gray-600 mt-1",children:["護理員：",k.care_staff_name]}),(0,t.jsx)("div",{className:"text-sm text-blue-600 font-medium mt-1",children:k.service_type})]}),(0,t.jsxs)("div",{className:"flex gap-3",children:[(0,t.jsx)("button",{type:"button",onClick:()=>{r(k),C(!1),$(null)},className:"flex-1 py-3 px-4 bg-blue-500 text-white rounded-xl font-medium hover:bg-blue-600 transition-colors",children:"編輯"}),(0,t.jsx)("button",{type:"button",onClick:()=>{a(k.id),C(!1),$(null)},className:"flex-1 py-3 px-4 bg-red-500 text-white rounded-xl font-medium hover:bg-red-600 transition-colors",children:"刪除"})]}),(0,t.jsx)("button",{type:"button",onClick:()=>{C(!1),$(null)},className:"w-full mt-3 py-3 px-4 text-gray-600 bg-gray-100 rounded-xl font-medium hover:bg-gray-200 transition-colors",children:"取消"})]})})]})]}):(0,t.jsx)("div",{className:"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",children:b.map((e,r)=>(0,t.jsxs)("div",{onClick:()=>{$(e),C(!0)},className:`card-apple border p-5 shadow-sm cursor-pointer hover:shadow-lg hover:border-primary hover:-translate-y-0.5 transition-all duration-300 relative ${l?.[e.id]?"bg-green-50 border-green-300 ring-2 ring-green-400/30":"border-border-light"}`,children:[(()=>{let r=l?.[e.id];if(!r)return null;let a=Math.floor((y-r.getTime())/6e4),s=a<1?"剛剛":1===a?"1分鐘前":`${a}分鐘前`;return console.log("🎯 渲染30分鐘提示:",{recordId:e.id,diff:a,label:s}),(0,t.jsxs)("div",{className:"text-center mb-3 bg-green-500 text-white font-semibold text-xs py-1.5 rounded-lg shadow-sm",children:["✓ ",s,"更新"]})})(),(0,t.jsxs)("div",{className:"space-y-3",children:[(0,t.jsxs)("div",{className:"flex justify-between items-start",children:[(0,t.jsx)("h3",{className:"font-semibold text-text-primary truncate",children:e.customer_name}),(0,t.jsx)("span",{className:"text-xs text-text-secondary bg-bg-tertiary px-2 py-1 rounded",children:e.service_date})]}),(0,t.jsxs)("div",{className:"space-y-2",children:[(0,t.jsxs)("div",{className:"flex items-center text-sm text-text-secondary",children:[(0,t.jsx)("svg",{className:"w-4 h-4 mr-2",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"})}),e.care_staff_name]}),(0,t.jsxs)("div",{className:"flex items-center text-sm text-text-secondary",children:[(0,t.jsx)("svg",{className:"w-4 h-4 mr-2",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"})}),e.start_time&&e.end_time&&e.start_time>e.end_time&&(0,t.jsx)("span",{title:"跨夜更",className:"text-orange-500 mr-1",children:"🌙"}),e.start_time," - ",e.end_time]}),(0,t.jsxs)("div",{className:"flex items-center text-sm text-blue-600",children:[(0,t.jsx)("svg",{className:"w-4 h-4 mr-2",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"})}),e.service_type]})]})]})]},e.id))}),S&&k&&(0,t.jsx)(t.Fragment,{children:(0,d.createPortal)((0,t.jsxs)("div",{className:"fixed inset-0 z-[9999] overflow-y-auto",onMouseDown:e=>{e.target===e.currentTarget&&(C(!1),$(null))},children:[(0,t.jsx)("div",{className:"fixed inset-0 bg-black/60 transition-opacity"}),(0,t.jsx)("div",{className:"fixed inset-0 flex items-center justify-center p-4",children:(0,t.jsxs)("div",{className:"relative bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 transform transition-all",onMouseDown:e=>e.stopPropagation(),children:[(0,t.jsx)("h3",{className:"text-lg font-semibold text-gray-900 mb-4",children:"選擇操作"}),(0,t.jsxs)("div",{className:"bg-gray-50 rounded-xl p-4 mb-5 border border-gray-200",children:[(0,t.jsxs)("div",{className:"text-sm text-gray-500 mb-1.5",children:[k.service_date," ",k.start_time,"-",k.end_time]}),(0,t.jsx)("div",{className:"font-semibold text-gray-900 text-base",children:k.customer_name}),(0,t.jsxs)("div",{className:"text-sm text-gray-600 mt-1",children:["護理員：",k.care_staff_name]}),(0,t.jsx)("div",{className:"text-sm text-primary font-medium mt-1",children:k.service_type})]}),(0,t.jsxs)("div",{className:"flex space-x-3",children:[(0,t.jsx)("button",{type:"button",onMouseDown:e=>e.stopPropagation(),onClick:()=>{console.log("📝 編輯按鈕被點擊:",k),r(k),C(!1),$(null)},className:"btn-apple-primary flex-1",children:"編輯"}),(0,t.jsx)("button",{type:"button",onMouseDown:e=>e.stopPropagation(),onClick:()=>{console.log("🗑️ 刪除按鈕被點擊:",k.id),a(k.id),C(!1),$(null)},className:"flex-1 bg-red-500 text-white py-2.5 px-4 rounded-xl hover:bg-red-600 transition-all duration-300 font-medium",children:"刪除"})]}),(0,t.jsx)("button",{type:"button",onMouseDown:e=>e.stopPropagation(),onClick:()=>{C(!1),$(null)},className:"btn-apple-secondary w-full mt-4",children:"取消"})]})})]}),document.body)})]})}let W=e=>e?e.trim().toLowerCase():null,V=e=>e?e.trim().replace(/[\s]/g,"").replace(/[()（）]/g,"").toLowerCase():"";function q({filters:e,setFilters:r,updateDateRange:a,kpiData:s,kpiLoading:l,categorySummary:n}){return(0,t.jsxs)("div",{className:"space-y-8",children:[(0,t.jsxs)("div",{className:"card-apple mb-4 sm:mb-6 fade-in-apple",children:[(0,t.jsx)("div",{className:"card-apple-header",children:(0,t.jsx)("h3",{className:"text-lg sm:text-xl font-semibold text-text-primary",children:"搜尋與篩選"})}),(0,t.jsxs)("div",{className:"card-apple-content",children:[(0,t.jsx)("h2",{className:"text-apple-heading text-text-primary mb-4",children:"選擇時段"}),(0,t.jsx)("div",{className:"flex items-center gap-4 mb-4",children:(0,t.jsxs)("div",{className:"flex gap-2 flex-wrap",children:[(0,t.jsx)("button",{onClick:()=>a("thisMonth"),className:"btn-apple-primary text-sm",children:"本月"}),(0,t.jsx)("button",{onClick:()=>a("lastMonth"),className:"btn-apple-secondary text-sm",children:"上月"}),(0,t.jsx)("button",{onClick:()=>a("last3months"),className:"btn-apple-secondary text-sm",children:"最近3個月"}),(0,t.jsx)("button",{onClick:()=>a("last6months"),className:"btn-apple-secondary text-sm",children:"最近6個月"}),(0,t.jsx)("button",{onClick:()=>a("thisQuarter"),className:"btn-apple-secondary text-sm",children:"本季度"}),(0,t.jsx)("button",{onClick:()=>a("thisYear"),className:"btn-apple-secondary text-sm",children:"本年度"})]})}),(0,t.jsx)("div",{className:"flex items-center gap-4 mb-4",children:(0,t.jsxs)("div",{className:"flex items-center gap-3",children:[(0,t.jsx)("select",{value:e.dateRange?.start?(()=>{let[t]=e.dateRange.start.split("-").map(Number);return t})():new Date().getFullYear(),onChange:t=>{let a=parseInt(t.target.value),s=e.dateRange?.start?(()=>{let[,t]=e.dateRange.start.split("-").map(Number);return t-1})():new Date().getMonth(),l=new Date(a,s+1,0),n=a+"-"+String(s+1).padStart(2,"0")+"-01",o=l.getFullYear()+"-"+String(l.getMonth()+1).padStart(2,"0")+"-"+String(l.getDate()).padStart(2,"0");r(e=>({...e,dateRange:{start:n,end:o}}))},className:"form-input-apple pr-10 appearance-none cursor-pointer",children:Array.from({length:5},(e,r)=>{let a=new Date().getFullYear()-2+r;return(0,t.jsxs)("option",{value:a,children:[a,"年"]},a)})}),(0,t.jsx)("select",{value:e.dateRange?.start?(()=>{let[,t]=e.dateRange.start.split("-").map(Number);return t-1})():new Date().getMonth(),onChange:t=>{let a=e.dateRange?.start?(()=>{let[t]=e.dateRange.start.split("-").map(Number);return t})():new Date().getFullYear(),s=parseInt(t.target.value),l=new Date(a,s+1,0),n=a+"-"+String(s+1).padStart(2,"0")+"-01",o=l.getFullYear()+"-"+String(l.getMonth()+1).padStart(2,"0")+"-"+String(l.getDate()).padStart(2,"0");r(e=>({...e,dateRange:{start:n,end:o}}))},className:"px-3 py-2 text-sm border border-border-light rounded-xl bg-bg-primary text-text-primary focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent",children:Array.from({length:12},(e,r)=>(0,t.jsxs)("option",{value:r,children:[r+1,"月"]},r))})]})}),(0,t.jsxs)("div",{className:"flex items-center gap-2",children:[(0,t.jsx)("label",{className:"text-sm text-text-secondary",children:"時間段："}),(0,t.jsx)("input",{type:"date",value:e.dateRange?.start||"",onChange:e=>r(t=>({...t,dateRange:{...t.dateRange,start:e.target.value}})),className:"px-3 py-2 text-sm border border-border-light rounded-xl bg-bg-primary text-text-primary focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"}),(0,t.jsx)("span",{className:"text-text-secondary",children:"至"}),(0,t.jsx)("input",{type:"date",value:e.dateRange?.end||"",onChange:e=>r(t=>({...t,dateRange:{...t.dateRange,end:e.target.value}})),className:"px-3 py-2 text-sm border border-border-light rounded-xl bg-bg-primary text-text-primary focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"})]}),(0,t.jsxs)("div",{className:"mt-4 text-sm text-text-secondary",children:["當前範圍：",e.dateRange?.start||"未設定"," ~ ",e.dateRange?.end||"未設定"]})]})]}),(0,t.jsx)("div",{className:"grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-6",children:l?(0,t.jsxs)("div",{className:"col-span-full text-center py-12",children:[(0,t.jsx)("div",{className:"inline-block animate-spin rounded-full h-8 w-8 border-2 border-primary border-t-transparent"}),(0,t.jsx)("p",{className:"text-sm text-text-secondary mt-3",children:"計算中..."})]}):s?(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)("div",{className:"card-apple border border-border-light p-4 md:p-6 text-center",children:[(0,t.jsxs)("div",{className:"text-2xl md:text-3xl font-bold text-text-primary mb-2",children:["$",s.totalRevenue.toLocaleString()]}),(0,t.jsx)("div",{className:"text-xs md:text-sm text-text-secondary",children:"總收入"}),0!==s.revenueGrowthRate&&(0,t.jsxs)("div",{className:`text-xs mt-2 ${s.revenueGrowthRate>=0?"text-green-600":"text-red-600"}`,children:[s.revenueGrowthRate>=0?"↗":"↘"," ",Math.abs(s.revenueGrowthRate).toFixed(1),"%"]})]}),(0,t.jsxs)("div",{className:"card-apple border border-border-light p-4 md:p-6 text-center",children:[(0,t.jsxs)("div",{className:"text-2xl md:text-3xl font-bold text-text-primary mb-2",children:["$",s.totalProfit.toLocaleString()]}),(0,t.jsx)("div",{className:"text-xs md:text-sm text-text-secondary",children:"總利潤"}),(0,t.jsxs)("div",{className:"text-xs text-text-secondary mt-2",children:["利潤率: ",s.totalRevenue>0?(s.totalProfit/s.totalRevenue*100).toFixed(1):0,"%"]})]}),(0,t.jsxs)("div",{className:"card-apple border border-border-light p-4 md:p-6 text-center",children:[(0,t.jsx)("div",{className:"text-2xl md:text-3xl font-bold text-text-primary mb-2",children:s.totalServiceHours.toFixed(1)}),(0,t.jsx)("div",{className:"text-xs md:text-sm text-text-secondary",children:"總服務時數"})]}),(0,t.jsxs)("div",{className:"card-apple border border-border-light p-4 md:p-6 text-center",children:[(0,t.jsxs)("div",{className:"text-2xl md:text-3xl font-bold text-text-primary mb-2",children:["$",s.avgProfitPerHour.toFixed(2)]}),(0,t.jsx)("div",{className:"text-xs md:text-sm text-text-secondary",children:"每小時利潤"})]})]}):(0,t.jsx)("div",{className:"col-span-full text-center py-12",children:(0,t.jsx)("p",{className:"text-text-secondary",children:"選取的日期範圍內暫無數據"})})}),(0,t.jsx)("div",{className:"card-apple border border-border-light fade-in-apple",children:(0,t.jsxs)("div",{className:"p-6",children:[(0,t.jsx)("h3",{className:"text-apple-heading text-text-primary mb-6",children:"項目分類統計"}),n&&n.length>0?(0,t.jsxs)("div",{className:"space-y-4",children:[n.map((e,r)=>(0,t.jsxs)("div",{className:"flex items-center justify-between p-4 bg-bg-secondary rounded-xl border border-border-light",children:[(0,t.jsxs)("div",{className:"flex items-center",children:[(0,t.jsx)("div",{className:"w-3 h-3 bg-primary rounded-full mr-3"}),(0,t.jsxs)("div",{children:[(0,t.jsx)("h4",{className:"font-medium text-text-primary",children:e.category}),(0,t.jsxs)("p",{className:"text-sm text-text-secondary",children:[e.recordCount," 筆記錄 • ",e.uniqueCustomers," 位客戶"]})]})]}),(0,t.jsxs)("div",{className:"text-right",children:[(0,t.jsxs)("div",{className:"text-lg font-bold text-text-primary",children:["$",e.totalFee.toLocaleString()]}),(0,t.jsxs)("div",{className:"text-sm text-text-secondary",children:[e.totalHours.toFixed(1),"h • 利潤 $",e.totalProfit.toLocaleString()]})]})]},e.category)),(0,t.jsxs)("div",{className:"flex items-center justify-between p-4 bg-primary/10 rounded-xl border-2 border-primary mt-6",children:[(0,t.jsxs)("div",{className:"flex items-center",children:[(0,t.jsx)("div",{className:"w-3 h-3 bg-primary rounded-full mr-3"}),(0,t.jsxs)("div",{children:[(0,t.jsx)("h4",{className:"font-bold text-text-primary",children:"所有項目總計"}),(0,t.jsxs)("p",{className:"text-sm text-text-secondary",children:[n.reduce((e,t)=>e+t.recordCount,0)," 筆記錄 • ",n.length," 個項目"]})]})]}),(0,t.jsxs)("div",{className:"text-right",children:[(0,t.jsxs)("div",{className:"text-lg font-bold text-primary",children:["$",n.reduce((e,t)=>e+t.totalFee,0).toLocaleString()]}),(0,t.jsxs)("div",{className:"text-sm text-text-secondary",children:[n.reduce((e,t)=>e+t.totalHours,0).toFixed(1),"h • 利潤 $",n.reduce((e,t)=>e+t.totalProfit,0).toLocaleString()]})]})]})]}):(0,t.jsx)("div",{className:"text-center py-12",children:(0,t.jsx)("p",{className:"text-text-secondary",children:"選取的日期範圍內暫無項目數據"})})]})})]})}function K({localSchedules:e,updateTrigger:r}){let a,s,l,[o,i]=(0,n.useState)([]),d=(0,n.useCallback)(async()=>{let t=Object.values(e||{}).flat();console.log("計算社區券統計 - 本地排程:",e),console.log("所有排程:",t);try{let e=await L();if(!e.success||!e.data)return console.error("無法獲取社區券費率"),[];let r=e.data;console.log("社區券費率表:",r);let a={};t.forEach(e=>{let t=e.service_type||"未分類",s=z(r,t,e.service_date),l=e.service_hours||0;a[t]||(a[t]={count:0,total_hours:0,rate:s,total_amount:0}),a[t].count+=1,a[t].total_hours=Math.round((a[t].total_hours+l)*100)/100,a[t].total_amount=Math.round((a[t].total_amount+Math.round(l*s*100)/100)*100)/100});let s=Object.entries(a).map(([e,t])=>({service_type:e,count:t.count,total_hours:t.total_hours,total_rate:t.rate,total_amount:t.total_amount}));return console.log("社區券統計結果:",s),s}catch(e){return console.error("計算社區券統計失敗:",e),[]}},[e]);(0,n.useEffect)(()=>{let e=!1;return d().then(t=>{e||i(t)}),()=>{e=!0}},[d,r]);let c=(s=Math.round(100*((a=Object.values(e||{}).flat())||[]).reduce((e,t)=>e+(t.service_hours||0),0))/100,l=Math.round(100*(a||[]).reduce((e,t)=>e+(t.service_fee||0),0))/100,{totalCount:a?.length||0,totalHours:s,totalFee:l}),m=o.reduce((e,t)=>e+t.total_amount,0);return(0,t.jsxs)("div",{className:"space-y-6",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("h3",{className:"text-apple-heading text-text-primary mb-4",children:"排班小結"}),(0,t.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-4",children:[(0,t.jsxs)("div",{className:"bg-blue-50 rounded-xl p-4",children:[(0,t.jsx)("div",{className:"text-2xl font-bold text-primary",children:c.totalCount}),(0,t.jsx)("div",{className:"text-sm text-text-secondary",children:"總排班數"})]}),(0,t.jsxs)("div",{className:"bg-green-50 rounded-xl p-4",children:[(0,t.jsx)("div",{className:"text-2xl font-bold text-green-600",children:c.totalHours.toFixed(1)}),(0,t.jsx)("div",{className:"text-sm text-text-secondary",children:"總時數"})]}),(0,t.jsxs)("div",{className:"bg-orange-50 rounded-xl p-4",children:[(0,t.jsxs)("div",{className:"text-2xl font-bold text-orange-600",children:["$",c.totalFee.toFixed(2)]}),(0,t.jsx)("div",{className:"text-sm text-text-secondary",children:"總服務費用"})]})]})]}),o.length>0?(0,t.jsxs)("div",{children:[(0,t.jsx)("h3",{className:"text-apple-heading text-text-primary mb-4",children:"社區券機數統計（當前排班）"}),(0,t.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-4 mb-6",children:[(0,t.jsxs)("div",{className:"bg-purple-50 rounded-xl p-4",children:[(0,t.jsx)("div",{className:"text-2xl font-bold text-purple-600",children:c.totalCount}),(0,t.jsx)("div",{className:"text-sm text-text-secondary",children:"總服務次數"})]}),(0,t.jsxs)("div",{className:"bg-indigo-50 rounded-xl p-4",children:[(0,t.jsx)("div",{className:"text-2xl font-bold text-indigo-600",children:c.totalHours.toFixed(1)}),(0,t.jsx)("div",{className:"text-sm text-text-secondary",children:"總服務時數"})]}),(0,t.jsxs)("div",{className:"bg-pink-50 rounded-xl p-4",children:[(0,t.jsxs)("div",{className:"text-2xl font-bold text-pink-600",children:["$",m.toFixed(2)]}),(0,t.jsx)("div",{className:"text-sm text-text-secondary",children:"總社區券金額"})]})]}),(0,t.jsx)("div",{className:"bg-white border border-border-light rounded-xl overflow-hidden",children:(0,t.jsxs)("table",{className:"w-full",children:[(0,t.jsx)("thead",{className:"bg-bg-secondary",children:(0,t.jsxs)("tr",{children:[(0,t.jsx)("th",{className:"text-left py-3 px-4 text-sm font-medium text-text-primary",children:"服務類型"}),(0,t.jsx)("th",{className:"text-left py-3 px-4 text-sm font-medium text-text-primary",children:"次數"}),(0,t.jsx)("th",{className:"text-left py-3 px-4 text-sm font-medium text-text-primary",children:"時數"}),(0,t.jsx)("th",{className:"text-left py-3 px-4 text-sm font-medium text-text-primary",children:"費率/小時"}),(0,t.jsx)("th",{className:"text-left py-3 px-4 text-sm font-medium text-text-primary",children:"金額"})]})}),(0,t.jsx)("tbody",{children:o&&o.map((e,r)=>(0,t.jsxs)("tr",{className:r%2==0?"bg-white":"bg-bg-secondary",children:[(0,t.jsx)("td",{className:"py-3 px-4 text-sm text-text-primary",children:e.service_type}),(0,t.jsx)("td",{className:"py-3 px-4 text-sm text-text-primary",children:e.count}),(0,t.jsx)("td",{className:"py-3 px-4 text-sm text-text-primary",children:e.total_hours.toFixed(1)}),(0,t.jsxs)("td",{className:"py-3 px-4 text-sm text-text-secondary",children:["$",e.total_rate.toFixed(2)]}),(0,t.jsxs)("td",{className:"py-3 px-4 text-sm text-text-primary font-medium",children:["$",e.total_amount.toFixed(2)]})]},e.service_type))})]})})]}):(0,t.jsxs)("div",{children:[(0,t.jsx)("h3",{className:"text-apple-heading text-text-primary mb-4",children:"社區券機數統計（當前排班）"}),(0,t.jsx)("div",{className:"bg-bg-secondary rounded-xl p-6 text-center",children:(0,t.jsxs)("div",{className:"text-text-secondary",children:[(0,t.jsx)("svg",{className:"w-12 h-12 mx-auto mb-3 text-text-tertiary",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"})}),(0,t.jsx)("p",{className:"text-lg font-medium text-text-primary mb-2",children:"尚無排班資料"}),(0,t.jsx)("p",{className:"text-sm text-text-secondary",children:"請先添加排班記錄以查看社區券統計"})]})})]})]})}function J({filters:e,refreshTrigger:r}){let[a,s]=(0,n.useState)(null),[l,o]=(0,n.useState)(!0),[i,d]=(0,n.useState)(null);return((0,n.useEffect)(()=>{(async()=>{o(!0),d(null);try{let t=await R(e);t.success&&t.data?s(t.data):d(t.error||"載入社區券統計失敗")}catch(e){console.error("載入社區券統計失敗:",e),d("載入社區券統計失敗")}finally{o(!1)}})()},[e,r]),l)?(0,t.jsxs)("div",{className:"flex items-center justify-center py-8",children:[(0,t.jsx)("div",{className:"animate-spin rounded-full h-8 w-8 border-2 border-primary border-t-transparent"}),(0,t.jsx)("span",{className:"ml-3 text-text-secondary",children:"載入統計數據中..."})]}):i?(0,t.jsx)("div",{className:"text-center py-8",children:(0,t.jsx)("p",{className:"text-red-600",children:i})}):a?(0,t.jsxs)("div",{children:[(0,t.jsx)("h3",{className:"text-apple-heading text-text-primary mb-4",children:"社區券機數統計"}),(0,t.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-4 mb-6",children:[(0,t.jsxs)("div",{className:"bg-blue-50 rounded-xl p-4",children:[(0,t.jsx)("div",{className:"text-2xl font-bold text-primary",children:a.grandTotal.total_count}),(0,t.jsx)("div",{className:"text-sm text-text-secondary",children:"總服務次數"})]}),(0,t.jsxs)("div",{className:"bg-green-50 rounded-xl p-4",children:[(0,t.jsx)("div",{className:"text-2xl font-bold text-green-600",children:a.grandTotal.total_hours.toFixed(1)}),(0,t.jsx)("div",{className:"text-sm text-text-secondary",children:"總服務時數"})]}),(0,t.jsxs)("div",{className:"bg-orange-50 rounded-xl p-4",children:[(0,t.jsxs)("div",{className:"text-2xl font-bold text-orange-600",children:["$",a.grandTotal.total_amount.toFixed(2)]}),(0,t.jsx)("div",{className:"text-sm text-text-secondary",children:"總社區券金額"})]})]}),(0,t.jsx)("div",{className:"bg-white border border-border-light rounded-xl overflow-hidden",children:(0,t.jsxs)("table",{className:"w-full",children:[(0,t.jsx)("thead",{className:"bg-bg-secondary",children:(0,t.jsxs)("tr",{children:[(0,t.jsx)("th",{className:"text-left py-3 px-4 text-sm font-medium text-text-primary",children:"服務類型"}),(0,t.jsx)("th",{className:"text-left py-3 px-4 text-sm font-medium text-text-primary",children:"次數"}),(0,t.jsx)("th",{className:"text-left py-3 px-4 text-sm font-medium text-text-primary",children:"時數"}),(0,t.jsx)("th",{className:"text-left py-3 px-4 text-sm font-medium text-text-primary",children:"單價"}),(0,t.jsx)("th",{className:"text-left py-3 px-4 text-sm font-medium text-text-primary",children:"金額"})]})}),(0,t.jsx)("tbody",{children:a.serviceTypeSummary&&a.serviceTypeSummary.map((e,r)=>(0,t.jsxs)("tr",{className:r%2==0?"bg-white":"bg-bg-secondary",children:[(0,t.jsx)("td",{className:"py-3 px-4 text-sm text-text-primary",children:e.service_type}),(0,t.jsx)("td",{className:"py-3 px-4 text-sm text-text-primary",children:e.count}),(0,t.jsx)("td",{className:"py-3 px-4 text-sm text-text-primary",children:e.total_hours.toFixed(1)}),(0,t.jsxs)("td",{className:"py-3 px-4 text-sm text-text-primary",children:["$",e.total_rate.toFixed(2)]}),(0,t.jsxs)("td",{className:"py-3 px-4 text-sm text-text-primary font-medium",children:["$",e.total_amount.toFixed(2)]})]},e.service_type))})]})})]}):(0,t.jsx)("div",{className:"text-center py-8",children:(0,t.jsx)("p",{className:"text-text-secondary",children:"暫無數據"})})}function G({filters:e,onCalendarExport:a,calendarExportLoading:l,isActive:d=!0,refreshTrigger:c=0}){let[m,x]=(0,n.useState)(()=>{if(e.dateRange?.start){let[t,r]=e.dateRange.start.split("-").map(Number);return new Date(t,r-1,1)}return new Date}),[p,u]=(0,n.useState)({}),[h,g]=(0,n.useState)(!1),[b,y]=(0,n.useState)(null),[_,j]=(0,n.useState)(!1),[N,w]=(0,n.useState)(null),[k,S]=(0,n.useState)([]),[C,D]=(0,n.useState)(!1),[M,F]=(0,n.useState)(!1),[z,L]=(0,n.useState)({}),R=(0,n.useRef)(!1),[E,I]=(0,n.useState)("all"),[P,O]=(0,n.useState)(null),[H,Y]=(0,n.useState)(!1),[U,W]=(0,n.useState)(()=>{let e=new Date;return`${e.getFullYear()}-${String(e.getMonth()+1).padStart(2,"0")}`}),[V,q]=(0,n.useState)(""),[J,Q]=(0,n.useState)(""),[ee,et]=(0,n.useState)(!1),[er,ea]=(0,n.useState)([]),[es,el]=(0,n.useState)(!1),[en,eo]=(0,n.useState)(0),[ei,ed]=(0,n.useState)(!1),[ec,em]=(0,n.useState)("ask"),[ex,ep]=(0,n.useState)("customer"),[eu,eh]=(0,n.useState)(null),[eg,ef]=(0,n.useState)([]),[eb,ev]=(0,n.useState)([]),[ey,e_]=(0,n.useState)(""),[ej,eN]=(0,n.useState)(!1),[ew,ek]=(0,n.useState)(e.dateRange.start);if(ew!==e.dateRange.start&&(ek(e.dateRange.start),e.dateRange.start)){let[t,r]=e.dateRange.start.split("-").map(Number);x(new Date(t,r-1,1))}let e$=(0,n.useRef)(0),eS=(0,n.useRef)(!1),eC=(0,n.useCallback)(async()=>{if(!eS.current||!d)return;let e=++e$.current,t=()=>eS.current&&e===e$.current;g(!0),y(null),u({});try{let{start:e,end:r}=(0,o.f)(m.getFullYear(),m.getMonth()+1),a=await (0,i.f)((t,a)=>s.supabase.from("billing_salary_data").select("*").gte("service_date",e).lte("service_date",r).order("service_date").order("id").range(t,a));if(!t())return;let l={};a.forEach(e=>{(l[e.service_date]||=[]).push(e)}),u(l)}catch(e){if(!t())return;u({}),y(e instanceof Error?e.message:"載入已儲存排程失敗，請重試")}finally{t()&&g(!1)}},[m,d]),eD=(0,n.useRef)(eC);(0,n.useEffect)(()=>{if(eD.current=eC,!d)return;eS.current=!0;let e=e$.current;return queueMicrotask(()=>{eS.current&&e===e$.current&&eC()}),()=>{eS.current=!1,e$.current+=1}},[d,eC,c]);let[eM,eF]=(0,n.useState)({isOpen:!1,schedule:null,dateStr:"",draftId:""}),[ez,eL]=(0,n.useState)(null),eR=()=>Object.values(z||{}).reduce((e,t)=>e+(t?.length||0),0),eT=()=>{let e=new Set;return[...Object.values(p),...Object.values(z)].forEach(t=>{(t||[]).forEach(t=>{t.customer_name&&e.add(t.customer_name)})}),Array.from(e).sort()},eE=()=>{if("all"===E)return z;let e={};return Object.entries(z).forEach(([t,r])=>{let a=r.filter(e=>e.customer_name===E);a.length>0&&(e[t]=a)}),e},eI=(0,n.useCallback)(()=>{let[e,t]=U.split("-").map(Number),{start:r,end:a}=(0,o.f)(e,t),{start:l,end:n}=(0,o.f)(e,t-1);return(0,i.f)((e,t)=>s.supabase.from("customer_personal_data").select("customer_id, customer_name, phone, service_address, customer_type").order("id").range(e,t)).then(async e=>{let t=await (0,i.f)((e,t)=>s.supabase.from("billing_salary_data").select("customer_id, customer_name, project_category").gte("service_date",l).lte("service_date",n).order("id").range(e,t)),o=new Map;(t||[]).forEach(e=>{let t=e.customer_id||e.customer_name;t&&!o.has(t)&&o.set(t,e.project_category||"")});let d=await (0,i.f)((e,t)=>s.supabase.from("billing_salary_data").select("customer_id, customer_name").gte("service_date",r).lte("service_date",a).order("id").range(e,t)),c=new Map,m=new Map;(d||[]).forEach(e=>{e.customer_id&&c.set(e.customer_id,(c.get(e.customer_id)||0)+1),e.customer_name&&m.set(e.customer_name,(m.get(e.customer_name)||0)+1)});let x=(e||[]).map(e=>{let t=e.customer_id||e.customer_name||"",r=o.has(t),a=o.get(t)||"",s=Math.max(e.customer_id&&c.get(e.customer_id)||0,e.customer_name&&m.get(e.customer_name)||0);return{customer_id:e.customer_id||"",customer_name:e.customer_name||"",phone:e.phone||"",service_address:e.service_address||"",customer_type:e.customer_type||"",project_category:a,hasLastMonthService:r,hasCurrentMonthSchedule:s>0,currentMonthScheduleCount:s}});V&&(x=x.filter(e=>e.customer_type===V)),J&&(x=x.filter(e=>e.project_category===J)),ee||(x=x.filter(e=>e.hasLastMonthService)),x.sort((e,t)=>e.hasLastMonthService!==t.hasLastMonthService?e.hasLastMonthService?-1:1:e.customer_name.localeCompare(t.customer_name,"zh-Hant")),ea(x)}).catch(e=>{console.error("載入客戶列表失敗:",e),alert("載入排程客戶失敗，請重試"),ea([])})},[U,V,J,ee]);(0,n.useEffect)(()=>{H&&eI().finally(()=>el(!1))},[H,eI]);let eP=(0,n.useRef)(null),eO=async()=>{if(R.current)return;let e=eE(),t=Object.values(e||{}).reduce((e,t)=>e+(t?.length||0),0);if(0===t)return void("all"===E?alert("沒有待儲存的排程"):alert(`沒有 ${E} 的待儲存排程`));let r="all"===E?"全部":E;if(confirm(`確定要儲存 ${r} 的 ${t} 個排程到資料庫嗎？`))try{R.current=!0,F(!0);let a=new Set(Object.values(e).flat().map(e=>e._draftId)),s=Object.values(e).flat().map(({_draftId:e,...t})=>t),l=JSON.stringify(s);eP.current?.payload!==l&&(eP.current={payload:l,key:crypto.randomUUID()});let n=await $(eP.current.key,s);if(!n.success)throw Error(n.error||"儲存排程失敗");eP.current=null,L(e=>Object.fromEntries(Object.entries(e).map(([e,t])=>[e,t.filter(e=>!a.has(e._draftId))]).filter(([,e])=>e.length>0))),eF(e=>a.has(e.draftId)?{isOpen:!1,schedule:null,dateStr:"",draftId:""}:e),ez&&a.has(ez.draftId)&&(eL(null),j(!1),w(null),S([]),D(!1)),await eD.current();let o=Object.values(e).flat(),i=Array.from(new Set(o.map(e=>e.care_staff_name).filter(e=>!!(e&&e.trim())))),d=Array.from(new Set(o.map(e=>e.customer_name).filter(e=>!!(e&&e.trim())))),c=Array.from(new Set(o.map(e=>e.customer_id).filter(e=>!!(e&&e.trim())))),m=Object.keys(e).sort(),x=m[0]||"",p=m[m.length-1]||"";ef(i),ev(d);let u={dateRange:{start:x,end:p}};c.length>0?u.selectedCustomerIds=c:1===d.length?u.searchTerm=d[0]:"all"!==E?u.searchTerm=E:d.length>0&&(u.searchTerm=d[0]),eh(u),alert(`成功儲存 ${r} 的 ${t} 個排程到資料庫！`),em("ask"),ep("customer"),e_(""),ed(!0)}catch(t){console.error("儲存本地排程失敗:",t);let e=t instanceof Error?t.message:"未知錯誤";alert(`儲存排程時發生錯誤: ${e}`)}finally{R.current=!1,F(!1)}},eH=e=>{ep(e),"staff"===e&&eg.length>1?em("staffPicker"):"staff"===e&&1===eg.length?(e_(eg[0]),eB(eu,"staff",eg[0])):eB(eu,"customer","")},eB=async(e,t,a)=>{eN(!0);try{let s="staff"===t&&a?{...e,careStaffName:a}:e;console.log("📅 導出日曆 - 篩選條件:",JSON.stringify(s,null,2));let l=await T({format:"pdf",filters:s,includeStaffDetails:!0,includeCustomerDetails:!1,timezone:"Asia/Hong_Kong",nameMode:t,selectedStaffName:"staff"===t?a:void 0});if(l.success&&l.data){let e=l.data,t=window.open("","_blank");if(t&&t.document)t.opener=null,t.document.open(),t.document.write((0,r.f)(e)),t.document.close();else{let t=new Blob([(0,r.f)(e)],{type:"text/html;charset=utf-8"}),a=URL.createObjectURL(t);window.location.href=a,setTimeout(()=>URL.revokeObjectURL(a),6e4)}ed(!1)}else alert(`日曆導出失敗: ${l.error}`)}catch(e){console.error("日曆導出錯誤:",e),alert("日曆導出失敗，請稍後再試")}finally{eN(!1)}},eY=async e=>{if(!R.current){F(!0);try{if(ez){let{originalDateStr:t,draftId:r}=ez,a=e.service_date;console.log("編輯排程 - 原日期:",t,"新日期:",a),L(s=>{let l={...s};return l[t]&&(l[t]=l[t].filter(e=>e._draftId!==r),0===l[t].length&&delete l[t]),l[a]=[...l[a]||[],{...e,_draftId:r}],console.log("更新後的本地排程:",l),l}),alert("成功更新排班記錄"),eL(null)}else if(k.length>1)k.forEach(t=>{let r={...e,service_date:t,_draftId:crypto.randomUUID()};L(e=>({...e,[t]:[...e[t]||[],r]}))}),alert(`成功添加 ${k.length} 筆排班記錄到月曆`);else{let t=e.service_date,r={...e,_draftId:crypto.randomUUID()};L(e=>({...e,[t]:[...e[t]||[],r]})),alert("成功添加排班記錄到月曆")}j(!1),w(null),S([]),D(!1)}catch(e){console.error("處理排班失敗:",e),alert("處理排班失敗，請重試")}finally{F(!1)}}},eA=e=>{let t=new Date(m);t.setMonth(m.getMonth()+("next"===e?1:-1)),x(t)},eU=(()=>{let e=new Date(m.getFullYear(),m.getMonth(),1),t=new Date(e);t.setDate(t.getDate()-e.getDay());let r=[],a=new Date(t);for(let e=0;e<42;e++)r.push(new Date(a)),a.setDate(a.getDate()+1);return r})(),eW=m.getMonth();return(0,t.jsxs)("div",{className:"space-y-8",children:[(0,t.jsx)("div",{className:"card-apple border border-border-light fade-in-apple",children:(0,t.jsxs)("div",{className:"p-6",children:[(0,t.jsxs)("div",{className:"flex justify-between items-center mb-6",children:[(0,t.jsxs)("div",{className:"flex items-center space-x-4",children:[(0,t.jsx)("div",{className:"relative",children:(0,t.jsxs)("button",{onClick:()=>{el(!0),Y(!0)},className:`px-4 py-2 rounded-xl border transition-all duration-300 flex items-center gap-2 ${P?"bg-green-50 border-green-300 text-green-700":"border-border-light hover:bg-bg-secondary text-text-secondary"}`,children:[(0,t.jsx)("span",{children:"📋"}),(0,t.jsx)("span",{className:"max-w-[120px] truncate",children:P?P.customer_name:"選擇客戶"}),P&&(0,t.jsx)("button",{onClick:e=>{e.stopPropagation(),O(null)},className:"ml-1 p-0.5 hover:bg-green-200 rounded-full transition-colors",title:"清除已選客戶",children:(0,t.jsx)("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M6 18L18 6M6 6l12 12"})})})]})}),(0,t.jsx)("h3",{className:"text-apple-heading text-text-primary",children:"月曆排班"}),eT().length>0&&(0,t.jsxs)("div",{className:"flex items-center space-x-2",children:[(0,t.jsx)("span",{className:"text-sm text-text-secondary",children:"顯示客戶:"}),(0,t.jsxs)("select",{value:E,onChange:e=>I(e.target.value),className:"form-input-apple pr-10 appearance-none cursor-pointer",children:[(0,t.jsx)("option",{value:"all",children:"全部客戶"}),eT().map(e=>(0,t.jsx)("option",{value:e,children:e},e))]})]})]}),(0,t.jsxs)("div",{className:"flex items-center gap-4",children:[(0,t.jsx)("button",{onClick:a,disabled:l,className:"btn-apple-secondary bg-purple-500 text-white hover:bg-purple-600 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2",title:"導出 PDF 日曆報表",children:l?(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("div",{className:"animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"}),(0,t.jsx)("span",{children:"產生中..."})]}):(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M19 7v10a2 2 0 01-2 2H7a2 2 0 01-2-2V7m12 4l-4 4-4-4m4 4V3"})}),(0,t.jsx)("span",{children:"導出日曆 PDF"})]})}),C&&k.length>0&&(0,t.jsxs)("div",{className:"text-sm text-text-secondary",children:["已選擇 ",k.length," 天"]}),eR()>0&&(0,t.jsx)("div",{className:"text-sm text-orange-600 font-medium",children:"all"===E?`待儲存 ${eR()} 個排程`:`${E}: ${Object.values(eE()).reduce((e,t)=>e+t.length,0)} 個排程`}),(0,t.jsx)("button",{onClick:()=>{D(!C),S([]),w(null)},className:`px-4 py-2 rounded-xl border transition-all duration-300 ${C?"bg-primary text-white border-primary":"border-border-light hover:bg-bg-secondary text-text-secondary"}`,children:C?"取消多選":"多天排班"}),C&&k.length>0&&(0,t.jsx)("button",{onClick:()=>{j(!0)},className:"px-4 py-2 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-all duration-300",children:"確認排班"}),eR()>0&&(0,t.jsx)("button",{onClick:eO,disabled:M,className:`px-4 py-2 rounded-xl transition-all duration-300 ${M?"bg-text-tertiary text-white cursor-not-allowed":"bg-orange-600 text-white hover:bg-orange-700"}`,children:M?"儲存中...":"all"===E?"確認儲存全部":`儲存 ${E}`})]})]}),(0,t.jsxs)("div",{className:"flex justify-between items-center mb-6",children:[(0,t.jsx)("button",{onClick:()=>eA("prev"),className:"p-2 rounded-xl border border-border-light hover:bg-bg-secondary transition-all duration-300",children:(0,t.jsx)("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M15 19l-7-7 7-7"})})}),(0,t.jsxs)("h4",{className:"text-lg font-medium text-text-primary",children:[m.getFullYear(),"年 ",m.getMonth()+1,"月 排班表"]}),(0,t.jsx)("button",{onClick:()=>eA("next"),className:"p-2 rounded-xl border border-border-light hover:bg-bg-secondary transition-all duration-300",children:(0,t.jsx)("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M9 5l7 7-7 7"})})})]}),h&&(0,t.jsx)("p",{role:"status",className:"mb-4 text-sm text-text-secondary",children:"正在載入已儲存排程..."}),b&&(0,t.jsxs)("div",{role:"alert",className:"mb-4 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700",children:[(0,t.jsxs)("p",{children:["載入已儲存排程失敗：",b]}),(0,t.jsx)("button",{type:"button",onClick:eC,className:"mt-2 underline",children:"重新載入已儲存排程"})]}),(0,t.jsx)("div",{className:"grid grid-cols-7 gap-1 mb-2",children:["週日","週一","週二","週三","週四","週五","週六"].map(e=>(0,t.jsx)("div",{className:"p-3 text-center text-sm font-medium text-text-secondary bg-bg-secondary rounded-xl",children:e},e))}),(0,t.jsx)("div",{className:"grid grid-cols-7 gap-1",children:eU&&eU.map((e,r)=>{let a=A(e),s=e.getMonth()===eW,l=a===A(new Date),n=0===e.getDay()||6===e.getDay(),o=B(e),i=k.includes(a),d=(p[a]||[]).filter(e=>"all"===E||e.customer_name===E),c=eE()[a]||[],m=[...d,...c],x=m.length>0?Math.max(140,140+(m.length-1)*90):140;return(0,t.jsxs)("div",{onClick:()=>{let t;return s&&(t=A(e),void(C?k.includes(t)?S(e=>e.filter(e=>e!==t)):S(e=>[...e,t]):(w(t),S([t]),j(!0))))},style:{minHeight:`${x}px`},className:`
                    p-2 border-2 rounded-xl cursor-pointer
                    transition-all duration-300 hover:shadow-md
                    ${!s?"bg-bg-secondary text-text-tertiary border-border-light":i?"bg-green-100 border-green-500 border-2":o.isHoliday?"bg-red-50 border-red-300":n?"bg-blue-50 border-blue-200":"bg-bg-primary border-border-light"}
                    ${l?"ring-2 ring-primary border-primary":""}
                    hover:border-primary
                  `,children:[(0,t.jsxs)("div",{className:`
                    text-lg font-bold mb-3 flex justify-between items-center
                    ${l?"text-primary":o.isHoliday?"text-red-600":s?"text-text-primary":"text-text-tertiary"}
                  `,children:[(0,t.jsxs)("div",{className:"flex flex-col",children:[(0,t.jsx)("span",{children:e.getDate()}),o.isHoliday&&o.name&&"星期日"!==o.name&&(0,t.jsx)("span",{className:"text-xs text-red-500 font-normal truncate max-w-[80px]",title:o.name,children:o.name.length>5?o.name.substring(0,5)+"..":o.name})]}),s&&(0,t.jsx)("span",{className:"text-base text-green-600",children:"+"})]}),s&&(0,t.jsxs)("div",{className:"space-y-2",children:[(d||[]).map(e=>(0,t.jsxs)("div",{"data-schedule-status":"saved",onClick:e=>e.stopPropagation(),className:"text-base bg-white border border-border-light rounded p-3 shadow-sm",children:[(0,t.jsx)("div",{className:"mb-2 text-xs font-medium text-green-700",children:"已儲存"}),(0,t.jsxs)("div",{className:"font-medium text-text-primary mb-2 text-base break-words leading-tight",children:[e.customer_name,"/",e.care_staff_name]}),(0,t.jsx)("div",{className:"text-blue-600 mb-2 text-base break-words leading-tight",children:e.service_type}),(0,t.jsxs)("div",{className:"text-text-secondary text-base font-medium",children:[e.start_time,"-",e.end_time]})]},`remote-${e.id}`)),(c||[]).map(e=>(0,t.jsxs)("div",{"data-schedule-status":"draft",onClick:t=>{t.stopPropagation(),M||eF({isOpen:!0,schedule:e,dateStr:a,draftId:e._draftId})},className:"text-base bg-yellow-50 border-2 border-yellow-300 rounded p-3 shadow-sm cursor-pointer hover:bg-yellow-100 transition-colors relative group",children:[(0,t.jsx)("div",{className:"mb-2 text-xs font-medium text-orange-700",children:"待儲存"}),(0,t.jsx)("div",{className:"absolute inset-0 bg-blue-500 bg-opacity-0 group-hover:bg-opacity-20 rounded flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all",children:(0,t.jsx)("span",{className:"text-blue-700 font-bold text-sm",children:"點擊編輯"})}),(0,t.jsxs)("div",{className:"font-medium text-text-primary mb-2 text-base break-words leading-tight",children:[e.customer_name,"/",e.care_staff_name]}),(0,t.jsx)("div",{className:"text-blue-600 mb-2 text-base break-words leading-tight",children:e.service_type}),(0,t.jsxs)("div",{className:"text-text-secondary text-base font-medium",children:[e.start_time,"-",e.end_time]})]},e._draftId))]})]},r)})})]})}),(0,t.jsx)("div",{className:"card-apple border border-border-light fade-in-apple",children:(0,t.jsxs)("div",{className:"p-6",children:[(0,t.jsx)("h3",{className:"text-apple-heading text-text-primary mb-4",children:"排班說明"}),(0,t.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4 text-sm",children:[(0,t.jsxs)("div",{className:"flex items-center gap-2",children:[(0,t.jsx)("div",{className:"w-4 h-4 bg-blue-50 border-2 border-blue-200 rounded"}),(0,t.jsx)("span",{className:"text-text-secondary",children:"週末"})]}),(0,t.jsxs)("div",{className:"flex items-center gap-2",children:[(0,t.jsx)("div",{className:"w-4 h-4 bg-white border border-border-light rounded"}),(0,t.jsx)("span",{className:"text-text-secondary",children:"已儲存排程"})]}),(0,t.jsxs)("div",{className:"flex items-center gap-2",children:[(0,t.jsx)("div",{className:"w-4 h-4 bg-yellow-50 border-2 border-yellow-300 rounded"}),(0,t.jsx)("span",{className:"text-text-secondary",children:"待儲存排程（點擊編輯）"})]})]})]})}),(0,t.jsx)("div",{className:"card-apple border border-border-light fade-in-apple",children:(0,t.jsx)("div",{className:"p-6",children:(0,t.jsx)(K,{localSchedules:z,updateTrigger:en})})}),d&&_&&(0,t.jsx)(Z,{isOpen:_,onClose:()=>{j(!1),w(null),S([]),D(!1),eL(null)},selectedDate:N,selectedDates:k,existingRecord:ez?.schedule?{id:"local-edit",created_at:new Date().toISOString(),updated_at:new Date().toISOString(),service_date:ez.schedule.service_date,customer_id:ez.schedule.customer_id,customer_name:ez.schedule.customer_name,phone:ez.schedule.phone,service_address:ez.schedule.service_address,start_time:ez.schedule.start_time,end_time:ez.schedule.end_time,service_hours:ez.schedule.service_hours,staff_id:ez.schedule.staff_id,care_staff_name:ez.schedule.care_staff_name,service_fee:ez.schedule.service_fee,staff_salary:ez.schedule.staff_salary,hourly_rate:ez.schedule.hourly_rate,hourly_salary:ez.schedule.hourly_salary,service_type:ez.schedule.service_type,project_category:ez.schedule.project_category,project_manager:ez.schedule.project_manager}:null,preselectedCustomer:ez?null:P,onSubmit:eY}),d&&eM.isOpen&&(0,t.jsx)(X,{isOpen:eM.isOpen,schedule:eM.schedule,onClose:()=>eF({isOpen:!1,schedule:null,dateStr:"",draftId:""}),onUpdate:e=>{if(R.current)return;let{dateStr:t,draftId:r}=eM;L(a=>{let s={...a};return s[t]&&(s[t]=s[t].map(t=>t._draftId===r?{...e,_draftId:r}:t)),s}),eF({isOpen:!1,schedule:null,dateStr:"",draftId:""}),eo(e=>e+1)},onDelete:()=>{let{dateStr:e,draftId:t}=eM;R.current||(L(r=>{let a={...r};return a[e]&&(a[e]=a[e].filter(e=>e._draftId!==t),0===a[e].length&&delete a[e]),a}),eo(e=>e+1)),eF({isOpen:!1,schedule:null,dateStr:"",draftId:""})},onEdit:()=>{if(R.current)return;let{dateStr:e,draftId:t,schedule:r}=eM;r&&(console.log("開始編輯本地排程:",{originalDate:e,draftId:t,scheduleDate:r.service_date}),eL({originalDateStr:e,draftId:t,schedule:r}),w(r.service_date),S([]),D(!1),eF({isOpen:!1,schedule:null,dateStr:"",draftId:""}),j(!0))}}),H&&(0,t.jsx)("div",{className:"fixed inset-0 bg-black/50 z-[10001] flex items-center justify-center",onClick:()=>Y(!1),children:(0,t.jsxs)("div",{className:"bg-white rounded-xl w-[90%] max-w-2xl max-h-[80vh] overflow-hidden shadow-2xl z-[10002]",onClick:e=>e.stopPropagation(),children:[(0,t.jsxs)("div",{className:"p-4 border-b border-border-light bg-bg-secondary",children:[(0,t.jsxs)("div",{className:"flex items-center justify-between mb-3",children:[(0,t.jsx)("h3",{className:"text-lg font-bold text-text-primary",children:"📋 選擇客戶（排班前置）"}),(0,t.jsx)("button",{type:"button",onClick:()=>Y(!1),className:"p-1 hover:bg-bg-tertiary rounded-lg transition-colors",children:(0,t.jsx)("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M6 18L18 6M6 6l12 12"})})})]}),P&&(0,t.jsxs)("div",{className:"mb-3 p-2 bg-green-50 border border-green-200 rounded-lg flex items-center justify-between",children:[(0,t.jsxs)("span",{className:"text-green-700 text-sm",children:["✅ 已選: ",(0,t.jsx)("strong",{children:P.customer_name})]}),(0,t.jsx)("button",{onClick:()=>O(null),className:"text-green-600 hover:text-green-800 text-sm",children:"清除"})]}),(0,t.jsxs)("div",{className:"flex flex-wrap gap-2",children:[(0,t.jsx)("input",{type:"month",value:U,onChange:e=>{el(!0),W(e.target.value)},className:"px-3 py-1.5 border border-border-light rounded-lg text-sm"}),(0,t.jsxs)("select",{value:V,onChange:e=>{el(!0),q(e.target.value)},className:"px-3 py-1.5 border border-border-light rounded-lg text-sm",children:[(0,t.jsx)("option",{value:"",children:"全部類型"}),v.filter(e=>"家訪客戶"!==e).map(e=>(0,t.jsx)("option",{value:e,children:e},e))]}),(0,t.jsxs)("select",{value:J,onChange:e=>{el(!0),Q(e.target.value)},className:"px-3 py-1.5 border border-border-light rounded-lg text-sm",children:[(0,t.jsx)("option",{value:"",children:"全部項目"}),f.map(e=>(0,t.jsx)("option",{value:e.value,children:e.label},e.value))]}),(0,t.jsx)("button",{type:"button",onClick:()=>{el(!0),et(!ee)},className:`px-3 py-1.5 rounded-lg text-sm transition-colors ${ee?"bg-gray-200 text-gray-700":"bg-blue-500 text-white"}`,children:ee?"顯示全部":"只顯示上月有服務"})]})]}),(0,t.jsx)("div",{className:"overflow-y-auto max-h-[50vh]",children:es?(0,t.jsxs)("div",{className:"p-8 text-center text-text-secondary",children:[(0,t.jsx)("div",{className:"animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full mx-auto mb-2"}),"載入中..."]}):0===er.length?(0,t.jsx)("div",{className:"p-8 text-center text-text-secondary",children:"沒有符合條件的客戶"}):(0,t.jsx)("div",{className:"divide-y divide-border-light",children:er.map((e,r)=>(0,t.jsx)("div",{onClick:()=>{O({customer_id:e.customer_id,customer_name:e.customer_name,phone:e.phone,service_address:e.service_address,project_category:e.project_category}),Y(!1)},className:`p-3 hover:bg-bg-secondary cursor-pointer transition-colors ${P?.customer_id===e.customer_id?"bg-green-50":""}`,children:(0,t.jsxs)("div",{className:"flex items-start justify-between",children:[(0,t.jsxs)("div",{className:"flex-1",children:[(0,t.jsxs)("div",{className:"flex items-center gap-2 flex-wrap",children:[(0,t.jsx)("span",{className:"font-medium text-text-primary",children:e.customer_name}),e.hasLastMonthService&&(0,t.jsx)("span",{className:"px-1.5 py-0.5 bg-blue-100 text-blue-700 text-xs rounded",children:"上月有服務"}),e.currentMonthScheduleCount>0?(0,t.jsxs)("span",{className:"px-1.5 py-0.5 bg-green-100 text-green-700 text-xs rounded",children:["本月已排 ",e.currentMonthScheduleCount," 更"]}):(0,t.jsx)("span",{className:"px-1.5 py-0.5 bg-orange-100 text-orange-700 text-xs rounded",children:"本月未排更"})]}),(0,t.jsxs)("div",{className:"text-xs text-text-secondary mt-1",children:[e.customer_id&&(0,t.jsx)("span",{className:"mr-2",children:e.customer_id}),e.phone&&(0,t.jsxs)("span",{className:"mr-2",children:["📞 ",e.phone]})]}),(0,t.jsxs)("div",{className:"text-xs text-text-tertiary mt-0.5 truncate",children:["📍 ",e.service_address||"未設定地址"]})]}),(0,t.jsxs)("div",{className:"text-right text-xs",children:[(0,t.jsx)("div",{className:"text-text-secondary",children:e.customer_type}),e.project_category&&(0,t.jsx)("div",{className:"text-text-tertiary",children:e.project_category})]})]})},e.customer_id||r))})}),(0,t.jsx)("div",{className:"p-3 border-t border-border-light bg-bg-secondary text-xs text-text-secondary",children:"💡 選擇客戶後，點擊月曆日期新增排班時會自動填入客戶資料"})]})}),ei&&(0,t.jsx)("div",{className:"fixed inset-0 bg-black/50 z-[10001] flex items-center justify-center",onClick:()=>ed(!1),children:(0,t.jsxs)("div",{className:"bg-white rounded-2xl w-[90%] max-w-md overflow-hidden shadow-2xl z-[10002] animate-in fade-in zoom-in-95 relative",onClick:e=>e.stopPropagation(),children:["ask"===ec&&(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)("div",{className:"p-6 pb-2 text-center",children:[(0,t.jsx)("div",{className:"w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4",children:(0,t.jsx)("span",{className:"text-3xl",children:"✅"})}),(0,t.jsx)("h3",{className:"text-lg font-bold text-text-primary mb-2",children:"排程儲存成功！"}),(0,t.jsxs)("p",{className:"text-sm text-text-secondary",children:[eb.length>0&&(0,t.jsxs)("span",{className:"block mb-1",children:["客戶：",eb.length<=2?eb.join("、"):`${eb[0]} 等 ${eb.length} 位`]}),"需要導出剛才入更的日曆 PDF 嗎？"]})]}),(0,t.jsxs)("div",{className:"p-4 flex gap-3",children:[(0,t.jsx)("button",{onClick:()=>ed(!1),className:"flex-1 px-4 py-3 rounded-xl border border-border-light text-text-secondary hover:bg-bg-secondary transition-all duration-200 font-medium",children:"唔需要"}),(0,t.jsx)("button",{onClick:()=>em("nameMode"),className:"flex-1 px-4 py-3 rounded-xl bg-primary text-white hover:bg-primary/90 transition-all duration-200 font-medium shadow-lg shadow-primary/25",children:"要，導出 PDF"})]})]}),"nameMode"===ec&&(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)("div",{className:"p-6 pb-2",children:[(0,t.jsxs)("div",{className:"flex items-center gap-3 mb-4",children:[(0,t.jsx)("button",{onClick:()=>em("ask"),className:"p-1 hover:bg-bg-secondary rounded-lg transition-colors",children:(0,t.jsx)("svg",{className:"w-5 h-5 text-text-secondary",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M15 19l-7-7 7-7"})})}),(0,t.jsx)("h3",{className:"text-lg font-bold text-text-primary",children:"PDF 檔案名稱"})]}),(0,t.jsx)("p",{className:"text-sm text-text-secondary mb-4",children:"請選擇 PDF 檔案名稱使用邊個名稱："}),(0,t.jsxs)("div",{className:"space-y-3",children:[(0,t.jsx)("button",{onClick:()=>eH("customer"),disabled:ej,className:"w-full p-4 rounded-xl border-2 border-border-light hover:border-primary hover:bg-primary/5 transition-all duration-200 text-left group disabled:opacity-50",children:(0,t.jsxs)("div",{className:"flex items-center gap-3",children:[(0,t.jsx)("div",{className:"w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center group-hover:bg-blue-200 transition-colors",children:(0,t.jsx)("span",{className:"text-xl",children:"👤"})}),(0,t.jsxs)("div",{children:[(0,t.jsx)("div",{className:"font-medium text-text-primary",children:"客戶名稱"}),(0,t.jsx)("div",{className:"text-xs text-text-secondary mt-0.5",children:eb.length>0?`例如：${eb[0]} ...更表`:"以客戶名稱作為檔案名稱"})]})]})}),(0,t.jsx)("button",{onClick:()=>eH("staff"),disabled:ej,className:"w-full p-4 rounded-xl border-2 border-border-light hover:border-purple-500 hover:bg-purple-50 transition-all duration-200 text-left group disabled:opacity-50",children:(0,t.jsxs)("div",{className:"flex items-center gap-3",children:[(0,t.jsx)("div",{className:"w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center group-hover:bg-purple-200 transition-colors",children:(0,t.jsx)("span",{className:"text-xl",children:"👨‍⚕️"})}),(0,t.jsxs)("div",{children:[(0,t.jsx)("div",{className:"font-medium text-text-primary",children:"護理人員名稱"}),(0,t.jsx)("div",{className:"text-xs text-text-secondary mt-0.5",children:eg.length>0?`例如：${eg[0]} ...更表${eg.length>1?`（共 ${eg.length} 位）`:""}`:"以護理人員名稱作為檔案名稱"})]})]})})]})]}),(0,t.jsx)("div",{className:"p-4 pt-2",children:(0,t.jsx)("button",{onClick:()=>ed(!1),className:"w-full px-4 py-2 text-sm text-text-tertiary hover:text-text-secondary transition-colors",children:"取消"})}),ej&&(0,t.jsx)("div",{className:"absolute inset-0 bg-white/80 flex items-center justify-center rounded-2xl",children:(0,t.jsxs)("div",{className:"text-center",children:[(0,t.jsx)("div",{className:"animate-spin rounded-full h-8 w-8 border-3 border-primary border-t-transparent mx-auto mb-2"}),(0,t.jsx)("p",{className:"text-sm text-text-secondary",children:"正在產生日曆 PDF..."})]})})]}),"staffPicker"===ec&&(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)("div",{className:"p-6 pb-2",children:[(0,t.jsxs)("div",{className:"flex items-center gap-3 mb-4",children:[(0,t.jsx)("button",{onClick:()=>em("nameMode"),className:"p-1 hover:bg-bg-secondary rounded-lg transition-colors",children:(0,t.jsx)("svg",{className:"w-5 h-5 text-text-secondary",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M15 19l-7-7 7-7"})})}),(0,t.jsx)("h3",{className:"text-lg font-bold text-text-primary",children:"選擇護理人員"})]}),(0,t.jsxs)("p",{className:"text-sm text-text-secondary mb-4",children:["排程中有 ",eg.length," 位護理人員，請選擇要用邊位嘅名稱："]}),(0,t.jsx)("div",{className:"space-y-2 max-h-[40vh] overflow-y-auto",children:eg.map((e,r)=>(0,t.jsxs)("button",{onClick:()=>{e_(e),eB(eu,"staff",e)},disabled:ej,className:"w-full p-3 rounded-xl border border-border-light hover:border-purple-500 hover:bg-purple-50 transition-all duration-200 text-left flex items-center gap-3 disabled:opacity-50",children:[(0,t.jsx)("div",{className:"w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0",children:(0,t.jsx)("span",{className:"text-sm",children:"👨‍⚕️"})}),(0,t.jsx)("div",{children:(0,t.jsx)("div",{className:"font-medium text-text-primary text-sm",children:e})})]},r))})]}),(0,t.jsx)("div",{className:"p-4 pt-2",children:(0,t.jsx)("button",{onClick:()=>ed(!1),className:"w-full px-4 py-2 text-sm text-text-tertiary hover:text-text-secondary transition-colors",children:"取消"})}),ej&&(0,t.jsx)("div",{className:"absolute inset-0 bg-white/80 flex items-center justify-center rounded-2xl",children:(0,t.jsxs)("div",{className:"text-center",children:[(0,t.jsx)("div",{className:"animate-spin rounded-full h-8 w-8 border-3 border-primary border-t-transparent mx-auto mb-2"}),(0,t.jsx)("p",{className:"text-sm text-text-secondary",children:"正在產生日曆 PDF..."})]})})]})]})})]})}function Q({filters:e,setFilters:r,updateDateRange:a,exportLoading:l,handleExport:o,onCalendarExport:i,calendarExportLoading:c,onEdit:m,onDelete:x,refreshTrigger:u,onRefresh:b,recordUpdateTimes:v}){let[y,_]=(0,n.useState)([]),[j,N]=(0,n.useState)(!0),[w,k]=(0,n.useState)(""),[$,S]=(0,n.useState)([]),[C,D]=(0,n.useState)(!1),[M,z]=(0,n.useState)(!1),[L,R]=(0,n.useState)([]),T=(0,n.useRef)(null),[E,I]=(0,n.useState)({top:0,left:0,width:0}),[P,O]=(0,n.useState)(!1),H=Array.isArray(e.projectCategory)?e.projectCategory:e.projectCategory?[e.projectCategory]:[],B=()=>{if(T.current){let e=T.current.getBoundingClientRect();I({top:e.bottom+window.scrollY,left:e.left+window.scrollX,width:e.width})}};(0,n.useEffect)(()=>{let e=e=>{let t=e.target;t.closest(".customer-search-container")||D(!1),t.closest(".project-category-dropdown")||O(!1)};return document.addEventListener("mousedown",e),()=>document.removeEventListener("mousedown",e)},[]);let Y=(0,n.useCallback)(()=>F().then(async e=>{e.success&&e.data&&_(e.data||[])}).catch(e=>{console.error("載入護理人員列表失敗:",e)}),[]);(0,n.useEffect)(()=>{Y().finally(()=>N(!1))},[Y]);let W=async e=>{if(console.log("客戶搜尋開始:",e),e.length<1){S([]),D(!1);return}try{z(!0),console.log("使用 Supabase 直接進行客戶搜尋");let{data:t,error:r}=await s.supabase.from("customer_personal_data").select("customer_id, customer_name, phone, service_address").or(`customer_name.ilike.%${e.trim()}%,customer_id.ilike.%${e.trim()}%,phone.ilike.%${e.trim()}%,service_address.ilike.%${e.trim()}%`).limit(10);if(r){console.error("Supabase 客戶搜尋錯誤:",r),S([]),D(!1);return}let a=(t||[]).map(e=>({customer_id:e.customer_id||"",customer_name:e.customer_name||"",phone:e.phone||"",service_address:e.service_address||"",display_text:e.customer_name||"",type:"customer"}));console.log("客戶搜尋結果:",a),S(a),D(!0),console.log("設定建議列表:",a.length,"筆資料")}catch(e){console.error("客戶搜尋失敗:",e),S([]),D(!1)}finally{z(!1)}},V=e=>{console.log("切換客戶選擇:",e.customer_name),R(t=>{let r;return t.some(t=>t.customer_id===e.customer_id)?(r=(t||[]).filter(t=>t.customer_id!==e.customer_id),console.log("移除客戶:",e.customer_name)):(r=[...t||[],e],console.log("新增客戶:",e.customer_name)),r})};return(0,n.useEffect)(()=>{if(L&&L.length>0){let e=(L||[]).map(e=>e?.customer_id).filter(e=>e);r(t=>({...t,selectedCustomerIds:e,searchTerm:""})),console.log("設定客戶篩選條件:",e)}else r(e=>({...e,selectedCustomerIds:void 0,searchTerm:""})),console.log("清除客戶篩選條件")},[L,r]),(0,t.jsxs)("div",{className:"space-y-6",children:[(0,t.jsxs)("div",{className:"card-apple mb-4 sm:mb-6 fade-in-apple relative z-50",style:{overflow:"visible"},children:[(0,t.jsx)("div",{className:"card-apple-header border-b border-border-light",children:(0,t.jsxs)("div",{className:"flex items-center justify-between",children:[(0,t.jsx)("h3",{className:"text-lg sm:text-xl font-semibold text-text-primary",children:"搜尋與篩選"}),(0,t.jsxs)("div",{className:"flex space-x-2",children:[(0,t.jsx)("button",{onClick:()=>{let e=A(new Date);r(t=>({...t,dateRange:{start:e,end:e}}))},className:"btn-apple-secondary text-xs sm:text-sm",children:"今日"}),(0,t.jsx)("button",{onClick:()=>a("thisMonth"),className:"btn-apple-primary text-xs sm:text-sm",children:"本月"})]})]})}),(0,t.jsxs)("div",{className:"card-apple-content",style:{overflow:"visible"},children:[(0,t.jsxs)("div",{className:"flex flex-wrap items-center gap-3 mb-5 pb-5 border-b border-border-light",children:[(0,t.jsx)("span",{className:"text-sm font-medium text-text-secondary",children:"日期範圍"}),(0,t.jsxs)("div",{className:"flex items-center gap-2 bg-bg-secondary rounded-xl px-4 py-2",children:[(0,t.jsx)("input",{type:"date",value:e.dateRange?.start||"",onChange:e=>r(t=>({...t,dateRange:{...t.dateRange,start:e.target.value}})),className:"bg-transparent border-none text-sm text-text-primary focus:outline-none focus:ring-0"}),(0,t.jsx)("span",{className:"text-text-tertiary",children:"至"}),(0,t.jsx)("input",{type:"date",value:e.dateRange?.end||"",onChange:e=>r(t=>({...t,dateRange:{...t.dateRange,end:e.target.value}})),className:"bg-transparent border-none text-sm text-text-primary focus:outline-none focus:ring-0"})]})]}),(0,t.jsxs)("div",{className:"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4",style:{overflow:"visible"},children:[(0,t.jsxs)("div",{className:"relative z-50",style:{overflow:"visible"},children:[(0,t.jsx)("label",{className:"block text-xs font-medium text-text-secondary mb-1.5",children:"客戶"}),(0,t.jsxs)("div",{className:"relative customer-search-container",style:{overflow:"visible"},children:[(0,t.jsx)("svg",{className:"absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-text-tertiary",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"})}),(0,t.jsx)("input",{ref:T,type:"text",placeholder:"姓名/編號/電話",value:w,onChange:e=>{var t;k(t=e.target.value),L&&0!==L.length||r(e=>({...e,searchTerm:t})),t.length>=1?(B(),W(t)):(S([]),D(!1))},onFocus:()=>{console.log("輸入框被點擊"),B(),w.length>=1&&($.length>0?D(!0):W(w))},onBlur:()=>{console.log("輸入框失去焦點"),setTimeout(()=>{D(!1)},150)},className:"w-full pl-9 pr-4 py-2.5 bg-bg-secondary border border-border-light rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all"}),C&&(0,d.createPortal)((0,t.jsx)("div",{className:"fixed bg-white border border-border-light rounded-xl shadow-2xl max-h-48 overflow-y-auto z-[9999]",style:{top:`${Math.min(E.top,window.innerHeight-250)}px`,left:`${Math.max(8,Math.min(E.left,window.innerWidth-E.width-8))}px`,width:`${Math.min(E.width,window.innerWidth-16)}px`,backgroundColor:"#ffffff",border:"1px solid #e5e7eb"},onMouseDown:e=>{console.log("下拉選單被點擊"),e.preventDefault()},children:M?(0,t.jsx)("div",{className:"p-3 text-center text-text-secondary",children:(0,t.jsx)("div",{className:"animate-spin rounded-full h-4 w-4 border-2 border-primary border-t-transparent mx-auto"})}):$&&$.length>0?$.map((e,r)=>(0,t.jsxs)("div",{className:"p-3 hover:bg-bg-secondary cursor-pointer border-b border-border-light last:border-b-0 flex items-center transition-colors",onMouseDown:t=>{console.log("選項被點擊:",e.customer_name),t.preventDefault(),t.stopPropagation(),V(e)},children:[(0,t.jsx)("input",{type:"checkbox",checked:L.some(t=>t.customer_id===e.customer_id),className:"mr-3 rounded border-border-light focus:ring-primary pointer-events-none",readOnly:!0}),(0,t.jsxs)("div",{className:"flex-1",children:[(0,t.jsx)("div",{className:"font-medium text-text-primary",children:e.customer_name}),(0,t.jsxs)("div",{className:"text-sm text-text-secondary",children:[e.customer_id," ",e.phone&&`• ${e.phone}`]})]})]},`${e.customer_id}-${r}`)):(0,t.jsx)("div",{className:"p-3 text-center text-text-secondary text-sm",children:"沒有找到相關客戶"})}),document.body)]}),L&&L.length>0&&(0,t.jsx)("div",{className:"mt-2 flex flex-wrap gap-1.5",children:L&&L.map(e=>(0,t.jsxs)("div",{className:"inline-flex items-center bg-primary text-white text-xs px-2.5 py-1 rounded-full",children:[(0,t.jsx)("span",{className:"mr-1.5 truncate max-w-[100px]",children:e.customer_name}),(0,t.jsx)("button",{onClick:()=>{V(e)},className:"hover:bg-white/20 rounded-full p-0.5",children:(0,t.jsx)("svg",{className:"w-3 h-3",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M6 18L18 6M6 6l12 12"})})})]},e.customer_id))})]}),(0,t.jsxs)("div",{className:"relative z-40",style:{overflow:"visible"},children:[(0,t.jsx)("label",{className:"block text-xs font-medium text-text-secondary mb-1.5",children:"所屬項目"}),(0,t.jsxs)("div",{className:"relative project-category-dropdown",children:[(0,t.jsx)("div",{className:"w-full px-3 py-2.5 bg-bg-secondary border border-border-light rounded-xl text-sm cursor-pointer flex items-center min-h-[42px]",onClick:()=>O(!P),children:(0,t.jsx)("div",{className:"flex flex-wrap gap-1 flex-1",children:H.length>0?H.map(e=>{let a=f.find(t=>t.value===e);return(0,t.jsxs)("span",{className:"inline-flex items-center px-2 py-0.5 bg-primary/10 text-primary text-xs rounded-lg font-medium",children:[(0,t.jsx)("span",{className:"truncate max-w-[60px]",children:a?.label}),(0,t.jsx)("button",{type:"button",onClick:t=>{t.stopPropagation(),r(t=>{let r=Array.isArray(t.projectCategory)?t.projectCategory:t.projectCategory?[t.projectCategory]:[];return{...t,projectCategory:r.filter(t=>t!==e)}})},className:"ml-1 text-primary hover:text-red-500",children:"×"})]},e)}):(0,t.jsx)("span",{className:"text-text-tertiary text-sm",children:"可多選"})})}),(0,t.jsx)("svg",{className:"absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-text-tertiary pointer-events-none transition-transform duration-200",style:{transform:P?"translateY(-50%) rotate(180deg)":"translateY(-50%)"},fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M19 9l-7 7-7-7"})}),P&&(0,t.jsx)("div",{className:"absolute top-full left-0 right-0 mt-1 bg-white border border-border-light rounded-xl shadow-2xl z-[100] max-h-56 overflow-y-auto",children:f.map(e=>{let a=H.includes(e.value);return(0,t.jsxs)("div",{className:`px-3 py-2.5 cursor-pointer hover:bg-bg-secondary flex items-center justify-between text-sm transition-colors ${a?"bg-primary/5 text-primary font-medium":"text-text-primary"}`,onClick:()=>{r(t=>{let r=Array.isArray(t.projectCategory)?t.projectCategory:t.projectCategory?[t.projectCategory]:[],s=a?r.filter(t=>t!==e.value):[...r,e.value];return{...t,projectCategory:s}})},children:[(0,t.jsx)("span",{className:"truncate",children:e.label}),a&&(0,t.jsx)("svg",{className:"w-4 h-4 text-primary flex-shrink-0 ml-2",fill:"currentColor",viewBox:"0 0 20 20",children:(0,t.jsx)("path",{fillRule:"evenodd",d:"M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z",clipRule:"evenodd"})})]},e.value)})})]})]}),(0,t.jsxs)("div",{className:"relative z-30",children:[(0,t.jsx)("label",{className:"block text-xs font-medium text-text-secondary mb-1.5",children:"服務類型"}),(0,t.jsxs)("div",{className:"relative",children:[(0,t.jsxs)("select",{value:e.serviceType||"",onChange:e=>r(t=>({...t,serviceType:e.target.value})),className:"w-full px-3 py-2.5 bg-bg-secondary border border-border-light rounded-xl text-sm appearance-none cursor-pointer focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary",children:[(0,t.jsx)("option",{value:"",children:"全部"}),g.map(e=>(0,t.jsx)("option",{value:e.value,children:e.label},e.value))]}),(0,t.jsx)("svg",{className:"absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-text-tertiary pointer-events-none",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M19 9l-7 7-7-7"})})]})]}),(0,t.jsxs)("div",{className:"relative z-20",children:[(0,t.jsx)("label",{className:"block text-xs font-medium text-text-secondary mb-1.5",children:"護理人員"}),(0,t.jsx)(p,{careStaffList:y,value:e.careStaffName||"",onChange:e=>r(t=>({...t,careStaffName:e})),loading:j,placeholder:"全部"})]}),(0,t.jsxs)("div",{className:"relative z-10",children:[(0,t.jsx)("label",{className:"block text-xs font-medium text-text-secondary mb-1.5",children:"介紹人"}),(0,t.jsxs)("div",{className:"relative",children:[(0,t.jsxs)("select",{value:e.introducer||"",onChange:e=>r(t=>({...t,introducer:e.target.value||void 0})),className:"w-full px-3 py-2.5 bg-bg-secondary border border-border-light rounded-xl text-sm appearance-none cursor-pointer focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary",children:[(0,t.jsx)("option",{value:"",children:"全部"}),h.map(e=>(0,t.jsx)("option",{value:e.value,children:e.label},e.value))]}),(0,t.jsx)("svg",{className:"absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-text-tertiary pointer-events-none",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M19 9l-7 7-7-7"})})]})]})]})]})]}),(0,t.jsx)("div",{className:"card-apple border border-border-light fade-in-apple relative z-10",children:(0,t.jsxs)("div",{className:"p-4 sm:p-6",children:[(0,t.jsxs)("div",{className:"flex flex-col lg:flex-row lg:justify-between lg:items-center mb-6 gap-4",children:[(0,t.jsxs)("div",{className:"flex items-center gap-4",children:[(0,t.jsx)("h3",{className:"text-lg font-semibold text-text-primary",children:"服務記錄"}),(0,t.jsx)("span",{className:"text-sm text-text-tertiary",children:(()=>{let[t,r]=e.dateRange.start.split("-").map(Number);return`${t}年${r}月`})()})]}),(0,t.jsxs)("div",{className:"flex flex-wrap items-center gap-3",children:[(0,t.jsx)("button",{onClick:i,disabled:c,className:"inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-text-primary bg-white border border-border-light rounded-xl hover:bg-bg-secondary transition-colors disabled:opacity-50",title:"導出 PDF 日曆報表",children:c?(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("div",{className:"animate-spin rounded-full h-4 w-4 border-2 border-primary border-t-transparent"}),(0,t.jsx)("span",{children:"產生中..."})]}):(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"})}),(0,t.jsx)("span",{children:"導出日曆 PDF"})]})}),(0,t.jsx)("button",{onMouseDown:e=>{e.preventDefault(),e.stopPropagation(),o()},disabled:l,className:"btn-apple-primary text-sm disabled:opacity-50",children:l?(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("div",{className:"animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2"}),(0,t.jsx)("span",{children:"導出中..."})]}):(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("svg",{className:"w-4 h-4 mr-2",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"})}),(0,t.jsx)("span",{children:"導出報表"})]})})]})]}),(0,t.jsx)(U,{filters:e,onEdit:m,onDelete:x,refreshTrigger:u,recordUpdateTimes:v}),(0,t.jsx)("div",{className:"mt-8",children:(0,t.jsx)("div",{className:"card-apple border border-border-light fade-in-apple",children:(0,t.jsx)("div",{className:"p-6",children:(0,t.jsx)(J,{filters:e,refreshTrigger:u})})})})]})})]})}function Z({isOpen:e,onClose:r,selectedDate:a,selectedDates:l=[],onSubmit:d,onDelete:c,isMultiDay:m=!1,existingRecord:x=null,preselectedCustomer:p=null}){let[u,h]=(0,n.useState)(()=>x?{service_date:x.service_date,customer_id:x.customer_id,customer_name:x.customer_name,phone:x.phone,service_address:x.service_address,start_time:x.start_time,end_time:x.end_time,service_hours:x.service_hours,staff_id:x.staff_id,care_staff_name:x.care_staff_name,service_fee:x.service_fee,staff_salary:x.staff_salary,hourly_rate:x.hourly_rate||0,hourly_salary:x.hourly_salary||0,service_type:x.service_type,project_category:x.project_category,project_manager:x.project_manager}:p?{service_date:a||A(new Date),customer_id:p.customer_id,customer_name:p.customer_name,phone:p.phone,service_address:p.service_address,start_time:"09:00",end_time:"17:00",service_hours:8,staff_id:"",care_staff_name:"",service_fee:0,staff_salary:0,hourly_rate:0,hourly_salary:0,service_type:"",project_category:p.project_category||"",project_manager:""}:{service_date:a||A(new Date),customer_id:"",customer_name:"",phone:"",service_address:"",start_time:"09:00",end_time:"17:00",service_hours:8,staff_id:"",care_staff_name:"",service_fee:0,staff_salary:0,hourly_rate:0,hourly_salary:0,service_type:"",project_category:"",project_manager:""}),[v,y]=(0,n.useState)(!1),[_,j]=(0,n.useState)({}),[N,w]=(0,n.useState)(x?.customer_name||p?.customer_name||""),[k,$]=(0,n.useState)([]),[S,C]=(0,n.useState)(!1),[D,M]=(0,n.useState)(x?x.care_staff_name:""),[F,z]=(0,n.useState)([]),[L,R]=(0,n.useState)(!1),[T,E]=(0,n.useState)([]),[I,P]=(0,n.useState)(!1),O=(0,n.useCallback)(e=>s.supabase.from("billing_salary_data").select("service_date, customer_name, staff_salary, hourly_salary").eq("staff_id",e).order("service_date",{ascending:!1}).order("id").limit(5).then(({data:e,error:t})=>{t?(console.error("查詢護理人員薪資歷史失敗:",t),E([])):E(e||[]),P(!1)}).catch(e=>{console.error("查詢護理人員薪資歷史失敗:",e),E([]),P(!1)}),[]);(0,n.useEffect)(()=>{x?.staff_id&&O(x.staff_id)},[x?.staff_id,O]);let[H,B]=(0,n.useState)([]),[Y,U]=(0,n.useState)(!1),[W,V]=(0,n.useState)(!1),[q,K]=(0,n.useState)(()=>{let e=a||(l.length>0?l[0]:null);if(e){let[t,r]=e.split("-");return`${t}-${r}`}let t=new Date;return`${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,"0")}`}),[J,G]=(0,n.useState)(""),[Q,X]=(0,n.useState)(""),[ee,et]=(0,n.useState)(!1),[er,ea]=(0,n.useState)([]),[es,el]=(0,n.useState)(!1),en=(0,n.useCallback)(()=>{let[e,t]=q.split("-").map(Number),{start:r,end:a}=(0,o.f)(e,t),{start:l,end:n}=(0,o.f)(e,t-1);return(0,i.f)((e,t)=>s.supabase.from("customer_personal_data").select("customer_id, customer_name, phone, service_address, customer_type").order("id").range(e,t)).then(async e=>{let t=await (0,i.f)((e,t)=>s.supabase.from("billing_salary_data").select("customer_id, customer_name, project_category").gte("service_date",l).lte("service_date",n).order("id").range(e,t)),o=await (0,i.f)((e,t)=>s.supabase.from("billing_salary_data").select("customer_id, customer_name, project_category").gte("service_date",r).lte("service_date",a).order("id").range(e,t)),d=new Set((t||[]).map(e=>e.customer_id||e.customer_name)),c=new Set((o||[]).map(e=>e.customer_id||e.customer_name)),m=new Map;[...t||[],...o||[]].forEach(e=>{(e.customer_id||e.customer_name)&&e.project_category&&m.set(e.customer_id||e.customer_name||"",e.project_category)});let x=(e||[]).filter(e=>"家訪客戶"!==e.customer_type).map(e=>({customer_id:e.customer_id,customer_name:e.customer_name,phone:e.phone||"",service_address:e.service_address||"",customer_type:e.customer_type||"",project_category:m.get(e.customer_id)||m.get(e.customer_name)||"",hasLastMonthService:d.has(e.customer_id)||d.has(e.customer_name),hasCurrentMonthSchedule:c.has(e.customer_id)||c.has(e.customer_name)}));J&&(x=x.filter(e=>e.customer_type===J)),Q&&(x=x.filter(e=>e.project_category===Q)),ee||(x=x.filter(e=>e.hasLastMonthService)),x.sort((e,t)=>e.hasLastMonthService&&!t.hasLastMonthService?-1:!e.hasLastMonthService&&t.hasLastMonthService?1:e.customer_name.localeCompare(t.customer_name,"zh-Hant")),ea(x)}).catch(e=>{console.error("載入客戶列表失敗:",e),alert("載入排程客戶失敗，請重試"),ea([])})},[q,J,Q,ee]);(0,n.useEffect)(()=>{W&&en().finally(()=>el(!1))},[W,en]);let[eo,ei]=(0,n.useState)(!1),[ed,ec]=(0,n.useState)("0"),[em,ex]=(0,n.useState)(null),[ep,eu]=(0,n.useState)(null),[eh,eg]=(0,n.useState)(!1),ef=e=>{eh?(ec(e),eg(!1)):ec("0"===ed?e:ed+e)},eb=e=>{let t=parseFloat(ed);if(null===em)ex(t);else if(ep){let e=em||0,r=e;switch(ep){case"+":r=e+t;break;case"-":r=e-t;break;case"×":r=e*t;break;case"÷":r=0!==t?e/t:0}ec(String(Math.round(1e8*r)/1e8)),ex(r)}eg(!0),eu(e)},[ev,ey]=(0,n.useState)(null),[e_,ej]=(0,n.useState)(null);(0,n.useEffect)(()=>(console.log("ScheduleFormModal組件已掛載"),()=>{console.log("ScheduleFormModal組件將卸載"),ev&&clearTimeout(ev),e_&&clearTimeout(e_)}),[ev,e_]),(0,n.useEffect)(()=>{let e=e=>{let t=e.target;t.closest(".customer-search-container")||C(!1),t.closest(".staff-search-container")||R(!1)};return document.addEventListener("mousedown",e),()=>document.removeEventListener("mousedown",e)},[]),(0,n.useEffect)(()=>{let e=e=>{let t=e.target;t.closest(".customer-search-container")||C(!1),t.closest(".staff-search-container")||R(!1)};return document.addEventListener("mousedown",e),()=>document.removeEventListener("mousedown",e)},[]);let eN=m||l.length>1,ew=async e=>{e.preventDefault(),y(!0);try{let e,t=(e={},u.customer_name.trim()||(e.customer_name="客戶姓名不能為空"),u.phone.trim()||(e.phone="聯絡電話不能為空"),u.service_address.trim()||(e.service_address="服務地址不能為空"),u.care_staff_name.trim()||(e.care_staff_name="護理人員不能為空"),u.staff_id?.trim()||(e.staff_id="請透過搜尋選擇護理人員"),(null==u.service_fee||u.service_fee<0)&&(e.service_fee="服務費用不能為空或負數"),(null==u.staff_salary||u.staff_salary<0)&&(e.staff_salary="員工薪資不能為空或負數"),(null==u.service_hours||u.service_hours<0)&&(e.service_hours="服務時數不能為空或負數"),u.service_type||(e.service_type="請選擇服務類型"),u.project_category||(e.project_category="請選擇項目分類"),u.project_manager||(e.project_manager="請選擇項目負責人"),e);if(Object.keys(t).length>0)return void j(t);j({});let a={service_date:u.service_date,customer_id:u.customer_id,customer_name:u.customer_name,phone:u.phone,service_address:u.service_address,start_time:u.start_time,end_time:u.end_time,service_hours:u.service_hours,staff_id:u.staff_id,care_staff_name:u.care_staff_name,service_fee:u.service_fee,staff_salary:u.staff_salary,service_type:u.service_type,project_category:u.project_category,project_manager:u.project_manager};await d(a),r()}catch(t){console.error("提交表單失敗:",t);let e=t instanceof Error?t.message:"未知錯誤";alert(`提交表單失敗: ${e}`)}finally{y(!1)}},ek=(e,t)=>{h(r=>{let a={...r,[e]:t};if("care_staff_name"===e&&(a.staff_id=""),"service_date"===e&&t&&"string"==typeof t&&t.match(/^\d{4}-\d{2}-\d{2}$/)&&(a.service_date=t),("start_time"===e||"end_time"===e)&&a.start_time&&a.end_time){let e=Math.round(2*((e,t)=>{let[r,a]=e.split(":").map(Number),[s,l]=t.split(":").map(Number),n=60*r+a,o=60*s+l;return o<n&&(o+=1440),Math.max(0,(o-n)/60)})(a.start_time,a.end_time))/2;a.service_hours=e}return("service_fee"===e||"staff_salary"===e||"service_hours"===e)&&a.service_hours>0&&(a.hourly_rate=Math.round((a.service_fee||0)/a.service_hours*100)/100,a.hourly_salary=Math.round((a.staff_salary||0)/a.service_hours*100)/100),a}),"customer_name"===e?w(t):"care_staff_name"===e&&M(t)},e$=async e=>{if(console.log("表單客戶搜尋開始:",e),w(e),e.trim().length<1){$([]),C(!1);return}try{console.log("使用 Supabase 直接進行表單客戶搜尋");let{data:t,error:r}=await s.supabase.from("customer_personal_data").select("customer_id, customer_name, phone, service_address").or(`customer_name.ilike.%${e.trim()}%,customer_id.ilike.%${e.trim()}%,phone.ilike.%${e.trim()}%,service_address.ilike.%${e.trim()}%`).limit(10);if(r){console.error("Supabase 表單客戶搜尋錯誤:",r),$([]),C(!1);return}let a=(t||[]).map(e=>({customer_id:e.customer_id||"",customer_name:e.customer_name||"",phone:e.phone||"",service_address:e.service_address||"",display_text:e.customer_name||"",type:"customer"}));console.log("表單客戶搜尋結果:",a),$(a),C(!0)}catch(e){console.error("客戶搜尋失敗:",e),$([]),C(!1)}},eS=async e=>{if(ek("customer_name",e.customer_name||e.display_text),ek("customer_id",e.customer_id||""),ek("phone",e.phone||""),ek("service_address",e.service_address||""),w(e.customer_name||e.display_text),C(!1),e.customer_id||e.customer_name){U(!0);try{let{data:t,error:r}=await s.supabase.from("billing_salary_data").select("staff_id, care_staff_name, service_date").or(`customer_id.eq.${e.customer_id},customer_name.eq.${e.customer_name}`).order("service_date",{ascending:!1}).limit(20);if(r)console.error("查詢客戶歷史護理人員失敗:",r),B([]);else{let e=new Map;for(let r of t||[])if(r.staff_id&&r.care_staff_name){let t=e.get(r.staff_id);t?t.service_count++:e.set(r.staff_id,{staff_id:r.staff_id,care_staff_name:r.care_staff_name,service_date:r.service_date,service_count:1})}B(Array.from(e.values()).slice(0,5))}}catch(e){console.error("查詢客戶歷史護理人員錯誤:",e),B([])}finally{U(!1)}}else B([])},eC=async e=>{if(console.log("護理人員搜尋開始:",e),M(e),e.trim().length<1){z([]),R(!1);return}try{console.log("使用 Supabase 直接進行護理人員搜尋");let{data:t,error:r}=await s.supabase.from("care_staff_profiles").select("name_chinese, name_english, staff_id, phone").or(`name_chinese.ilike.%${e.trim()}%,name_english.ilike.%${e.trim()}%,staff_id.ilike.%${e.trim()}%,phone.ilike.%${e.trim()}%`).limit(10);if(r){console.error("Supabase 護理人員搜尋錯誤:",r),z([]),R(!1);return}let a=(t||[]).map(e=>({name_chinese:e.name_chinese||"",name_english:e.name_english||"",staff_id:e.staff_id||"",phone:e.phone||""}));console.log("護理人員搜尋結果:",a),z(a),R(!0)}catch(e){console.error("護理人員搜尋失敗:",e),z([]),R(!1)}},eD=async e=>{ek("care_staff_name",e.name_chinese),ek("staff_id",e.staff_id||""),M(e.name_chinese),R(!1),await O(e.staff_id||"")};return e?(0,t.jsx)("div",{className:"fixed inset-0 bg-black/50 z-[9999]",onClick:r,children:(0,t.jsxs)("div",{className:"fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-bg-primary rounded-xl w-[calc(100%-2rem)] max-w-4xl max-h-[90vh] overflow-hidden shadow-2xl",onClick:e=>e.stopPropagation(),children:[(0,t.jsxs)("div",{className:"p-6 border-b border-border-light",children:[(0,t.jsx)("h3",{className:"text-lg font-medium text-text-primary",children:x?`編輯排班 - ${x.service_date}`:eN?`批量新增排班 (${l.length} 天)`:`新增排班 - ${a}`}),eN&&(0,t.jsxs)("div",{className:"mt-2 text-sm text-text-secondary",children:["選定日期：",l.sort().join(", ")]})]}),(0,t.jsx)("div",{className:"p-6 overflow-y-auto max-h-[calc(90vh-200px)]",children:(0,t.jsxs)("form",{onSubmit:ew,className:"space-y-6",children:[x&&(0,t.jsx)("div",{className:"card-apple border border-border-light",children:(0,t.jsxs)("div",{className:"p-6",children:[(0,t.jsx)("h4",{className:"text-apple-heading text-text-primary mb-4",children:"服務日期"}),(0,t.jsxs)("div",{children:[(0,t.jsxs)("label",{className:"block text-apple-caption font-medium text-text-primary mb-2",children:["日期 ",(0,t.jsx)("span",{className:"text-danger",children:"*"})]}),(0,t.jsx)("input",{type:"date",value:u.service_date,onChange:e=>ek("service_date",e.target.value),className:`form-input-apple w-full ${_.service_date?"border-danger":""}`,required:!0}),_.service_date&&(0,t.jsx)("p",{className:"text-apple-caption text-danger mt-1",children:_.service_date})]})]})}),(0,t.jsx)("div",{className:"card-apple border border-border-light",children:(0,t.jsxs)("div",{className:"p-6",children:[(0,t.jsx)("h4",{className:"text-apple-heading text-text-primary mb-4",children:"客戶基本資料"}),(0,t.jsxs)("div",{className:"space-y-4",children:[(0,t.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:[(0,t.jsxs)("div",{children:[(0,t.jsxs)("label",{className:"block text-apple-caption font-medium text-text-primary mb-2",children:["服務類型 ",(0,t.jsx)("span",{className:"text-danger",children:"*"})]}),(0,t.jsxs)("select",{value:u.service_type,onChange:e=>ek("service_type",e.target.value),className:`form-input-apple w-full ${_.service_type?"border-danger":""}`,required:!0,children:[(0,t.jsx)("option",{value:"",children:"請選擇服務類型"}),g.map(e=>(0,t.jsx)("option",{value:e.value,children:e.label},e.value))]}),_.service_type&&(0,t.jsx)("p",{className:"text-apple-caption text-danger mt-1",children:_.service_type})]}),(0,t.jsxs)("div",{children:[(0,t.jsxs)("label",{className:"block text-apple-caption font-medium text-text-primary mb-2",children:["項目分類 ",(0,t.jsx)("span",{className:"text-danger",children:"*"})]}),(0,t.jsxs)("select",{value:u.project_category,onChange:e=>ek("project_category",e.target.value),className:`form-input-apple w-full ${_.project_category?"border-danger":""}`,required:!0,children:[(0,t.jsx)("option",{value:"",children:"請選擇項目分類"}),f.map(e=>(0,t.jsx)("option",{value:e.value,children:e.label},e.value))]}),_.project_category&&(0,t.jsx)("p",{className:"text-apple-caption text-danger mt-1",children:_.project_category})]})]}),(0,t.jsxs)("div",{children:[(0,t.jsxs)("label",{className:"block text-apple-caption font-medium text-text-primary mb-2",children:["項目負責人 ",(0,t.jsx)("span",{className:"text-danger",children:"*"})]}),(0,t.jsxs)("select",{value:u.project_manager,onChange:e=>ek("project_manager",e.target.value),className:`form-input-apple w-full ${_.project_manager?"border-danger":""}`,required:!0,children:[(0,t.jsx)("option",{value:"",children:"請選擇項目負責人"}),b.map(e=>(0,t.jsx)("option",{value:e.value,children:e.label},e.value))]}),_.project_manager&&(0,t.jsx)("p",{className:"text-apple-caption text-danger mt-1",children:_.project_manager})]}),(0,t.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:[(0,t.jsxs)("div",{className:"relative customer-search-container",children:[(0,t.jsxs)("label",{className:"block text-apple-caption font-medium text-text-primary mb-2",children:["客戶姓名 ",(0,t.jsx)("span",{className:"text-danger",children:"*"})]}),(0,t.jsx)("input",{type:"text",value:N,onChange:e=>{let t=e.target.value;console.log("客戶搜尋輸入變化:",t),w(t),ek("customer_name",t),ev&&clearTimeout(ev),t.length>=1?(console.log("設置客戶搜尋定時器"),ey(setTimeout(()=>{console.log("執行客戶搜尋"),e$(t)},300))):C(!1)},onFocus:()=>{console.log("客戶輸入框獲得焦點"),N.length>=1&&k.length>0&&C(!0)},className:`form-input-apple w-full ${_.customer_name?"border-danger":""}`,placeholder:"請輸入客戶姓名或編號（≥1字元）",autoComplete:"off",required:!0}),S&&k.length>0&&(0,t.jsx)("div",{className:"absolute z-10 w-full mt-1 bg-bg-primary border border-border-light rounded-xl shadow-lg max-h-48 overflow-y-auto",children:k.map((e,r)=>(0,t.jsxs)("div",{onClick:()=>eS(e),className:"px-4 py-2 hover:bg-bg-secondary cursor-pointer border-b border-border-light last:border-b-0",children:[(0,t.jsxs)("div",{className:"font-medium text-text-primary",children:[e.customer_name||e.display_text,e.customer_id&&(0,t.jsxs)("span",{className:"text-text-secondary ml-1",children:["（",e.customer_id,"）"]})]}),e.phone&&(0,t.jsx)("div",{className:"text-sm text-text-secondary",children:e.phone}),e.service_address&&(0,t.jsx)("div",{className:"text-sm text-text-secondary truncate",children:e.service_address})]},e.customer_id||r))}),_.customer_name&&(0,t.jsx)("p",{className:"text-apple-caption text-danger mt-1",children:_.customer_name})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"block text-apple-caption font-medium text-text-primary mb-2",children:"客戶編號"}),(0,t.jsx)("input",{type:"text",value:u.customer_id||"",readOnly:!0,className:"form-input-apple w-full bg-bg-secondary text-text-secondary cursor-not-allowed",placeholder:"選擇客戶後自動填入"})]})]}),(0,t.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"block text-apple-caption font-medium text-text-primary mb-2",children:"聯絡電話"}),(0,t.jsx)("input",{type:"tel",value:u.phone,readOnly:!0,className:"form-input-apple w-full bg-bg-secondary text-text-secondary cursor-not-allowed",placeholder:"選擇客戶後自動填入"})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"block text-apple-caption font-medium text-text-primary mb-2",children:"服務地址"}),(0,t.jsx)("input",{type:"text",value:u.service_address,onChange:e=>ek("service_address",e.target.value),className:`form-input-apple w-full ${_.service_address?"border-danger":""}`,placeholder:"請輸入服務地址"}),_.service_address&&(0,t.jsx)("p",{className:"text-apple-caption text-danger mt-1",children:_.service_address})]})]})]})]})}),(0,t.jsx)("div",{className:"card-apple border border-border-light",children:(0,t.jsxs)("div",{className:"p-6",children:[(0,t.jsx)("h4",{className:"text-apple-heading text-text-primary mb-4",children:"服務詳情"}),(0,t.jsxs)("div",{className:"space-y-4",children:[(0,t.jsxs)("div",{className:"relative staff-search-container",children:[(0,t.jsx)("label",{className:"block text-apple-caption font-medium text-text-primary mb-2",children:"護理人員"}),(0,t.jsx)("input",{type:"text",value:D,onChange:e=>{let t=e.target.value;console.log("護理人員搜尋輸入變化:",t),M(t),ek("care_staff_name",t),e_&&clearTimeout(e_),t.length>=1?(console.log("設置護理人員搜尋定時器"),ej(setTimeout(()=>{console.log("執行護理人員搜尋"),eC(t)},300))):R(!1)},onFocus:()=>{console.log("護理人員輸入框獲得焦點"),D.length>=1&&F.length>0&&R(!0)},className:`form-input-apple w-full ${_.care_staff_name?"border-danger":""}`,placeholder:"輸入護理人員中文姓名或編號（≥1字元）",autoComplete:"off"}),L&&F&&F.length>0&&(0,t.jsx)("div",{className:"absolute z-10 w-full mt-1 bg-bg-primary border border-border-light rounded-xl shadow-lg max-h-48 overflow-y-auto",children:F.map((e,r)=>(0,t.jsx)("div",{onClick:()=>eD(e),className:"px-4 py-2 hover:bg-bg-secondary cursor-pointer border-b border-border-light last:border-b-0",children:(0,t.jsxs)("div",{className:"font-medium text-text-primary",children:[e.name_chinese,e.staff_id&&(0,t.jsxs)("span",{className:"text-text-secondary ml-1",children:["（",e.staff_id,"）"]})]})},e.staff_id||r))}),_.care_staff_name&&(0,t.jsx)("p",{className:"text-apple-caption text-danger mt-1",children:_.care_staff_name}),u.customer_name&&!u.staff_id&&(0,t.jsxs)("div",{className:"mt-3 bg-green-50 border border-green-200 rounded-xl p-3",children:[(0,t.jsxs)("div",{className:"flex items-center gap-2 mb-2",children:[(0,t.jsx)("span",{className:"text-lg",children:"👥"}),(0,t.jsxs)("span",{className:"text-sm font-medium text-green-800",children:[u.customer_name," 的最近護理人員"]})]}),Y?(0,t.jsx)("div",{className:"text-sm text-green-600 animate-pulse",children:"載入中..."}):H.length>0?(0,t.jsx)("div",{className:"flex flex-wrap gap-2",children:H.map((e,r)=>(0,t.jsxs)("button",{type:"button",onClick:()=>{ek("care_staff_name",e.care_staff_name),ek("staff_id",e.staff_id),M(e.care_staff_name),O(e.staff_id)},className:"inline-flex items-center gap-1 px-3 py-1.5 bg-white border border-green-300 rounded-lg text-sm text-green-700 hover:bg-green-100 hover:border-green-400 transition-colors",children:[(0,t.jsx)("span",{className:"font-medium",children:e.care_staff_name}),(0,t.jsxs)("span",{className:"text-green-500 text-xs",children:["(",e.staff_id,")"]}),(0,t.jsxs)("span",{className:"text-green-400 text-xs ml-1",children:["×",e.service_count]})]},e.staff_id))}):(0,t.jsx)("div",{className:"text-sm text-green-600",children:"暫無歷史記錄"})]})]}),(0,t.jsxs)("div",{children:[(0,t.jsxs)("label",{className:"block text-apple-caption font-medium text-text-primary mb-2",children:["護理人員編號 ",(0,t.jsx)("span",{className:"text-text-secondary",children:"（自動帶入）"})]}),(0,t.jsx)("input",{type:"text",value:u.staff_id||"",readOnly:!0,className:`form-input-apple w-full bg-bg-secondary text-text-secondary cursor-not-allowed ${_.staff_id?"border-danger":""}`,placeholder:"選擇護理人員後自動填入"}),_.staff_id&&(0,t.jsx)("p",{className:"text-apple-caption text-danger mt-1",children:_.staff_id})]}),(0,t.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"block text-apple-caption font-medium text-text-primary mb-2",children:"開始時間"}),(0,t.jsx)("input",{type:"time",value:u.start_time,onChange:e=>ek("start_time",e.target.value),className:"form-input-apple w-full",step:"1800"})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"block text-apple-caption font-medium text-text-primary mb-2",children:"結束時間"}),(0,t.jsx)("input",{type:"time",value:u.end_time,onChange:e=>ek("end_time",e.target.value),className:`form-input-apple w-full ${_.end_time?"border-danger":""}`,step:"1800"}),_.end_time&&(0,t.jsx)("p",{className:"text-apple-caption text-danger mt-1",children:_.end_time})]})]}),(0,t.jsxs)("div",{children:[(0,t.jsxs)("label",{className:"block text-apple-caption font-medium text-text-primary mb-2",children:["服務時數 ",(0,t.jsx)("span",{className:"text-danger",children:"*"})]}),(0,t.jsx)("input",{type:"number",value:0===u.service_hours?"0":u.service_hours||"",onChange:e=>ek("service_hours",""===e.target.value?null:parseFloat(e.target.value)),onBlur:e=>{""===e.target.value&&ek("service_hours",0)},className:`form-input-apple w-full ${_.service_hours?"border-danger":""}`,placeholder:"請輸入服務時數",step:"0.5",min:"0"}),_.service_hours&&(0,t.jsx)("p",{className:"text-apple-caption text-danger mt-1",children:_.service_hours}),(0,t.jsx)("p",{className:"text-apple-caption text-text-secondary mt-1",children:"填入開始/結束時間後會自動計算，也可手動輸入"})]})]})]})}),(0,t.jsx)("div",{className:"card-apple border border-border-light",children:(0,t.jsxs)("div",{className:"p-6",children:[(0,t.jsxs)("div",{className:"flex items-center justify-between mb-4",children:[(0,t.jsx)("h4",{className:"text-apple-heading text-text-primary",children:"收費與工資"}),(0,t.jsx)("button",{type:"button",onClick:()=>ei(!eo),className:`p-2 rounded-lg transition-colors ${eo?"bg-primary text-white":"bg-bg-secondary text-text-secondary hover:bg-bg-tertiary"}`,title:"計算機",children:(0,t.jsx)("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"})})})]}),eo&&(0,t.jsxs)("div",{className:"mb-4 bg-gray-800 rounded-xl p-4 shadow-lg",children:[(0,t.jsxs)("div",{className:"bg-gray-900 rounded-lg p-3 mb-3",children:[(0,t.jsx)("div",{className:"text-right text-2xl font-mono text-white truncate",children:ed}),ep&&(0,t.jsxs)("div",{className:"text-right text-xs text-gray-400 mt-1",children:[em," ",ep]})]}),(0,t.jsxs)("div",{className:"grid grid-cols-4 gap-2",children:[(0,t.jsx)("button",{type:"button",onClick:()=>{ec("0"),ex(null),eu(null),eg(!1)},className:"col-span-2 py-3 bg-red-500 hover:bg-red-600 text-white rounded-lg font-medium transition-colors",children:"C"}),(0,t.jsx)("button",{type:"button",onClick:()=>eb("÷"),className:"py-3 bg-orange-500 hover:bg-orange-600 text-white rounded-lg font-medium transition-colors",children:"÷"}),(0,t.jsx)("button",{type:"button",onClick:()=>eb("×"),className:"py-3 bg-orange-500 hover:bg-orange-600 text-white rounded-lg font-medium transition-colors",children:"×"}),(0,t.jsx)("button",{type:"button",onClick:()=>ef("7"),className:"py-3 bg-gray-600 hover:bg-gray-500 text-white rounded-lg font-medium transition-colors",children:"7"}),(0,t.jsx)("button",{type:"button",onClick:()=>ef("8"),className:"py-3 bg-gray-600 hover:bg-gray-500 text-white rounded-lg font-medium transition-colors",children:"8"}),(0,t.jsx)("button",{type:"button",onClick:()=>ef("9"),className:"py-3 bg-gray-600 hover:bg-gray-500 text-white rounded-lg font-medium transition-colors",children:"9"}),(0,t.jsx)("button",{type:"button",onClick:()=>eb("-"),className:"py-3 bg-orange-500 hover:bg-orange-600 text-white rounded-lg font-medium transition-colors",children:"-"}),(0,t.jsx)("button",{type:"button",onClick:()=>ef("4"),className:"py-3 bg-gray-600 hover:bg-gray-500 text-white rounded-lg font-medium transition-colors",children:"4"}),(0,t.jsx)("button",{type:"button",onClick:()=>ef("5"),className:"py-3 bg-gray-600 hover:bg-gray-500 text-white rounded-lg font-medium transition-colors",children:"5"}),(0,t.jsx)("button",{type:"button",onClick:()=>ef("6"),className:"py-3 bg-gray-600 hover:bg-gray-500 text-white rounded-lg font-medium transition-colors",children:"6"}),(0,t.jsx)("button",{type:"button",onClick:()=>eb("+"),className:"py-3 bg-orange-500 hover:bg-orange-600 text-white rounded-lg font-medium transition-colors",children:"+"}),(0,t.jsx)("button",{type:"button",onClick:()=>ef("1"),className:"py-3 bg-gray-600 hover:bg-gray-500 text-white rounded-lg font-medium transition-colors",children:"1"}),(0,t.jsx)("button",{type:"button",onClick:()=>ef("2"),className:"py-3 bg-gray-600 hover:bg-gray-500 text-white rounded-lg font-medium transition-colors",children:"2"}),(0,t.jsx)("button",{type:"button",onClick:()=>ef("3"),className:"py-3 bg-gray-600 hover:bg-gray-500 text-white rounded-lg font-medium transition-colors",children:"3"}),(0,t.jsx)("button",{type:"button",onClick:()=>{if(!ep||null===em)return;let e=parseFloat(ed),t=em;switch(ep){case"+":t=em+e;break;case"-":t=em-e;break;case"×":t=em*e;break;case"÷":t=0!==e?em/e:0}ec(String(Math.round(1e8*t)/1e8)),ex(null),eu(null),eg(!0)},className:"row-span-2 py-3 bg-green-500 hover:bg-green-600 text-white rounded-lg font-medium transition-colors",children:"="}),(0,t.jsx)("button",{type:"button",onClick:()=>ef("0"),className:"col-span-2 py-3 bg-gray-600 hover:bg-gray-500 text-white rounded-lg font-medium transition-colors",children:"0"}),(0,t.jsx)("button",{type:"button",onClick:()=>{eh?(ec("0."),eg(!1)):ed.includes(".")||ec(ed+".")},className:"py-3 bg-gray-600 hover:bg-gray-500 text-white rounded-lg font-medium transition-colors",children:"."})]})]}),(0,t.jsxs)("div",{className:"space-y-4",children:[u.staff_id&&(0,t.jsxs)("div",{className:"bg-blue-50 border border-blue-200 rounded-xl p-3",children:[(0,t.jsxs)("div",{className:"flex items-center gap-2 mb-2",children:[(0,t.jsx)("span",{className:"text-lg",children:"📋"}),(0,t.jsxs)("span",{className:"text-sm font-medium text-blue-800",children:["最近 5 次記錄 (",u.staff_id," ",u.care_staff_name,")"]})]}),I?(0,t.jsx)("div",{className:"text-sm text-blue-600 animate-pulse",children:"載入中..."}):T.length>0?(0,t.jsx)("div",{className:"space-y-1",children:T.map((e,r)=>(0,t.jsxs)("div",{className:"text-sm text-blue-700 font-mono bg-white/50 px-2 py-1 rounded",children:[(0,t.jsx)("span",{className:"inline-block w-4 text-blue-500",children:"①②③④⑤"[r]})," ",e.service_date," | ",e.customer_name||"未知客戶"," | 薪資: $",e.staff_salary?.toLocaleString()||0," | 時薪: $",e.hourly_salary?.toLocaleString()||0,"/小時"]},r))}):(0,t.jsx)("div",{className:"text-sm text-blue-600",children:"暫無歷史記錄"})]}),(0,t.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:[(0,t.jsxs)("div",{children:[(0,t.jsxs)("label",{className:"block text-apple-caption font-medium text-text-primary mb-2",children:["服務費用 ",(0,t.jsx)("span",{className:"text-danger",children:"*"})]}),(0,t.jsx)("input",{type:"number",value:0===u.service_fee?"0":u.service_fee||"",onChange:e=>ek("service_fee",""===e.target.value?null:parseFloat(e.target.value)),onBlur:e=>{""===e.target.value&&ek("service_fee",0)},className:`form-input-apple w-full ${_.service_fee?"border-danger":""}`,placeholder:"請輸入服務費用",min:"0",step:"0.01"}),_.service_fee&&(0,t.jsx)("p",{className:"text-apple-caption text-danger mt-1",children:_.service_fee})]}),(0,t.jsxs)("div",{children:[(0,t.jsxs)("label",{className:"block text-apple-caption font-medium text-text-primary mb-2",children:["員工薪資 ",(0,t.jsx)("span",{className:"text-danger",children:"*"})]}),(0,t.jsx)("input",{type:"number",value:0===u.staff_salary?"0":u.staff_salary||"",onChange:e=>ek("staff_salary",""===e.target.value?null:parseFloat(e.target.value)),onBlur:e=>{""===e.target.value&&ek("staff_salary",0)},className:`form-input-apple w-full ${_.staff_salary?"border-danger":""}`,placeholder:"請輸入員工薪資",min:"0",step:"0.01"}),_.staff_salary&&(0,t.jsx)("p",{className:"text-apple-caption text-danger mt-1",children:_.staff_salary}),(0,t.jsx)("p",{className:"text-apple-caption text-text-secondary mt-1",children:"員工薪資不能超過服務費用"})]})]}),(0,t.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"block text-apple-caption font-medium text-text-primary mb-2",children:"每小時收費"}),(0,t.jsx)("input",{type:"number",value:u.hourly_rate.toFixed(2),readOnly:!0,className:"form-input-apple w-full bg-bg-secondary text-text-secondary cursor-not-allowed",placeholder:"自動計算"}),(0,t.jsx)("p",{className:"text-apple-caption text-text-secondary mt-1",children:"自動計算：服務費用 ÷ 服務時數"})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"block text-apple-caption font-medium text-text-primary mb-2",children:"每小時薪資"}),(0,t.jsx)("input",{type:"number",value:u.hourly_salary.toFixed(2),readOnly:!0,className:"form-input-apple w-full bg-bg-secondary text-text-secondary cursor-not-allowed",placeholder:"自動計算"}),(0,t.jsx)("p",{className:"text-apple-caption text-text-secondary mt-1",children:"自動計算：員工薪資 ÷ 服務時數"})]})]}),(0,t.jsxs)("div",{className:"bg-green-50 border border-green-200 rounded-xl p-4",children:[(0,t.jsxs)("div",{className:"flex justify-between items-center",children:[(0,t.jsx)("label",{className:"text-apple-body font-medium text-green-800",children:"本次利潤"}),(0,t.jsxs)("div",{className:"text-apple-heading font-bold text-green-700",children:["$",((u.service_fee||0)-(u.staff_salary||0)).toFixed(2)]})]}),(0,t.jsx)("p",{className:"text-apple-caption text-green-600 mt-1",children:"計算公式：服務費用 - 員工薪資"})]}),(0,t.jsxs)("div",{className:"border-t border-border-light pt-4",children:[(0,t.jsx)("h5",{className:"text-apple-body font-medium text-text-primary mb-2",children:"費用摘要"}),(0,t.jsxs)("div",{className:"grid grid-cols-2 md:grid-cols-4 gap-4 text-sm",children:[(0,t.jsxs)("div",{className:"text-center",children:[(0,t.jsx)("div",{className:"text-text-secondary",children:"服務費用"}),(0,t.jsxs)("div",{className:"font-medium text-text-primary",children:["$",(u.service_fee||0).toFixed(2)]})]}),(0,t.jsxs)("div",{className:"text-center",children:[(0,t.jsx)("div",{className:"text-text-secondary",children:"員工薪資"}),(0,t.jsxs)("div",{className:"font-medium text-text-primary",children:["$",(u.staff_salary||0).toFixed(2)]})]}),(0,t.jsxs)("div",{className:"text-center",children:[(0,t.jsx)("div",{className:"text-text-secondary",children:"利潤率"}),(0,t.jsx)("div",{className:"font-medium text-text-primary",children:(u.service_fee||0)>0?`${(((u.service_fee||0)-(u.staff_salary||0))/(u.service_fee||1)*100).toFixed(1)}%`:"0%"})]}),(0,t.jsxs)("div",{className:"text-center",children:[(0,t.jsx)("div",{className:"text-text-secondary",children:"服務時數"}),(0,t.jsxs)("div",{className:"font-medium text-text-primary",children:[u.service_hours,"小時"]})]})]})]})]})]})})]})}),(0,t.jsx)("div",{className:"p-6 border-t border-border-light bg-bg-secondary",children:(0,t.jsxs)("div",{className:"flex justify-between",children:[(0,t.jsx)("div",{children:x&&c&&(0,t.jsx)("button",{type:"button",onClick:async()=>{if(confirm("確定要刪除這筆記錄嗎？此操作無法復原。"))try{await c(x.id),r()}catch(e){console.error("刪除失敗:",e),alert("刪除失敗，請稍後再試")}},disabled:v,className:"px-4 py-2 bg-red-600 text-white rounded-xl hover:bg-red-700 transition-all duration-300 disabled:opacity-50",children:v?"刪除中...":"刪除"})}),(0,t.jsxs)("div",{className:"flex gap-3",children:[(0,t.jsx)("button",{type:"button",onClick:r,className:"px-4 py-2 text-text-secondary border border-border-light rounded-xl hover:bg-bg-primary transition-all duration-300",disabled:v,children:"取消"}),(0,t.jsx)("button",{type:"submit",onClick:ew,disabled:v,className:"px-4 py-2 bg-primary text-white rounded-xl hover:bg-opacity-90 transition-all duration-300 disabled:opacity-50",children:v?"處理中...":x?"儲存修改":eN?"批量新增":"新增排班"})]})]})})]})}):null}function X({isOpen:e,schedule:r,onClose:a,onUpdate:s,onDelete:l,onEdit:n}){return e&&r?(0,t.jsx)("div",{className:"fixed inset-0 bg-black/50 z-[9999]",onClick:a,children:(0,t.jsxs)("div",{className:"fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-bg-primary rounded-xl w-[calc(100%-2rem)] max-w-md max-h-[90vh] overflow-hidden shadow-2xl",onClick:e=>e.stopPropagation(),children:[(0,t.jsxs)("div",{className:"p-6 border-b border-border-light",children:[(0,t.jsx)("h3",{className:"text-lg font-medium text-text-primary",children:"排程選項"}),(0,t.jsx)("p",{className:"text-sm text-text-secondary mt-1",children:"選擇要對此排程執行的操作"})]}),(0,t.jsxs)("div",{className:"p-6",children:[(0,t.jsxs)("div",{className:"bg-yellow-50 border border-yellow-200 rounded-xl p-4 mb-6",children:[(0,t.jsxs)("div",{className:"text-sm text-text-secondary mb-2",children:[(0,t.jsx)("strong",{children:"日期："})," ",r.service_date]}),(0,t.jsxs)("div",{className:"text-sm text-text-secondary mb-2",children:[(0,t.jsx)("strong",{children:"客戶："})," ",r.customer_name]}),(0,t.jsxs)("div",{className:"text-sm text-text-secondary mb-2",children:[(0,t.jsx)("strong",{children:"護理人員："})," ",r.care_staff_name]}),(0,t.jsxs)("div",{className:"text-sm text-text-secondary mb-2",children:[(0,t.jsx)("strong",{children:"護理員編號："})," ",r.staff_id||"—"]}),(0,t.jsxs)("div",{className:"text-sm text-text-secondary mb-2",children:[(0,t.jsx)("strong",{children:"服務類型："})," ",r.service_type]}),(0,t.jsxs)("div",{className:"text-sm text-text-secondary",children:[(0,t.jsx)("strong",{children:"時間："})," ",r.start_time," - ",r.end_time]})]}),(0,t.jsxs)("div",{className:"space-y-3",children:[(0,t.jsx)("button",{onClick:n,className:"w-full px-4 py-3 bg-blue-500 text-white rounded-xl hover:bg-primary-dark transition-colors text-left",children:(0,t.jsxs)("div",{className:"flex items-center",children:[(0,t.jsx)("svg",{className:"w-5 h-5 mr-3",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"})}),"編輯排程"]})}),(0,t.jsx)("button",{onClick:()=>{confirm("確定要刪除這個排程嗎？")&&l()},className:"w-full px-4 py-3 bg-red-500 text-white rounded-xl hover:bg-red-600 transition-colors text-left",children:(0,t.jsxs)("div",{className:"flex items-center",children:[(0,t.jsx)("svg",{className:"w-5 h-5 mr-3",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"})}),"刪除排程"]})})]})]}),(0,t.jsx)("div",{className:"p-6 border-t border-border-light bg-bg-secondary",children:(0,t.jsx)("button",{onClick:a,className:"w-full px-4 py-2 text-text-secondary border border-border-light rounded-xl hover:bg-bg-primary transition-all duration-300",children:"取消"})})]})}):null}e.s(["default",0,function(){let[e,o]=(0,n.useState)(null),[i,p]=(0,n.useState)(!0),[h,g]=(0,n.useState)(!1),[f,b]=(0,n.useState)(!1),[v,y]=(0,n.useState)(!1),[_,j]=(0,n.useState)("reports"),N=(0,c.useRouter)();(0,n.useEffect)(()=>{let e=()=>{let e=new URLSearchParams(window.location.search).get("tab");("overview"===e||"schedule"===e||"reports"===e)&&j(e)};window.addEventListener("popstate",e);let t=window.requestAnimationFrame(e);return()=>{window.cancelAnimationFrame(t),window.removeEventListener("popstate",e)}},[]);let[w,$]=(0,n.useState)(()=>{let e=new Date,t=new Date(e.getFullYear(),e.getMonth(),1),r=new Date(e.getFullYear(),e.getMonth()+1,0);return{dateRange:{start:Y(t),end:Y(r)},projectCategory:[]}}),[F,z]=(0,n.useState)(null),[L,R]=(0,n.useState)([]),[E,I]=(0,n.useState)(null),[P,O]=(0,n.useState)(!1),[H,B]=(0,n.useState)(0),[A,U]=(0,n.useState)(null),[K,J]=(0,n.useState)({});(0,n.useEffect)(()=>{(()=>{let e={},t=new Date;console.log("🔍 開始掃描 localStorage 中的記錄更新時間...");for(let r=0;r<localStorage.length;r++){let a=localStorage.key(r);if(a?.startsWith("service_update_")){let r=a.replace("service_update_",""),s=localStorage.getItem(a);if(s){let l;if(s.includes("T")&&s.includes("Z"))l=new Date(s);else{let e=parseInt(s,10);if(isNaN(e)){console.warn("⚠️ 無效的時間格式，跳過記錄:",{key:a,timeStr:s});continue}l=new Date(e)}if(isNaN(l.getTime())){console.warn("⚠️ 無效的Date對象，跳過記錄:",{key:a,timeStr:s});continue}let n=(t.getTime()-l.getTime())/6e4;console.log("📝 找到記錄更新時間:",{recordId:r,updateTime:l.toISOString(),diffInMinutes:Math.round(100*n)/100}),n<30?(e[r]=l,console.log("✅ 記錄在30分鐘內，已加載")):(localStorage.removeItem(a),console.log("🗑️ 記錄超過30分鐘，已清除"))}}}console.log("🔄 載入記錄更新時間完成，總共載入:",Object.keys(e).length,"筆記錄"),console.log("📊 載入的記錄更新時間:",e),J(e),console.log("✅ setRecordUpdateTimes 已調用，期望觸發重新渲染")})()},[H]),(0,n.useEffect)(()=>{let e=e=>{if(e?.detail?.recordId){let t=e.detail.recordId,r=localStorage.getItem(`service_update_${t}`);if(r){let e;if(r.includes("T")&&r.includes("Z"))e=new Date(r);else{let a=parseInt(r,10);if(isNaN(a))return void console.warn("⚠️ 事件處理器: 無效的時間格式",{recordId:t,timeStr:r});e=new Date(a)}isNaN(e.getTime())||(J(r=>({...r,[t]:e})),console.log("🔔 事件處理器更新記錄時間:",{recordId:t,updateTime:e.toISOString()}),console.log("🔄 事件處理器 setRecordUpdateTimes 已調用，期望觸發重新渲染"),B(e=>e+1),console.log("🔃 觸發 refreshTrigger 以強制重新渲染組件"))}}},t=()=>{let e=localStorage.getItem("recordUpdated");if(e){let{recordId:t,updateTime:r}=JSON.parse(e);J(e=>({...e,[t]:new Date(r)})),localStorage.removeItem("recordUpdated")}};return t(),window.addEventListener("storage",t),window.addEventListener("recordUpdated",e),()=>{window.removeEventListener("storage",t),window.removeEventListener("recordUpdated",e)}},[]);let[X,ee]=(0,n.useState)(!1),[et,er]=(0,n.useState)("pdf"),[ea,es]=(0,n.useState)("accounting"),[el,en]=(0,n.useState)("combined"),[eo,ei]=(0,n.useState)(!1),[ed,ec]=(0,n.useState)({}),[em,ex]=(0,n.useState)([]),[ep,eu]=(0,n.useState)(!0),[eh,eg]=(0,n.useState)({service_date:!0,customer_id:!1,customer_name:!0,phone:!1,service_address:!0,start_time:!0,end_time:!0,service_hours:!0,care_staff_name:!0,staff_id:!1,service_fee:!1,staff_salary:!1,service_profit:!1,hourly_rate:!1,hourly_salary:!1,service_type:!0,project_category:!1,project_manager:!1}),ef={accounting:{name:"對數模式",description:"包含服務費用和收費相關欄位",columns:{service_date:!0,customer_name:!0,service_address:!0,start_time:!0,end_time:!0,service_hours:!0,care_staff_name:!0,staff_id:!1,service_type:!0,service_fee:!0,service_profit:!0,hourly_rate:!0,customer_id:!1,phone:!1,staff_salary:!1,hourly_salary:!1,project_category:!1,project_manager:!1}},payroll:{name:"工資模式",description:"包含護理員工資和薪酬相關欄位",columns:{service_date:!0,customer_name:!0,service_address:!0,start_time:!0,end_time:!0,service_hours:!0,care_staff_name:!1,staff_id:!0,service_type:!0,staff_salary:!0,service_profit:!1,hourly_salary:!0,customer_id:!1,phone:!1,service_fee:!1,hourly_rate:!1,project_category:!1,project_manager:!1}}},eb=()=>{B(e=>e+1)},ev=async e=>{if(E)try{b(!0),console.log("🔄 主要組件 handleEditSave 開始更新記錄:",{recordId:E.id,formData:e});let t=await S(E.id,e);if(console.log("📝 主要組件 handleEditSave 更新結果:",t),t.success){let e=new Date,t=e.toISOString();console.log("🕐 設置記錄更新時間:",{recordId:E.id,updateTime:t}),J(t=>({...t,[E.id]:e})),localStorage.setItem(`service_update_${E.id}`,t),console.log("💾 localStorage 已設置:",`service_update_${E.id}`,t),window.dispatchEvent(new CustomEvent("recordUpdated",{detail:{recordId:E.id}})),console.log("📡 recordUpdated 事件已觸發:",E.id),O(!1),I(null),U(new Date),setTimeout(()=>{console.log("✅ 記錄更新成功！")},100)}else throw Error(t.error||"更新記錄失敗")}catch(e){throw console.error("更新記錄失敗:",e),e}finally{b(!1)}},ey=async e=>{if(confirm("確定要刪除這筆記錄嗎？此操作無法撤銷。"))try{b(!0),console.log("🗑️ 主要組件 handleDelete 開始刪除記錄:",e);let t=await C(e);console.log("🗑️ 主要組件 handleDelete 刪除結果:",t),t.success?(alert("記錄刪除成功！"),eb(),U(new Date),J(t=>({...t,[e]:new Date}))):alert("刪除記錄失敗："+(t.error||"未知錯誤"))}catch(e){console.error("刪除記錄失敗:",e),alert("刪除記錄失敗，請重試")}finally{b(!1)}};(0,n.useEffect)(()=>{(async()=>{let{data:{user:e}}=await s.supabase.auth.getUser();e?o(e):N.push("/"),p(!1)})()},[N]);let e_=(0,n.useCallback)(()=>D({start:w.dateRange?.start||"",end:w.dateRange?.end||""}).then(async e=>{e.success&&e.data&&z(e.data);let t=await M({start:w.dateRange?.start||"",end:w.dateRange?.end||""});t.success&&t.data&&R(t.data)}).catch(e=>{console.error("載入數據失敗:",e)}),[w.dateRange]);(0,n.useEffect)(()=>{e&&"overview"===_&&e_().finally(()=>g(!1))},[e,_,e_]),(0,n.useEffect)(()=>{eo&&(async()=>{eu(!0);try{let e=await k(w);if(e.success&&e.data){let t=new Map;e.data.filter(e=>e.care_staff_name&&""!==e.care_staff_name.trim()).forEach(e=>{let r=e.care_staff_name.trim(),a=e.staff_id?.trim()||null,s=W(a),l=V(r),n=s||l;n&&(t.has(n)||t.set(n,{name:r,staffId:a,normalizedName:l,normalizedId:s}))});let r=Array.from(t.values()).sort((e,t)=>(e.normalizedName||"").localeCompare(t.normalizedName||"","zh-HK"));ex(r)}}catch(e){console.error("載入護理員列表失敗:",e)}finally{eu(!1)}})()},[eo,w]);let ej=e=>{let t,r,a=new Date;switch(e){case"last7days":t=new Date(a.getTime()-6048e5),r=a;break;case"last30days":t=new Date(a.getTime()-2592e6),r=a;break;case"last90days":t=new Date(a.getTime()-7776e6),r=a;break;case"thisMonth":t=new Date(a.getFullYear(),a.getMonth(),1),r=new Date(a.getFullYear(),a.getMonth()+1,0);break;case"lastMonth":t=new Date(a.getFullYear(),a.getMonth()-1,1),r=new Date(a.getFullYear(),a.getMonth(),0);break;case"last3months":t=new Date(a.getFullYear(),a.getMonth()-2,1),r=new Date(a.getFullYear(),a.getMonth()+1,0);break;case"last6months":t=new Date(a.getFullYear(),a.getMonth()-5,1),r=new Date(a.getFullYear(),a.getMonth()+1,0);break;case"thisQuarter":let s=3*Math.floor(a.getMonth()/3);t=new Date(a.getFullYear(),s,1),r=new Date(a.getFullYear(),s+3,0);break;case"thisYear":t=new Date(a.getFullYear(),0,1),r=new Date(a.getFullYear(),12,0);break;default:return}$(e=>({...e,dateRange:{start:Y(t),end:Y(r)}}))},eN=async()=>{y(!0);try{console.log("🚀 開始導出日曆，格式:","pdf");let e=await T({format:"pdf",filters:w,includeStaffDetails:!0,includeCustomerDetails:!1,timezone:"Asia/Hong_Kong"});if(e.success&&e.data){console.log("✅ 日曆 HTML 內容已生成");let t=e.data,a=window.open("","_blank");if(a&&a.document)a.opener=null,a.document.open(),a.document.write((0,r.f)(t)),a.document.close();else{console.warn("瀏覽器封鎖了彈出視窗，於目前頁面開啟日曆。");let e=new Blob([(0,r.f)(t)],{type:"text/html;charset=utf-8"}),a=URL.createObjectURL(e);window.location.href=a,setTimeout(()=>{URL.revokeObjectURL(a)},6e4)}}else console.error("❌ 日曆導出失敗:",e.error),alert(`日曆導出失敗: ${e.error}`)}catch(e){console.error("❌ 日曆導出錯誤:",e),alert("日曆導出失敗，請稍後再試")}finally{y(!1)}},ew=async()=>{b(!0),ee(!1);try{let e=await k(w);if(!e.success||!e.data)throw Error("無法獲取數據");let t=e.data||[];"accounting"===ea&&(t=t.sort((e,t)=>{let r=(e.customer_name||"").localeCompare(t.customer_name||"","zh-TW");if(0!==r)return r;let a=new Date(e.service_date||""),s=new Date(t.service_date||"");return a.getTime()-s.getTime()}));let r=Object.entries(eh).filter(([e,t])=>t).map(([e,t])=>e);"pdf"===et?"payroll"===ea&&"separate"===el?(ee(!1),ei(!0),ec({})):await eS(t,r):await eC(t,r),alert("導出成功")}catch(e){console.error("Export error:",e),alert("導出時發生錯誤")}finally{b(!1)}},ek=async(e,t,r)=>{try{let a=eD(e),s=eM(e),l=(t||[]).filter(t=>eF(t,e));if(0===l.length)return void alert(`${s} 沒有符合條件的記錄`);l.sort((e,t)=>new Date(e.service_date).getTime()-new Date(t.service_date).getTime()),await e$(l,r,e),a&&ec(e=>({...e,[a]:"downloaded"}))}catch(e){console.error("下載護理員PDF時發生錯誤:",e),alert("下載護理員PDF時發生錯誤")}},e$=async(e,t,a)=>{let n=a.name,o=eM(a),i=null;try{if(a.staffId){let{data:e,error:t}=await s.supabase.from("care_staff_profiles").select("staff_id, name_chinese, name_english, hkid").eq("staff_id",a.staffId).single();!t&&e&&(i=e)}if(!i){let{data:e,error:t}=await s.supabase.from("care_staff_profiles").select("staff_id, name_chinese, name_english, hkid").eq("name_chinese",n).single();!t&&e&&(i=e)}}catch(e){console.error("查詢護理人員資料失敗:",e)}let d={service_date:"服務日期",customer_id:"客戶編號",customer_name:"客戶姓名",phone:"客戶電話",service_address:"服務地址",start_time:"開始時間",end_time:"結束時間",service_hours:"服務時數",care_staff_name:"護理員姓名",staff_id:"護理員編號",service_fee:"服務費用",staff_salary:"護理員工資",service_profit:"服務利潤",hourly_rate:"每小時收費",hourly_salary:"每小時工資",service_type:"服務類型",project_category:"所屬項目",project_manager:"項目經理",service_time:"服務時間",customer_address:"客戶地址",notes:"備註"},c=e.length,x=e.reduce((e,t)=>{let r=parseFloat(String(t.service_hours||"0"));return Math.round((e+(isNaN(r)?0:r))*100)/100},0),p=e.reduce((e,t)=>{let r=parseFloat(String(t.staff_salary||"0"));return Math.round((e+(isNaN(r)?0:r))*100)/100},0);e.reduce((e,t)=>{let r=t.project_category||"未分類";return e[r]||(e[r]={count:0,hours:0,salary:0}),e[r].count+=1,e[r].hours=Math.round((e[r].hours+parseFloat(String(t.service_hours||"0")))*100)/100,e[r].salary=Math.round((e[r].salary+parseFloat(String(t.staff_salary||"0")))*100)/100,e},{});let u=new Date;u.getFullYear(),String(u.getMonth()+1).padStart(2,"0"),String(u.getDate()).padStart(2,"0");let h=e[0],g=new Date(h?.service_date||u),f=`${g.getFullYear()}-${String(g.getMonth()+1).padStart(2,"0")}`,b=(0,m.f)("images/mingcare-logo.png"),v=await l(),y=`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>${o} ${f}工資明細</title>
        <style>
          @page {
            size: A4 portrait;
            margin: 15mm;
          }
          body {
            font-family: "PingFang TC", "Microsoft JhengHei", "SimHei", sans-serif;
            margin: 0;
            padding: 15px;
            font-size: max(11px, 0.8vw);
            line-height: 1.3;
            min-font-size: 9px;
          }
          @media print {
            body {
              font-size: 11px !important;
            }
            .responsive-text {
              font-size: max(9px, 10px) !important;
            }
            .keep-together {
              page-break-inside: avoid;
            }
            table {
              page-break-inside: auto;
            }
            tr {
              page-break-inside: avoid;
              page-break-after: auto;
            }
          }
          .header-container {
            margin-bottom: 20px;
            position: relative;
          }
          .company-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
          }
          .company-info {
            flex: 1;
            text-align: left;
          }
          .company-logo {
            flex: 0 0 180px;
            text-align: center;
          }
          .company-logo img {
            max-width: 180px;
            max-height: 180px;
          }
          .company-stamp {
            flex: 0 0 60px;
            text-align: center;
          }
          .company-stamp img {
            max-width: 60px;
            max-height: 60px;
          }
          .company-name {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 5px;
          }
          .company-details {
            font-size: 11px;
            line-height: 1.4;
          }
          .staff-info {
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 8px;
            margin-bottom: 15px;
          }
          .staff-info-title {
            font-size: 12px;
            font-weight: bold;
            margin-bottom: 6px;
            color: #495057;
          }
          .staff-details {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 6px;
            font-size: 10px;
          }
          .staff-field {
            display: flex;
          }
          .staff-field strong {
            width: 70px;
            color: #495057;
          }
          .header {
            text-align: center;
            margin-bottom: 15px;
          }
          .title {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 8px;
          }
          .subtitle {
            font-size: 12px;
            margin-bottom: 5px;
          }
          .summary {
            margin-bottom: 15px;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            font-size: max(10px, 0.7vw);
          }
          th, td {
            border: 1px solid #ddd;
            padding: 6px 4px;
            text-align: left;
            font-size: max(10px, 0.7vw);
            word-wrap: break-word;
          }
          @media print {
            table {
              font-size: 10px !important;
            }
            th, td {
              font-size: 10px !important;
              padding: 4px 3px;
            }
          }
          th {
            background-color: #f2f2f2;
            font-weight: bold;
          }
          tr:nth-child(even) {
            background-color: #f9f9f9;
          }
        </style>
      </head>
      <body>
        <div class="header-container">
          <!-- 公司信息與標誌 -->
          <div class="company-header">
            <div class="company-info">
              <div class="company-name">明家居家護理服護有限公司</div>
              <div class="company-details">
                地址：新界荃灣橫龍街43-47號龍力工業大廈3樓308室<br>
                電話：+852 2338 1811<br>
                電郵：info@mingcarehome.com<br>
                網址：www.mingcarehome.com
              </div>
            </div>
            <div class="company-logo">
              <img src="${b}" alt="明家居家護理標誌" onerror="this.style.display='none'">
            </div>
          </div>

          <!-- 護理人員資料 -->
          ${i?`
          <div class="staff-info">
              <div class="staff-info-title">護理人員資料</div>
              <div class="staff-details">
                <div class="staff-field">
                  <strong>中文姓名:</strong>
                  <span>${i.name_chinese||n}</span>
                </div>
              <div class="staff-field">
                <strong>英文姓名:</strong>
                <span>${i.name_english||""}</span>
              </div>
              <div class="staff-field">
                  <strong>員工編號:</strong>
                <span>${i.staff_id||a.staffId||""}</span>
              </div>
              <div class="staff-field">
                <strong>身份證號:</strong>
                <span>${i.hkid?i.hkid.substring(0,Math.max(0,i.hkid.length-4))+"xxxx":""}</span>
              </div>
            </div>
          </div>
          `:""}
        </div>

        <table>
          <thead>
            <tr>
              ${t.map(e=>`<th>${d[e]||e}</th>`).join("")}
            </tr>
          </thead>
          <tbody>
            ${e.map(e=>`
              <tr>
                ${t.map(t=>{let r="";switch(t){case"service_date":let a=new Date(e[t]);r=`${a.getFullYear()}-${String(a.getMonth()+1).padStart(2,"0")}-${String(a.getDate()).padStart(2,"0")}`;break;case"start_time":case"end_time":let s=e[t]||"";if(s.includes("T")||s.includes(" ")){let e=new Date(s);r=`${String(e.getHours()).padStart(2,"0")}:${String(e.getMinutes()).padStart(2,"0")}`}else r=s;break;case"service_hours":let l=parseFloat(String(e[t]||"0"));r=isNaN(l)?"0":l.toString();break;case"staff_salary":case"service_fee":case"hourly_rate":case"hourly_salary":case"billing_amount":let n=parseFloat(e[t]||"0");r=isNaN(n)?"$0.00":`$${n.toFixed(2)}`;break;case"service_profit":let o;o=void 0!==e.profit&&null!==e.profit?"number"==typeof e.profit?e.profit:parseFloat(String(e.profit)):parseFloat(e.service_fee||"0")-parseFloat(e.staff_salary||"0"),r=`$${o.toFixed(2)}`;break;default:r=String(e[t]||"")}return`<td>${r}</td>`}).join("")}
              </tr>
            `).join("")}
          </tbody>
        </table>

        <!-- 底部佈局：左邊統計，右邊印章 -->
        <div style="margin-top: 20px; display: flex; justify-content: space-between; align-items: flex-end;">
          <!-- 左邊：總計統計資訊 -->
          <div style="flex: 1;">
            <div style="margin-bottom: 5px; font-size: 12px;"><strong>總服務次數:</strong> ${c} 次</div>
            <div style="margin-bottom: 5px; font-size: 12px;"><strong>總時數:</strong> ${x.toFixed(1)} 小時</div>
            <div style="font-weight: bold; font-size: 14px; color: #000000;"><strong>總工資:</strong> $${p.toFixed(2)}</div>
          </div>
          <!-- 右邊：公司印章 -->
          <div style="flex: 0 0 auto;">
            <img src="${v}" alt="公司印章" style="width: 80px; height: auto;" onerror="this.style.display='none'">
          </div>
        </div>
      </body>
      </html>
    `,_=window.open("","_blank");_&&(_.document.write((0,r.f)(y)),_.document.close(),_.addEventListener("load",()=>{setTimeout(()=>{_.print(),_.close()},500)}))},eS=async(e,t)=>{try{let a={service_date:"服務日期",customer_id:"客戶編號",customer_name:"客戶姓名",phone:"客戶電話",service_address:"服務地址",start_time:"開始時間",end_time:"結束時間",service_hours:"服務時數",care_staff_name:"護理員姓名",service_fee:"服務費用",staff_salary:"護理員工資",service_profit:"服務利潤",staff_id:"護理員編號",hourly_rate:"每小時收費",hourly_salary:"每小時工資",service_type:"服務類型",project_category:"所屬項目",project_manager:"項目經理"},n=(e,t)=>{if("service_profit"===t){let t;return isNaN(t=void 0!==e.profit&&null!==e.profit?"number"==typeof e.profit?e.profit:parseFloat(String(e.profit)):parseFloat(String(e.service_fee||"0"))-parseFloat(String(e.staff_salary||"0")))?"$0.00":`$${t.toFixed(2)}`}let r=["service_fee","staff_salary","hourly_rate","hourly_salary"].includes(t),a=e[t];if(r){let e="number"==typeof a?a:parseFloat(String(a||"0"));return isNaN(e)?"$0.00":`$${e.toFixed(2)}`}if("service_hours"===t){let e="number"==typeof a?a:parseFloat(String(a||"0"));return isNaN(e)?"0":e.toFixed(1)}return String(a||"")},o="accounting"===ea,i=[...new Set(e.map(e=>e.customer_id).filter(Boolean))],d={},c={},x={};if(i.length>0)try{for(let e=0;e<i.length;e+=100){let t=i.slice(e,e+100),{data:r}=await s.supabase.from("customer_personal_data").select("customer_id, customer_name, voucher_number, hkid").in("customer_id",t);r&&r.forEach(e=>{e.voucher_number&&(d[e.customer_id]=e.voucher_number),e.hkid&&(c[e.customer_id]=e.hkid),e.customer_name&&e.customer_id&&(x[e.customer_name]=e.customer_id)})}}catch(e){console.error("獲取客戶資料失敗:",e)}e.forEach(e=>{e.customer_name&&e.customer_id&&!x[e.customer_name]&&(x[e.customer_name]=e.customer_id)});let p="",u="";if(o){let r={};(e||[]).forEach(e=>{let t=e.customer_name||"未知客戶";r[t]||(r[t]=[]),r[t].push(e)});let s=Object.keys(r).length,l=e.length,o=0,i=0,m=0,h=0;p=Object.keys(r).map((e,s)=>{let l=r[e],p=0,u=0,g=0,f=0,b=l.map(e=>(p=Math.round((p+parseFloat(e.service_hours||"0"))*100)/100,u=Math.round((u+parseFloat(e.service_fee||"0"))*100)/100,g=Math.round((g+parseFloat(String(e.staff_salary||"0")))*100)/100,f=Math.round((f+(void 0!==e.profit?e.profit:(e.service_fee||0)-(e.staff_salary||0)))*100)/100,`
              <tr>
                ${t.map(t=>{let r=n(e,t),a=["hourly_rate","hourly_salary","service_hours","service_fee","staff_salary","service_profit"].includes(t);return`<td class="${a?"number":""}">${r}</td>`}).join("")}
              </tr>
            `)).join(""),v=t.map((r,a)=>{t.length;let s="text-align: right; font-weight: bold; background-color: #f0f8ff; border-top: 2px solid #428bca;";if(0===a)return`<td colspan="1" style="${s} text-align: left;">${e} 小結</td>`;switch(r){case"service_hours":return`<td style="${s}">${p.toFixed(1)}</td>`;case"service_fee":return`<td style="${s}">$${u.toFixed(2)}</td>`;case"staff_salary":return`<td style="${s}">$${g.toFixed(2)}</td>`;case"service_profit":return`<td style="${s}">$${f.toFixed(2)}</td>`;default:return`<td style="${s}"></td>`}}).join(""),y=`<tr class="customer-subtotal">${v}</tr>`;o=Math.round((o+p)*100)/100,i=Math.round((i+u)*100)/100,m=Math.round((m+g)*100)/100,h=Math.round((h+f)*100)/100;let _=x[e]||l[0]?.customer_id||"",j=_&&c[_]||"",N=_&&d[_]||"",w=[];j&&w.push(`身份證: ${j}`),N&&w.push(`CCSV: ${N}`);let k=w.length>0?` <span style="font-size: 13px; color: #666; font-weight: normal;">(${w.join(" | ")})</span>`:"";return`
            <div class="customer-group">
              <h3 style="color: #428bca; margin: 20px 0 10px 0; font-size: 16px; border-bottom: 1px solid #428bca; padding-bottom: 5px;">
                ${e}${k} (${l.length} 次服務)
              </h3>
              <table>
                <thead>
                  <tr>
                    ${t.map(e=>`<th>${a[e]||e}</th>`).join("")}
                  </tr>
                </thead>
                <tbody>
                  ${b}
                  ${y}
                </tbody>
              </table>
            </div>
          `}).join("");let g={},f={};e.forEach(e=>{let t=e.service_type||"未知服務類型",r=e.project_category||"未分類",a=parseFloat(e.service_hours||"0"),s=parseFloat(e.service_fee||"0"),l=parseFloat(String(e.staff_salary||"0")),n=void 0!==e.profit?e.profit:s-l;g[t]||(g[t]={count:0,hours:0,amount:0,salary:0,profit:0}),f[r]||(f[r]={count:0,hours:0,amount:0,salary:0,profit:0}),g[t].count+=1,g[t].hours+=a,g[t].amount+=s,g[t].salary+=l,g[t].profit+=n,f[r].count+=1,f[r].hours+=a,f[r].amount+=s,f[r].salary+=l,f[r].profit+=n});let b=[];b.push(`
          <div style="text-align: center;">
            <div style="font-weight: bold; color: #428bca;">客戶總數</div>
            <div style="font-size: 18px; font-weight: bold;">${s}</div>
          </div>
        `),b.push(`
          <div style="text-align: center;">
            <div style="font-weight: bold; color: #428bca;">服務次數</div>
            <div style="font-size: 18px; font-weight: bold;">${l}</div>
          </div>
        `),t.includes("service_hours")&&b.push(`
            <div style="text-align: center;">
              <div style="font-weight: bold; color: #428bca;">總服務時數</div>
              <div style="font-size: 18px; font-weight: bold;">${o.toFixed(1)}</div>
            </div>
          `),t.includes("service_fee")&&b.push(`
            <div style="text-align: center;">
              <div style="font-weight: bold; color: #428bca;">總服務費用</div>
              <div style="font-size: 18px; font-weight: bold;">$${i.toFixed(2)}</div>
            </div>
          `),t.includes("staff_salary")&&b.push(`
            <div style="text-align: center;">
              <div style="font-weight: bold; color: #428bca;">總人工</div>
              <div style="font-size: 18px; font-weight: bold;">$${m.toFixed(2)}</div>
            </div>
          `),t.includes("service_profit")&&b.push(`
            <div style="text-align: center;">
              <div style="font-weight: bold; color: #428bca;">總利潤</div>
              <div style="font-size: 18px; font-weight: bold;">$${h.toFixed(2)}</div>
            </div>
          `);let v=['<th style="padding: 8px; border: 1px solid #ddd; text-align: left;">所屬項目</th>'];v.push('<th style="padding: 8px; border: 1px solid #ddd; text-align: center;">次數</th>'),t.includes("service_hours")&&v.push('<th style="padding: 8px; border: 1px solid #ddd; text-align: center;">時數</th>'),t.includes("service_fee")&&v.push('<th style="padding: 8px; border: 1px solid #ddd; text-align: center;">金額</th>'),t.includes("staff_salary")&&v.push('<th style="padding: 8px; border: 1px solid #ddd; text-align: center;">人工</th>'),t.includes("service_profit")&&v.push('<th style="padding: 8px; border: 1px solid #ddd; text-align: center;">利潤</th>');let y=Object.entries(f).sort(([e],[t])=>e.localeCompare(t,"zh-TW")).map(([e,r])=>{let a=[`<td style="padding: 8px; border: 1px solid #ddd;">${e}</td>`];return a.push(`<td style="padding: 8px; border: 1px solid #ddd; text-align: center;">${r.count}</td>`),t.includes("service_hours")&&a.push(`<td style="padding: 8px; border: 1px solid #ddd; text-align: center;">${r.hours.toFixed(1)}</td>`),t.includes("service_fee")&&a.push(`<td style="padding: 8px; border: 1px solid #ddd; text-align: right;">$${r.amount.toFixed(2)}</td>`),t.includes("staff_salary")&&a.push(`<td style="padding: 8px; border: 1px solid #ddd; text-align: right;">$${r.salary.toFixed(2)}</td>`),t.includes("service_profit")&&a.push(`<td style="padding: 8px; border: 1px solid #ddd; text-align: right;">$${r.profit.toFixed(2)}</td>`),`<tr>${a.join("")}</tr>`}).join(""),_=['<td style="padding: 8px; border: 1px solid #ddd;">總計</td>'];_.push(`<td style="padding: 8px; border: 1px solid #ddd; text-align: center;">${l}</td>`),t.includes("service_hours")&&_.push(`<td style="padding: 8px; border: 1px solid #ddd; text-align: center;">${o.toFixed(1)}</td>`),t.includes("service_fee")&&_.push(`<td style="padding: 8px; border: 1px solid #ddd; text-align: right;">$${i.toFixed(2)}</td>`),t.includes("staff_salary")&&_.push(`<td style="padding: 8px; border: 1px solid #ddd; text-align: right;">$${m.toFixed(2)}</td>`),t.includes("service_profit")&&_.push(`<td style="padding: 8px; border: 1px solid #ddd; text-align: right;">$${h.toFixed(2)}</td>`);let j=Object.keys(g).sort().map(e=>{let r=g[e],a=[`<td style="padding: 8px; border: 1px solid #ddd;">${e}</td>`];return a.push(`<td style="padding: 8px; border: 1px solid #ddd; text-align: center;">${r.count}</td>`),t.includes("service_hours")&&a.push(`<td style="padding: 8px; border: 1px solid #ddd; text-align: center;">${r.hours.toFixed(1)}</td>`),t.includes("service_fee")&&a.push(`<td style="padding: 8px; border: 1px solid #ddd; text-align: right;">$${r.amount.toFixed(2)}</td>`),t.includes("staff_salary")&&a.push(`<td style="padding: 8px; border: 1px solid #ddd; text-align: right;">$${r.salary.toFixed(2)}</td>`),t.includes("service_profit")&&a.push(`<td style="padding: 8px; border: 1px solid #ddd; text-align: right;">$${r.profit.toFixed(2)}</td>`),`<tr>${a.join("")}</tr>`}).join("");u=`
          <div style="margin-top: 30px; padding: 20px; border: 2px solid #428bca; background-color: #f8f9fa; page-break-inside: avoid;">
            <h3 style="text-align: center; color: #428bca; margin-bottom: 15px;">總結報告</h3>

            <!-- 總覽統計 -->
            <div style="display: flex; justify-content: space-around; font-size: 14px; margin-bottom: 20px;">
              ${b.join("")}
            </div>

            <!-- 項目統計 -->
            <div style="margin-top: 20px;">
              <h4 style="color: #428bca; margin-bottom: 10px; text-align: center;">各項目小結</h4>
              <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
                <thead>
                  <tr style="background-color: #428bca; color: white;">
                    ${v.join("")}
                  </tr>
                </thead>
                <tbody>
                  ${y}
                  <tr style="background-color: #e7f3ff; font-weight: bold; border-top: 2px solid #428bca;">
                    ${_.join("")}
                  </tr>
                </tbody>
              </table>
            </div>

            <!-- 服務類型細分統計 -->
            <div style="margin-top: 20px;">
              <h4 style="color: #428bca; margin-bottom: 10px; text-align: center;">服務類型統計明細</h4>
              <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
                <thead>
                  <tr style="background-color: #428bca; color: white;">
                    ${v.join("")}
                  </tr>
                </thead>
                <tbody>
                  ${j}
                  <tr style="background-color: #e7f3ff; font-weight: bold; border-top: 2px solid #428bca;">
                    ${_.join("")}
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        `}else if("payroll"===ea){let r={},s={};(e||[]).forEach(e=>{let t=(e.care_staff_name||"未知護理人員").trim();if(!t)return;let a=e.staff_id?.trim(),l=a||t;r[l]||(r[l]=[],s[l]={name:t,staffId:a||void 0}),r[l].push(e)});let l=Object.keys(r).sort((e,t)=>(s[e]?.name||e).localeCompare(s[t]?.name||t,"zh-HK")),n=l.length,o=e.length,i=0,m=0;p=l.map(e=>{let l=r[e],n=s[e]?.name||"未知護理人員",o=s[e]?.staffId,p=o?`${n}（${o}）`:n;l.sort((e,t)=>new Date(e.service_date).getTime()-new Date(t.service_date).getTime());let u=0,h=0;l.forEach(e=>{let t=parseFloat(String(e.service_hours||"0")),r=parseFloat(String(e.staff_salary||"0"));u=Math.round((u+(isNaN(t)?0:t))*100)/100,h=Math.round((h+(isNaN(r)?0:r))*100)/100}),i=Math.round((i+u)*100)/100,m=Math.round((m+h)*100)/100;let g=new Set;return`
            <div class="staff-group">
              <div class="staff-header">
                <h2>${p}</h2>
                <div class="staff-info">記錄數: ${l.length}筆</div>
              </div>

              <table class="data-table">
                <thead>
                  <tr>
                    ${t.map(e=>`<th>${a[e]||e}</th>`).join("")}
                  </tr>
                </thead>
                <tbody>
                  ${l.map(e=>{let r=e.customer_name||"未知客戶",a=e.customer_id||r,s="";if(!g.has(a)){g.add(a);let l=e.customer_id||x[r]||"",n=l&&c[l]||"",o=l&&d[l]||"",i=[];n&&i.push(`身份證: ${n}`),o&&i.push(`CCSV: ${o}`),i.length>0&&(s=`<tr style="background-color: #f0f7ff; border-top: 1px solid #428bca;">
                          <td colspan="${t.length}" style="padding: 4px 8px; font-size: 11px; color: #2c5aa0; font-weight: 600;">
                            📋 ${r} — ${i.join(" | ")}
                          </td>
                        </tr>`)}return`${s}
                    <tr>
                      ${t.map(t=>{let r=e[t]||"",a=["hourly_rate","hourly_salary","service_hours","service_fee","staff_salary","service_profit"].includes(t),s=String(r);if("service_date"===t&&r){let e=new Date(r),t=e.getFullYear(),a=String(e.getMonth()+1).padStart(2,"0"),l=String(e.getDate()).padStart(2,"0");s=`${t}-${a}-${l}`}else if("service_profit"===t)s=void 0!==e.profit&&null!==e.profit?("number"==typeof e.profit?e.profit:parseFloat(String(e.profit))).toFixed(2):(parseFloat(String(e.service_fee||"0"))-parseFloat(String(e.staff_salary||"0"))).toFixed(2);else if(a&&r){let e=parseFloat(String(r));s=isNaN(e)?"0":e.toFixed(2)}return`<td class="${a?"number":""}">${s}</td>`}).join("")}
                    </tr>
                  `}).join("")}
                </tbody>
              </table>

              <div class="staff-summary">
                <div class="summary-row">
                  <div class="summary-item">
                    <span class="label">服務時數:</span>
                    <span class="value">${u.toFixed(1)} 小時</span>
                  </div>
                  <div class="summary-item">
                    <span class="label">護理員工資:</span>
                    <span class="value">$${h.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>
          `}).join("");let h={};e.forEach(e=>{let t=e.project_category||"未分類";h[t]||(h[t]={count:0,hours:0,salary:0}),h[t].count+=1,h[t].hours=Math.round((h[t].hours+parseFloat(String(e.service_hours||"0")))*100)/100,h[t].salary=Math.round((h[t].salary+parseFloat(String(e.staff_salary||"0")))*100)/100}),u=`
          <div class="total-summary-page">
            <div class="summary-header">
              <h2>工資總結</h2>
            </div>
            <div class="summary-stats">
              <div class="stat-row">
                <div class="stat-item">
                  <div class="stat-label">護理員數量</div>
                  <div class="stat-value">${n} 人</div>
                </div>
                <div class="stat-item">
                  <div class="stat-label">總服務時數</div>
                  <div class="stat-value">${i.toFixed(1)} 小時</div>
                </div>
                <div class="stat-item">
                  <div class="stat-label">總工資</div>
                  <div class="stat-value">$${m.toFixed(2)}</div>
                </div>
              </div>
            </div>

            <div class="staff-summary-table" style="margin-top: 30px;">
              <h3>各護理人員明細</h3>
              <table class="summary-table">
                <thead>
                  <tr>
                    <th>護理人員</th>
                    <th>服務次數</th>
                    <th>服務時數</th>
                    <th>工資</th>
                  </tr>
                </thead>
                <tbody>
                  ${l.map(e=>{let t=r[e],a=s[e]?.name||"未知護理人員",l=s[e]?.staffId,n=l?`${a}（${l}）`:a,o=t.reduce((e,t)=>{let r=parseFloat(String(t.service_hours||"0"));return e+(isNaN(r)?0:r)},0),i=t.reduce((e,t)=>{let r=parseFloat(String(t.staff_salary||"0"));return e+(isNaN(r)?0:r)},0);return`
                      <tr>
                        <td>${n}</td>
                        <td class="number">${t.length}</td>
                        <td class="number">${o.toFixed(1)}</td>
                        <td class="number">$${i.toFixed(2)}</td>
                      </tr>
                    `}).join("")}
                  <tr class="total-row">
                    <td><strong>總計</strong></td>
                    <td class="number"><strong>${o}</strong></td>
                    <td class="number"><strong>${i.toFixed(1)}</strong></td>
                    <td class="number"><strong>$${m.toFixed(2)}</strong></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        `}else{let r=new Set;p=e.map(e=>{let a=e.customer_name||"未知客戶",s=e.customer_id||a,l="";if(!r.has(s)){r.add(s);let n=e.customer_id||x[a]||"",o=n&&c[n]||"",i=n&&d[n]||"",m=[];o&&m.push(`身份證: ${o}`),i&&m.push(`CCSV: ${i}`),m.length>0&&(l=`<tr style="background-color: #f0f7ff; border-top: 1px solid #428bca;">
                <td colspan="${t.length}" style="padding: 4px 8px; font-size: 11px; color: #2c5aa0; font-weight: 600;">
                  📋 ${a} — ${m.join(" | ")}
                </td>
              </tr>`)}return`${l}
          <tr>
            ${t.map(t=>{let r=n(e,t),a=["hourly_rate","hourly_salary","service_hours","service_fee","staff_salary","service_profit"].includes(t);return`<td class="${a?"number":""}">${r}</td>`}).join("")}
          </tr>`}).join("")}let h=(0,m.f)("images/mingcare-logo.png"),g=await l(),f=(()=>{let e=w.dateRange?.start;if(e){let[t,r]=e.split("-").map(Number);return`${t}年${r}月服務記錄 - 明家居家護理服務`}return"服務記錄 - 明家居家護理服務"})(),b=`
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="UTF-8">
          <title>${f}</title>
          <style>
            @media print {
              @page {
                size: A4 portrait;
                margin: 12mm;
              }
              body {
                margin: 0;
                font-size: 10px;
              }
              .customer-group {
                page-break-inside: avoid;
                page-break-after: auto;
              }
              .customer-group:last-child {
                page-break-after: auto;
              }
              .staff-group {
                page-break-inside: avoid;
                page-break-after: auto;
              }
              .staff-group:last-child {
                page-break-after: auto;
              }
              .total-summary-page {
                page-break-before: auto;
              }
            }
            body {
              font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "微軟雅黑", Arial, sans-serif;
              font-size: max(10px, 0.7vw);
              line-height: 1.3;
              margin: 0;
              padding: 8px;
              min-font-size: 9px;
            }
            @media print {
              body {
                font-size: 10px !important;
              }
            }
            .header {
              text-align: center;
              margin-bottom: 15px;
              border-bottom: 2px solid #333;
              padding-bottom: 8px;
            }
            .header h1 {
              margin: 0;
              font-size: 16px;
              color: #333;
            }
            .header h2 {
              margin: 5px 0;
              font-size: 12px;
              color: #666;
            }
            .meta {
              text-align: center;
              margin: 8px 0;
              font-size: 9px;
              color: #888;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              margin: 8px 0;
              font-size: max(9px, 0.6vw);
            }
            th, td {
              border: 1px solid #ddd;
              padding: 3px 4px;
              text-align: left;
              word-wrap: break-word;
            }
            @media print {
              table {
                font-size: 9px !important;
              }
              th, td {
                font-size: 9px !important;
                padding: 2px 3px;
              }
            }
            th {
              background-color: #428bca;
              color: white;
              font-weight: bold;
              text-align: center;
              font-size: 10px;
            }
            tr:nth-child(even) {
              background-color: #f8f9fa;
            }
            .number {
              text-align: right;
            }
            .customer-subtotal {
              background-color: #f0f8ff !important;
            }
            .staff-group {
              margin-bottom: 30px;
            }
            .staff-header {
              background-color: #e8f4fd;
              padding: 15px;
              border-radius: 8px;
              margin-bottom: 15px;
              border-left: 4px solid #428bca;
            }
            .staff-header h2 {
              margin: 0;
              color: #2c5282;
              font-size: 18px;
            }
            .staff-info {
              color: #666;
              font-size: 14px;
              margin-top: 5px;
            }
            .staff-summary {
              background-color: #f8f9fa;
              padding: 15px;
              border-radius: 8px;
              margin-top: 15px;
              border: 1px solid #e0e0e0;
            }
            .summary-row {
              display: flex;
              justify-content: space-around;
              align-items: center;
            }
            .summary-item {
              text-align: center;
              flex: 1;
            }
            .summary-item .label {
              display: block;
              font-weight: bold;
              color: #666;
              font-size: 13px;
              margin-bottom: 5px;
            }
            .summary-item .value {
              display: block;
              font-size: 16px;
              font-weight: bold;
              color: #2c5282;
            }
            .total-summary-page {
              padding: 20px;
            }
            .summary-header {
              text-align: center;
              margin-bottom: 30px;
              border-bottom: 2px solid #428bca;
              padding-bottom: 15px;
            }
            .summary-header h2 {
              margin: 0;
              color: #2c5282;
              font-size: 24px;
            }
            .summary-stats {
              margin-bottom: 30px;
              background-color: #f8f9fa;
              padding: 20px;
              border-radius: 8px;
            }
            .stat-row {
              display: flex;
              justify-content: space-around;
              align-items: center;
            }
            .stat-item {
              text-align: center;
              flex: 1;
            }
            .stat-label {
              font-weight: bold;
              color: #666;
              font-size: 14px;
              margin-bottom: 8px;
            }
            .stat-value {
              font-size: 20px;
              font-weight: bold;
              color: #2c5282;
            }
            .staff-summary-table h3 {
              color: #2c5282;
              margin-bottom: 15px;
              font-size: 18px;
            }
            .summary-table {
              margin-top: 0;
            }
            .total-row {
              background-color: #e8f4fd !important;
              font-weight: bold;
            }
            .footer {
              margin-top: 15px;
              text-align: center;
              font-size: 10px;
              color: #666;
              border-top: 1px solid #ddd;
              padding-top: 10px;
            }
            @media screen {
              .print-button {
                position: fixed;
                top: 20px;
                right: 20px;
                background: #007bff;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 5px;
                cursor: pointer;
                font-size: 14px;
                z-index: 1000;
              }
              .print-button:hover {
                background: #0056b3;
              }
            }
            @media print {
              .print-button { display: none; }
            }
          </style>
        </head>
        <body>
          <button class="print-button" data-intranet-print>列印 / 儲存為PDF</button>

          <div class="header">
            <!-- Company Info and Logo Row -->
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 15px;">
              <!-- Left: Company Info -->
              <div style="flex: 1; font-size: 11px; line-height: 1.4; text-align: left;">
                <div style="font-weight: bold; color: #2c5aa0;">明家居家護理服護有限公司</div>
                <div>地址：新界荃灣橫龍街43-47號龍力工業大廈3樓308室</div>
                <div>電話：+852 2338 1811</div>
                <div>電郵：info@mingcarehome.com</div>
                <div>網址：www.mingcarehome.com</div>
              </div>

              <!-- Right: Company Logo -->
              <div style="flex: 0 0 auto; text-align: right;">
                <img src="${h}" alt="明家居家護理標誌" style="height: 80px; width: auto;">
              </div>
            </div>

            <h1>${f}</h1>
            ${o?'<div style="color: #428bca; font-weight: bold; margin-top: 5px;">對數模式</div>':""}
            ${"payroll"===ea?'<div style="color: #28a745; font-weight: bold; margin-top: 5px;">工資模式</div>':""}
          </div>

          <div class="meta">
            日期範圍: ${w.dateRange?.start||"未設定"} ~ ${w.dateRange?.end||"未設定"}<br>
            生成時間: ${new Date().toLocaleDateString("zh-TW")} ${new Date().toLocaleTimeString("zh-TW")}
          </div>

          ${o||"payroll"===ea?p:`
          <table>
            <thead>
              <tr>
                ${t.map(e=>`<th>${a[e]||e}</th>`).join("")}
              </tr>
            </thead>
            <tbody>
              ${p}
            </tbody>
          </table>
          `}

          ${u}

          <!-- 底部佈局：左邊統計，右邊印章 -->
          <div style="margin-top: 30px; display: flex; justify-content: space-between; align-items: flex-end;">
            <!-- 左邊：報表統計 -->
            <div style="flex: 1;">
              <div style="margin-bottom: 5px; font-size: 12px;"><strong>報表記錄數:</strong> ${e.length} 筆</div>
              <div style="margin-bottom: 5px; font-size: 12px;"><strong>欄位數:</strong> ${t.length} 個</div>
            </div>
            <!-- 右邊：公司印章 -->
            <div style="flex: 0 0 auto;">
              <img src="${g}" alt="公司印章" style="height: 80px; width: auto;">
            </div>
          </div>
        </body>
        </html>
      `,v=window.open("","_blank");if(v)v.document.write((0,r.f)(b)),v.document.close(),v.onload=()=>{setTimeout(()=>{v.focus()},500)};else{let e=new Blob([(0,r.f)(b)],{type:"text/html;charset=utf-8"}),t=URL.createObjectURL(e),a=document.createElement("a");a.href=t,a.download=`mingcare_report_${w.dateRange?.start||"unknown"}_${w.dateRange?.end||"unknown"}.html`,document.body.appendChild(a),a.click(),document.body.removeChild(a),URL.revokeObjectURL(t),alert("已下載HTML文件，請在瀏覽器中打開後列印或儲存為PDF")}}catch(e){throw console.error("PDF導出錯誤:",e),alert("PDF導出失敗，請稍後再試或選擇CSV格式"),e}},eC=async(e,t)=>{let r={service_date:"服務日期",customer_id:"客戶編號",customer_name:"客戶姓名",phone:"客戶電話",service_address:"服務地址",start_time:"開始時間",end_time:"結束時間",service_hours:"服務時數",care_staff_name:"護理員姓名",staff_id:"護理員編號",service_fee:"服務費用",staff_salary:"護理員工資",service_profit:"服務利潤",hourly_rate:"每小時收費",hourly_salary:"每小時工資",service_type:"服務類型",project_category:"所屬項目",project_manager:"項目經理"},s=new Blob(["\uFEFF"+[t.map(e=>r[e]||e).map(a.f).join(","),...e.map(e=>t.map(t=>{let r=e[t]??"";if("service_profit"===t)if(void 0!==e.profit&&null!==e.profit){let t="number"==typeof e.profit?e.profit:parseFloat(String(e.profit));r=`$${t.toFixed(2)}`}else{let t=parseFloat(e.service_fee||"0"),a=parseFloat(e.staff_salary||"0");r=`$${(t-a).toFixed(2)}`}if(["service_fee","staff_salary","hourly_rate","hourly_salary"].includes(t)){let e="number"==typeof r?r:parseFloat(String(r));isNaN(e)||(r=`$${e.toFixed(2)}`)}return(0,a.f)(r)}).join(","))].join("\n")],{type:"text/csv;charset=utf-8;"}),l=document.createElement("a"),n=URL.createObjectURL(s);l.setAttribute("href",n),l.setAttribute("download",`mingcare_report_${w.dateRange?.start||"unknown"}_${w.dateRange?.end||"unknown"}.csv`),l.style.visibility="hidden",document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(n)},eD=e=>e.normalizedId||e.normalizedName,eM=e=>e.staffId?`${e.name}（${e.staffId}）`:e.name,eF=(e,t)=>{let r=W(e.staff_id);if(t.normalizedId&&r)return t.normalizedId===r;let a=V(e.care_staff_name);return!!t.normalizedName&&!!a&&t.normalizedName===a},ez=async()=>{try{let e=await k(w);if(!e.success||!e.data)return void alert("無法獲取記錄資料");let t=e.data||[],r=Object.entries(eh).filter(([e,t])=>t).map(([e,t])=>e),a={};(em||[]).forEach(e=>{let t=eD(e);t&&(a[t]="downloading")}),ec(a);let s=0,l=0;for(let e of em)try{let a=t.filter(t=>eF(t,e));if(0===a.length){console.warn(`護理員 ${eM(e)} 沒有記錄`),ec(t=>({...t,[eD(e)]:"error"})),l++;continue}a.sort((e,t)=>new Date(e.service_date).getTime()-new Date(t.service_date).getTime()),await e$(a,r,e),ec(t=>({...t,[eD(e)]:"downloaded"})),s++,await new Promise(e=>setTimeout(e,1e3))}catch(t){console.error(`下載護理員 ${eM(e)} PDF失敗:`,t),ec(t=>({...t,[eD(e)]:"error"})),l++}s>0&&0===l?alert(`全部下載完成！成功下載 ${s} 個護理員的工資明細`):s>0&&l>0?alert(`部分下載完成！成功下載 ${s} 個，失敗 ${l} 個`):alert("下載全部失敗，請檢查資料並重試")}catch(e){console.error("批量下載失敗:",e),alert("批量下載時發生錯誤，請重試")}};return i?(0,t.jsx)(x.f,{message:"正在載入護理服務資料..."}):eo?(0,t.jsxs)("div",{className:"min-h-screen bg-bg-primary overflow-auto",children:[(0,t.jsx)("header",{className:"card-apple border-b border-border-light fade-in-apple sticky top-0 z-10",children:(0,t.jsx)("div",{className:"px-6 lg:px-8",children:(0,t.jsxs)("div",{className:"flex justify-between items-center py-8",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("h1",{className:"text-apple-title text-text-primary mb-2",children:"工資明細下載"}),(0,t.jsx)("p",{className:"text-apple-body text-text-secondary",children:"選擇護理員下載其工資明細"})]}),(0,t.jsx)("button",{onClick:()=>ei(!1),className:"px-4 py-2 text-primary border border-primary rounded-xl hover:bg-primary hover:text-white transition-all duration-300",children:"返回報表"})]})})}),(0,t.jsx)("main",{className:"px-6 lg:px-8 py-8 pb-16",children:(0,t.jsx)("div",{className:"card-apple",children:(0,t.jsxs)("div",{className:"p-6",children:[(0,t.jsxs)("div",{className:"flex items-center justify-between mb-6",children:[(0,t.jsx)("h3",{className:"text-lg font-medium text-text-primary",children:"護理員工資明細"}),!ep&&em&&em.length>0&&(0,t.jsxs)("button",{onClick:ez,disabled:Object.values(ed).some(e=>"downloading"===e),className:`px-6 py-2 rounded-xl font-medium transition-all duration-300 flex items-center space-x-2 ${Object.values(ed).some(e=>"downloading"===e)?"bg-bg-tertiary text-text-secondary border border-border-medium cursor-not-allowed":"bg-primary text-white hover:bg-primary-dark active:bg-primary-dark"}`,children:[(0,t.jsx)("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"})}),(0,t.jsx)("span",{children:Object.values(ed).some(e=>"downloading"===e)?"下載中...":"一次過全部下載"})]})]}),ep?(0,t.jsx)("div",{className:"text-center py-12",children:(0,t.jsx)("p",{className:"text-text-secondary",children:"載入中..."})}):em&&0!==em.length?(0,t.jsx)("div",{className:"space-y-4 max-h-none",children:em&&em.map(e=>{let r=eD(e),a="downloaded"===ed[r],s="downloading"===ed[r],l=`${eM(e)} ${(w.dateRange?.start||"unknown").substring(0,7)}工資明細`;return(0,t.jsxs)("div",{className:"flex items-center justify-between p-4 border border-border-light rounded-xl",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("h4",{className:"font-medium text-text-primary",children:l}),(0,t.jsxs)("p",{className:"text-sm text-text-secondary mt-1",children:["期間：",w.dateRange?.start||"未設定"," 至 ",w.dateRange?.end||"未設定"]})]}),(0,t.jsx)("div",{className:"flex items-center space-x-3",children:a?(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("div",{className:"px-4 py-2 bg-green-100 text-green-700 border border-green-300 rounded-xl font-medium",children:"已成功下載"}),(0,t.jsx)("button",{onClick:async()=>{ec(e=>({...e,[r]:"downloading"}));try{let t=await k(w);if(t.success&&t.data){let r=Object.entries(eh).filter(([e,t])=>t).map(([e,t])=>e);await ek(e,t.data||[],r)}}catch(e){console.error("下載失敗:",e),ec(e=>({...e,[r]:"error"})),alert("下載失敗，請重試")}},disabled:s,className:"px-4 py-2 bg-blue-100 text-blue-700 border border-blue-300 rounded-xl font-medium hover:bg-blue-200 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed",children:"再次下載"})]}):(0,t.jsx)("button",{onClick:async()=>{if(!s){ec(e=>({...e,[r]:"downloading"}));try{let t=await k(w);if(t.success&&t.data){let r=Object.entries(eh).filter(([e,t])=>t).map(([e,t])=>e);await ek(e,t.data||[],r)}}catch(e){console.error("下載失敗:",e),ec(e=>({...e,[r]:"error"})),alert("下載失敗，請重試")}}},disabled:s,className:`px-6 py-2 rounded-xl font-medium transition-all duration-300 ${s?"bg-bg-tertiary text-text-secondary border border-border-medium cursor-not-allowed":"bg-primary text-white hover:bg-primary-dark active:bg-primary-dark"}`,children:s?"下載中...":"下載"})})]},r)})}):(0,t.jsx)("div",{className:"text-center py-12",children:(0,t.jsx)("p",{className:"text-text-secondary",children:"沒有找到護理員資料"})})]})})})]}):(0,t.jsxs)("div",{className:"min-h-screen bg-bg-primary",children:[(0,t.jsx)("header",{className:"card-apple border-b border-border-light fade-in-apple",children:(0,t.jsx)("div",{className:"px-4 sm:px-6 lg:px-8",children:(0,t.jsxs)("div",{className:"flex flex-col sm:flex-row sm:justify-between sm:items-center py-4 sm:py-6 lg:py-8 space-y-4 sm:space-y-0",children:[(0,t.jsxs)("div",{className:"flex items-start gap-4",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("h1",{className:"text-xl sm:text-2xl lg:text-3xl font-bold text-text-primary mb-1 sm:mb-2",children:"護理服務管理"}),(0,t.jsx)("p",{className:"text-sm sm:text-base text-text-secondary",children:"安排護理服務、管理服務排程及記錄"})]}),(0,t.jsx)(u.f,{lastUpdateTime:A})]}),(0,t.jsx)("button",{onClick:()=>N.push("/dashboard"),className:"btn-apple-secondary text-xs sm:text-sm self-start sm:self-auto",children:"返回主頁"})]})})}),(0,t.jsxs)("main",{className:"px-4 sm:px-6 lg:px-8 py-4 sm:py-6 lg:py-8",children:[(0,t.jsx)("div",{className:"mb-4 sm:mb-6 lg:mb-8",children:(0,t.jsx)("div",{className:"card-apple border border-border-light fade-in-apple",children:(0,t.jsx)("div",{className:"p-3 sm:p-4",children:(0,t.jsxs)("nav",{className:"flex space-x-2 sm:space-x-3 bg-bg-tertiary/60 p-1.5 rounded-2xl",children:[(0,t.jsxs)("button",{onClick:()=>j("reports"),className:`flex-1 py-2.5 sm:py-3 px-3 sm:px-5 rounded-xl font-medium text-xs sm:text-sm transition-all duration-300 flex items-center justify-center space-x-1.5 sm:space-x-2 ${"reports"===_?"bg-white text-primary shadow-md":"text-text-secondary hover:text-text-primary hover:bg-white/50"}`,children:[(0,t.jsx)("svg",{className:"w-3.5 h-3.5 sm:w-4 sm:h-4 flex-shrink-0",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"})}),(0,t.jsx)("span",{className:"hidden sm:inline",children:"詳細報表"}),(0,t.jsx)("span",{className:"sm:hidden",children:"報表"})]}),(0,t.jsxs)("button",{onClick:()=>j("schedule"),className:`flex-1 py-2.5 sm:py-3 px-3 sm:px-5 rounded-xl font-medium text-xs sm:text-sm transition-all duration-300 flex items-center justify-center space-x-1.5 sm:space-x-2 ${"schedule"===_?"bg-white text-primary shadow-md":"text-text-secondary hover:text-text-primary hover:bg-white/50"}`,children:[(0,t.jsx)("svg",{className:"w-3.5 h-3.5 sm:w-4 sm:h-4 flex-shrink-0",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"})}),(0,t.jsx)("span",{className:"hidden sm:inline",children:"排程管理"}),(0,t.jsx)("span",{className:"sm:hidden",children:"排程"})]}),(0,t.jsxs)("button",{onClick:()=>{g(!0),j("overview")},className:`flex-1 py-2.5 sm:py-3 px-3 sm:px-5 rounded-xl font-medium text-xs sm:text-sm transition-all duration-300 flex items-center justify-center space-x-1.5 sm:space-x-2 ${"overview"===_?"bg-white text-primary shadow-md":"text-text-secondary hover:text-text-primary hover:bg-white/50"}`,children:[(0,t.jsx)("svg",{className:"w-3.5 h-3.5 sm:w-4 sm:h-4 flex-shrink-0",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"})}),(0,t.jsx)("span",{className:"hidden sm:inline",children:"業務概覽"}),(0,t.jsx)("span",{className:"sm:hidden",children:"概覽"})]})]})})})}),"overview"===_&&(0,t.jsx)(q,{filters:w,setFilters:$,updateDateRange:ej,kpiData:F,kpiLoading:h,categorySummary:L}),e&&(0,t.jsx)("div",{hidden:"schedule"!==_,children:(0,t.jsx)(G,{filters:w,onCalendarExport:eN,calendarExportLoading:v,isActive:"schedule"===_,refreshTrigger:H},e.id)}),"reports"===_&&(0,t.jsx)(Q,{filters:w,setFilters:$,updateDateRange:ej,exportLoading:f,handleExport:()=>{ee(!0)},onCalendarExport:eN,calendarExportLoading:v,onEdit:e=>{console.log("🖊️ 主要組件 handleEdit - 點擊編輯按鈕，記錄:",e),I(e),O(!0)},onDelete:ey,refreshTrigger:H,onRefresh:eb,recordUpdateTimes:K})]}),P&&E&&(0,t.jsx)(Z,{isOpen:P,onClose:()=>{O(!1),I(null)},onSubmit:ev,onDelete:ey,existingRecord:E}),X&&(0,t.jsx)(t.Fragment,{children:(0,d.createPortal)((0,t.jsxs)("div",{className:"fixed inset-0 z-[9999] overflow-y-auto",onMouseDown:e=>{e.target===e.currentTarget&&ee(!1)},children:[(0,t.jsx)("div",{className:"fixed inset-0 bg-black/60 transition-opacity"}),(0,t.jsx)("div",{className:"fixed inset-0 flex items-center justify-center p-4",children:(0,t.jsxs)("div",{className:"relative card-apple w-full max-w-lg max-h-[90vh] overflow-hidden flex flex-col shadow-2xl",onMouseDown:e=>e.stopPropagation(),children:[(0,t.jsx)("div",{className:"p-6 border-b border-border-light flex-shrink-0 bg-bg-secondary/30",children:(0,t.jsx)("h3",{className:"text-lg font-semibold text-text-primary",children:"導出設定"})}),(0,t.jsxs)("div",{className:"flex-1 overflow-y-auto p-6",children:[(0,t.jsxs)("div",{className:"mb-6",children:[(0,t.jsx)("label",{className:"block text-sm font-semibold text-text-primary mb-3",children:"預設模式"}),(0,t.jsx)("div",{className:"space-y-3",children:Object.entries(ef).map(([e,r])=>(0,t.jsxs)("label",{className:`flex items-start p-3 rounded-xl border transition-all duration-300 cursor-pointer ${ea===e?"border-primary bg-primary/5":"border-border-light hover:border-primary/50 hover:bg-bg-secondary"}`,children:[(0,t.jsx)("input",{type:"radio",name:"exportMode",value:e,checked:ea===e,onChange:e=>{var t;es(t=e.target.value),eg(ef[t].columns)},className:"mr-3 mt-1 accent-primary"}),(0,t.jsxs)("div",{children:[(0,t.jsx)("div",{className:"font-medium text-text-primary",children:r.name}),(0,t.jsx)("div",{className:"text-sm text-text-secondary",children:r.description})]})]},e))})]}),(0,t.jsxs)("div",{className:"mb-6",children:[(0,t.jsx)("label",{className:"block text-sm font-semibold text-text-primary mb-3",children:"導出格式"}),(0,t.jsxs)("div",{className:"flex space-x-3",children:[(0,t.jsxs)("label",{className:`flex-1 flex items-center justify-center p-3 rounded-xl border transition-all duration-300 cursor-pointer ${"pdf"===et?"border-primary bg-primary/5":"border-border-light hover:border-primary/50"}`,children:[(0,t.jsx)("input",{type:"radio",name:"format",value:"pdf",checked:"pdf"===et,onChange:e=>er(e.target.value),className:"mr-2 accent-primary"}),(0,t.jsx)("span",{className:"font-medium",children:"PDF"})]}),(0,t.jsxs)("label",{className:`flex-1 flex items-center justify-center p-3 rounded-xl border transition-all duration-300 cursor-pointer ${"csv"===et?"border-primary bg-primary/5":"border-border-light hover:border-primary/50"}`,children:[(0,t.jsx)("input",{type:"radio",name:"format",value:"csv",checked:"csv"===et,onChange:e=>er(e.target.value),className:"mr-2 accent-primary"}),(0,t.jsx)("span",{className:"font-medium",children:"CSV"})]})]})]}),"payroll"===ea&&"pdf"===et&&(0,t.jsxs)("div",{className:"mb-6",children:[(0,t.jsx)("label",{className:"block text-sm font-semibold text-text-primary mb-3",children:"工資導出方式"}),(0,t.jsxs)("div",{className:"space-y-2",children:[(0,t.jsxs)("label",{className:`flex items-center p-3 rounded-xl border transition-all duration-300 cursor-pointer ${"combined"===el?"border-primary bg-primary/5":"border-border-light hover:border-primary/50"}`,children:[(0,t.jsx)("input",{type:"radio",name:"payrollType",value:"combined",checked:"combined"===el,onChange:e=>en(e.target.value),className:"mr-2 accent-primary"}),(0,t.jsx)("span",{children:"合併報表 (一個PDF包含所有人員)"})]}),(0,t.jsxs)("label",{className:`flex items-center p-3 rounded-xl border transition-all duration-300 cursor-pointer ${"separate"===el?"border-primary bg-primary/5":"border-border-light hover:border-primary/50"}`,children:[(0,t.jsx)("input",{type:"radio",name:"payrollType",value:"separate",checked:"separate"===el,onChange:e=>en(e.target.value),className:"mr-2"}),(0,t.jsx)("span",{children:"個別報表 (每人單獨PDF檔案)"})]})]})]}),(0,t.jsxs)("div",{className:"mb-6",children:[(0,t.jsxs)("label",{className:"block text-sm font-medium text-text-primary mb-3",children:["選擇要導出的欄位",(0,t.jsxs)("span",{className:"text-xs text-text-secondary ml-2",children:["(",ef[ea].name," 預設配置，可自由調整)"]})]}),(0,t.jsx)("div",{className:"space-y-2 max-h-48 overflow-y-auto border border-border-light rounded-xl p-3 bg-bg-secondary",children:Object.entries({service_date:"服務日期",customer_id:"客戶編號",customer_name:"客戶姓名",phone:"客戶電話",service_address:"服務地址",start_time:"開始時間",end_time:"結束時間",service_hours:"服務時數",care_staff_name:"護理員姓名",service_fee:"服務費用",staff_salary:"護理員工資",service_profit:"服務利潤",hourly_rate:"每小時收費",hourly_salary:"每小時工資",service_type:"服務類型",project_category:"所屬項目",project_manager:"項目經理"}).map(([e,r])=>{let a=["service_date","customer_name","service_address","start_time","end_time","service_hours","care_staff_name","service_type"].includes(e);return(0,t.jsxs)("label",{className:"flex items-center",children:[(0,t.jsx)("input",{type:"checkbox",checked:eh[e],onChange:t=>{eg(r=>({...r,[e]:t.target.checked}))},className:"mr-2"}),(0,t.jsxs)("span",{className:`text-sm ${a?"font-medium text-primary":""}`,children:[r,a&&(0,t.jsx)("span",{className:"text-xs text-primary ml-1",children:"(默認)"})]})]},e)})})]})]}),(0,t.jsxs)("div",{className:"p-6 border-t border-border-light flex justify-end space-x-3 flex-shrink-0 bg-bg-secondary/30",children:[(0,t.jsx)("button",{type:"button",onMouseDown:e=>e.stopPropagation(),onClick:()=>ee(!1),className:"btn-apple-secondary",children:"取消"}),(0,t.jsx)("button",{type:"button",onMouseDown:e=>e.stopPropagation(),onClick:ew,disabled:Object.values(eh).every(e=>!e),className:"btn-apple-primary disabled:opacity-50 disabled:cursor-not-allowed",children:"確認導出"})]})]})})]}),document.body)})]})}],64069)}]);